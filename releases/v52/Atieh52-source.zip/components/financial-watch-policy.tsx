"use client";

import { useEffect, useMemo, useState } from "react";
import { AlertTriangle, ArrowLeft, CheckCircle2, ChevronDown, Gauge, LoaderCircle, LockKeyhole, ShieldAlert, Sparkles } from "lucide-react";
import { CHART_DEFINITIONS, formatNumber, type AxisBundle } from "@/lib/financial-engine";
import {
  isNearPolicyBoundary,
  resolveFinancialWatchPolicy,
  resolveTrendModifier,
  type PolicyMatrixInput,
  type PolicyRulebookRuntime,
} from "@/lib/financial-watch-policy";

let cachedRulebook: Promise<PolicyRulebookRuntime> | null = null;

async function fetchRulebookData() {
  const embedded=(globalThis as typeof globalThis & {__ATIEH_RULEBOOK__?:PolicyRulebookRuntime}).__ATIEH_RULEBOOK__;
  if(embedded)return embedded;
  const direct = await fetch("./data/financial_watch_policy_runtime.json?v=1.4-v51", { cache: "no-cache" });
  if (direct.ok) return direct.json() as Promise<PolicyRulebookRuntime>;

  const manifestResponse = await fetch("./data/financial_watch_policy_runtime.manifest.json?v=1.4-v51", { cache: "no-cache" });
  if (!manifestResponse.ok) throw new Error("Rule Book در دسترس نیست.");
  const manifest = await manifestResponse.json() as { parts?: string[] };
  if (!Array.isArray(manifest.parts) || manifest.parts.length === 0) throw new Error("ساختار Rule Book معتبر نیست.");
  const baseUrl = new URL("./data/", window.location.href);
  const sourceParts = await Promise.all(manifest.parts.map(async (name) => {
    const response = await fetch(new URL(name, baseUrl), { cache: "force-cache" });
    if (!response.ok) throw new Error("یکی از بخش‌های Rule Book در دسترس نیست.");
    return response.text();
  }));
  return JSON.parse(sourceParts.join("")) as PolicyRulebookRuntime;
}

function loadRulebook() {
  if (!cachedRulebook) {
    cachedRulebook = fetchRulebookData()
      .then((rulebook) => {
        if (rulebook.meta?.combinations !== 6561 || rulebook.combinations?.length !== 6561) {
          throw new Error("پوشش Rule Book کامل نیست.");
        }
        return rulebook;
      });
  }
  return cachedRulebook;
}

const AXIS_SCORE_LABELS = CHART_DEFINITIONS.flatMap((definition) => [definition.xLabel, definition.yLabel]);

function axisScores(bundle: AxisBundle) {
  return CHART_DEFINITIONS.flatMap((definition) => [
    bundle.axes[definition.xKey].score,
    bundle.axes[definition.yKey].score,
  ]);
}

function matrixInputs(bundle: AxisBundle): PolicyMatrixInput[] {
  return CHART_DEFINITIONS.map((definition, index) => ({
    matrix: (index + 1) as 1 | 2 | 3 | 4,
    xScore: bundle.axes[definition.xKey].score,
    yScore: bundle.axes[definition.yKey].score,
  }));
}

export default function FinancialWatchPolicy({
  bundle,
  previousBundle,
  trendThreshold, reportKind,
}: {
  bundle: AxisBundle;
  previousBundle: AxisBundle | null;
  trendThreshold: number;
  reportKind?: "annual" | "half-year";
}) {
  const [rulebook, setRulebook] = useState<PolicyRulebookRuntime | null>(() => (globalThis as typeof globalThis & {__ATIEH_RULEBOOK__?: PolicyRulebookRuntime}).__ATIEH_RULEBOOK__ ?? null);
  const [error, setError] = useState("");

  useEffect(() => {
    let active = true;
    loadRulebook()
      .then((data) => { if (active) setRulebook(data); })
      .catch((reason: unknown) => { if (active) setError(reason instanceof Error ? reason.message : "خطا در خواندن Rule Book"); });
    return () => { active = false; };
  }, []);

  const inputs = useMemo(() => matrixInputs(bundle), [bundle]);
  const resolution = useMemo(() => rulebook ? resolveFinancialWatchPolicy(rulebook, inputs) : null, [rulebook, inputs]);
  const trend = useMemo(() => rulebook ? resolveTrendModifier(
    rulebook,
    axisScores(bundle),
    previousBundle ? axisScores(previousBundle) : null,
    trendThreshold,
  ) : null, [rulebook, bundle, previousBundle, trendThreshold]);

  if (error) {
    return <section className="watch-policy-state error"><AlertTriangle size={23}/><div><strong>موتور سیاست‌گذاری فعال نشد</strong><span>{error} منطق چهار ماتریس بدون تغییر باقی مانده است.</span></div></section>;
  }
  if (!rulebook) {
    return <section className="watch-policy-state loading"><LoaderCircle size={23}/><div><strong>در حال تطبیق با کتاب قاعده</strong><span>ترکیب چهار وضعیت برای {bundle.company} در سال {bundle.year.toLocaleString("fa-IR", { useGrouping: false })} بررسی می‌شود.</span></div></section>;
  }
  if (!resolution) {
    const missing = inputs.flatMap((input, index) => {
      const definition = CHART_DEFINITIONS[index];
      return [input.xScore === null ? definition.xLabel : null, input.yScore === null ? definition.yLabel : null].filter(Boolean);
    });
    return <section className="watch-policy-state warning"><AlertTriangle size={23}/><div><strong>برای ارائه تشخیص قاعده‌محور، داده کامل چهار ماتریس لازم است</strong><span>{missing.length ? `محورهای فاقد امتیاز: ${missing.join("، ")}` : "ترکیب وضعیت با Rule Book تطبیق پیدا نکرد."}</span><small>در نبود داده کامل، مدل نتیجه حدسی تولید نمی‌کند.</small></div></section>;
  }

  const periodLabel = `${reportKind === 'half-year' ? 'شش‌ماهه' : 'سالانه'} ${bundle.year.toLocaleString('fa-IR', {useGrouping:false})}`;
  const nearBoundaries = inputs.flatMap((input, index) => {
    const definition = CHART_DEFINITIONS[index];
    return [isNearPolicyBoundary(input.xScore) ? definition.xLabel : null, isNearPolicyBoundary(input.yScore) ? definition.yLabel : null].filter(Boolean);
  });
  return (
    <section className="watch-policy-engine watch-policy-compact" aria-label="تحلیل دیده‌بان بر پایه کتابچه">
      <header className="watch-policy-heading">
        <div><span className="watch-policy-kicker"><Sparkles size={16}/> جمع‌بندی مدیریتی</span><h2>{bundle.company}</h2><p>{periodLabel}</p></div>
        <span className={`severity severity-${resolution.severity.replaceAll(' ', '-')}`}>{resolution.severity}</span>
      </header>
      <div className="watch-policy-family">
        <h3>{resolution.family.title}</h3>
        <div className="watch-policy-diagnosis"><p>{resolution.comprehensiveDiagnosis}</p></div>
      </div>
      {nearBoundaries.length > 0 && <div className="watch-policy-state warning"><AlertTriangle size={20}/><span>نزدیک مرز امتیاز در {nearBoundaries.join('، ')}؛ تغییر کوچک امتیاز می‌تواند طبقه‌بندی را تغییر دهد.</span></div>}
      {trend?.modifier && <div className="watch-policy-trend"><strong>{trend.modifier.trend}</strong><p>{trend.modifier.append_text}</p>{trend.criticalAxisDrops.length > 0 && <p>افت محورهای حیاتی در مقایسه با دوره مشابه قبل: {trend.criticalAxisDrops.map(index => AXIS_SCORE_LABELS[index]).join('، ')}</p>}</div>}
      <div className="watch-policy-actions"><header><h3>اقدام‌های پیشنهادی</h3><CheckCircle2 size={22}/></header><div>{resolution.priorityActions.slice(0,3).map((action,index) => <article key={action}><span>{(index+1).toLocaleString('fa-IR')}</span><p>{action}</p></article>)}</div></div>
      <div className="watch-policy-guardrail"><ShieldAlert size={21}/><p>{resolution.guardrail}</p></div>
      <details className="watch-detail-panel"><summary>جزئیات چهار ماتریس و دلیل این جمع‌بندی <ChevronDown size={16}/></summary>
        <div className="watch-policy-matrices">{resolution.matrixStates.map((state,index) => {
          const definition=CHART_DEFINITIONS[index];
          return <article key={state.code} className={`watch-policy-matrix matrix-${state.matrix}`}>
            <h3>{definition.title}</h3>
            <div className="watch-policy-bands"><span>{definition.xLabel}<b>{state.x_band_fa}</b><small>{formatNumber(state.xScore,2)}</small></span><ArrowLeft size={16}/><span>{definition.yLabel}<b>{state.y_band_fa}</b><small>{formatNumber(state.yScore,2)}</small></span></div>
            <p>{state.status_sentence}</p><h4>{state.micro_policy_title}</h4><p>{state.micro_policy}</p>
            <details><summary>اقدام‌ها و احتیاط این ماتریس</summary><ol>{state.priority_actions.map(action => <li key={action}>{action}</li>)}</ol><p>{state.avoid_or_guardrail}</p></details>
          </article>;
        })}</div>
        <p>سیاست جامع: {resolution.comprehensivePolicy}</p>
        <p>دلیل انتخاب: {resolution.ruleTrace}</p><p>شناسه تحلیل: {resolution.combinationId} · خانواده سیاست: {resolution.familyCode}</p>
      </details>
      <details className="watch-detail-panel"><summary>روش تحلیل و محدودیت‌ها <ChevronDown size={16}/></summary><ol>{rulebook.meta.policy_precedence.map(item => <li key={item}>{item}</li>)}</ol><p>{rulebook.meta.implementation_note}</p></details>
    </section>
  );
}
