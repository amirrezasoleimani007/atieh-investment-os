"use client";

import { useEffect, useMemo, useState } from "react";
import { ArrowLeft, Check, ChevronDown, ChevronLeft, CircleHelp, Copy, RotateCcw, Search, Shield, Target, TrendingUp } from "lucide-react";
import {
  CONDITIONS, FOCUS_OPTIONS, HORIZONS as SOURCE_HORIZONS, ISIC_INDICATORS, ISIC_PRESETS,
  MISSION_OPTIONS, YEARS, defaultMovementState, normalizeWeights, scoreIsicActivities,
  suggestFocus, canSelectPortfolio, passesMissionGate, validatePortfolioShares, validateYearAllocation,
} from "@/lib/movement-model.mjs";

type MovementRow = { id:number; name:string; x:number; dynamicY:number; priority:number; coreFit:number; adjacentFit:number; transformFit:number; horizon:string };
type MasterActivity = { code:string; name:string; parentId:number|null; parentName:string|null; include:boolean; mappingConfidence:string|null; quality:string|null; readiness:string|null; availableIndicators:number; indicators:Record<string,number|null> };
type HorizonKey = "core"|"adjacent"|"transform";
const HORIZONS=SOURCE_HORIZONS as {key:HorizonKey;label:string;color:string}[];
type Weights = Record<(typeof ISIC_INDICATORS)[number]["key"],number>;
type Shares = Record<HorizonKey,number>;
type State = { mission:Record<number,string>; conditions:Record<number,{key:string;note:string}>; focus:Record<number,string>; thresholds:{deep:number;monitor:number}; board:Record<number,{score:number;reason:string}>; annualShares:Record<number,Shares>; allocations:Record<number,Record<number,number>>; isicPreset:string; customWeights:Weights };
type Stage = "mission"|"focus"|"isic"|"board"|"portfolio";
type ScoredActivity = MasterActivity & { score:number|null; availableCount:number; dataStatus:string };
type ParentScore = { score:number|null; best:ScoredActivity|null; topThree:ScoredActivity[]; validCount:number; activityCount:number; dataStatus:string };
type IsicResult = { activities:ScoredActivity[]; sectors:Record<number,ParentScore>; weights:Weights };
const STAGES:{id:Stage;label:string;caption:string}[]=[{id:"mission",label:"غربال مأموریتی",caption:"دامنه حضور"},{id:"focus",label:"تمرکز فرصت‌ها",caption:"بررسی یا رصد"},{id:"isic",label:"تحلیل تفصیلی",caption:"فعالیت‌های زیر‌بخش"},{id:"board",label:"سیاست هیئت‌مدیره",caption:"ترجیح مستقل"},{id:"portfolio",label:"پرتفوی هدف",caption:"نقشه ۱۴۰۶ تا ۱۴۱۴"}];
const fa=(value:number|null|undefined,d=1)=>value==null||!Number.isFinite(value)?"—":value.toLocaleString("fa-IR",{minimumFractionDigits:d,maximumFractionDigits:d});
const faInt=(value:number)=>value.toLocaleString("fa-IR");
const baseRow=(row:MovementRow)=>({mission:"مجاز",focus:suggestFocus(row.priority),horizon:row.horizon});

function loadSaved():State {
  const defaults=defaultMovementState() as State;
  try {
    const saved=localStorage.getItem("ips-movement-path-v1");
    if(!saved)return defaults;
    const parsed=JSON.parse(saved);
    return {...defaults,...parsed,thresholds:{...defaults.thresholds,...parsed.thresholds},annualShares:{...defaults.annualShares,...parsed.annualShares},allocations:{...defaults.allocations,...parsed.allocations}};
  } catch { return defaults; }
}

export default function MovementPath({rows,masterData}:{rows:MovementRow[];masterData:MasterActivity[]}) {
  const [stage,setStage]=useState<Stage>("mission");
  const [state,setState]=useState<State>(()=>defaultMovementState() as State);
  const [ready,setReady]=useState(false);
  const [query,setQuery]=useState("");
  const [activeYear,setActiveYear]=useState(1406);
  const [activeHorizon,setActiveHorizon]=useState<HorizonKey>("core");
  const [weightMode,setWeightMode]=useState(false);
  const preset=(state.isicPreset||"balanced") as keyof typeof ISIC_PRESETS|"custom";
  const customWeights=state.customWeights;

  // Hydrate the saved decision workspace once after browser mount.
  useEffect(()=>{setState(loadSaved());setReady(true)},[]); // eslint-disable-line react-hooks/set-state-in-effect
  useEffect(()=>{if(ready)localStorage.setItem("ips-movement-path-v1",JSON.stringify(state))},[state,ready]);

  const effectiveWeights=useMemo(()=>preset==="custom"?normalizeWeights(customWeights):ISIC_PRESETS[preset as keyof typeof ISIC_PRESETS].weights as Weights,[preset,customWeights]);
  const isic=useMemo(()=>scoreIsicActivities(masterData,effectiveWeights) as IsicResult,[masterData,effectiveWeights]);
  const selectedStageIndex=STAGES.findIndex(item=>item.id===stage);
  const records=useMemo(()=>rows.map(row=>({ ...row, ...baseRow(row), mission:state.mission[row.id]??"مجاز", focus:state.focus[row.id]??suggestFocus(row.priority,state.thresholds), condition:state.conditions[row.id]??{key:"",note:""}, board:state.board[row.id]??{score:3,reason:""}, detail:isic.sectors[row.id] })),[rows,state,isic]);
  const filtered=records.filter(row=>!query||`${row.name} ${row.id}`.toLocaleLowerCase("fa").includes(query.toLocaleLowerCase("fa")));
  const missionPassed=records.filter(row=>passesMissionGate(row.mission));
  const focusRows=missionPassed.map(row=>({...row,focus:state.focus[row.id]??suggestFocus(row.priority,state.thresholds)}));
  const boardRows=focusRows.filter(row=>row.focus!=="فعلاً متوقف");
  const deepRows=focusRows.filter(row=>row.focus==="بررسی عمیق");
  const detailedRows=deepRows.filter(row=>row.detail?.validCount>0);
  const portfolioRows=records.filter(row=>canSelectPortfolio(row.mission,state.focus[row.id]??suggestFocus(row.priority,state.thresholds)));
  const annual=state.annualShares[activeYear]??{core:60,adjacent:30,transform:10};
  const allocation=state.allocations[activeYear]??{};
  const currentRows=portfolioRows.filter(row=>row.horizon===activeHorizon);
  const annualValidation=validateYearAllocation(annual,allocation,rows.map(row=>({...row,mission:state.mission[row.id]??"مجاز",focus:state.focus[row.id]??suggestFocus(row.priority,state.thresholds)})));
  const update=(patch:Partial<State>)=>setState(current=>({...current,...patch}));
  const setMission=(id:number,value:string)=>setState(current=>({...current,mission:{...current.mission,[id]:value}}));
  const setFocus=(id:number,value:string)=>setState(current=>({...current,focus:{...current.focus,[id]:value}}));
  const setCondition=(id:number,key:string,note?:string)=>setState(current=>({...current,conditions:{...current.conditions,[id]:{key,note:note??current.conditions[id]?.note??""}}}));
  const setBoard=(id:number,key:"score"|"reason",value:string|number)=>setState(current=>({...current,board:{...current.board,[id]:{score:current.board[id]?.score??3,reason:current.board[id]?.reason??"",[key]:value}}}));
  const setAnnualShare=(key:HorizonKey,next:number)=>setState(current=>{
    const before=current.annualShares[activeYear]??{core:60,adjacent:30,transform:10};
    const bounded=Math.max(0,Math.min(100,Number(next)||0));
    const other=(Object.keys(before) as HorizonKey[]).filter(item=>item!==key);
    const oldTotal=other.reduce((sum,item)=>sum+before[item],0);
    const remaining=100-bounded;
    const updated:Shares={core:0,adjacent:0,transform:0,[key]:bounded};
    other.forEach(item=>updated[item]=oldTotal?remaining*before[item]/oldTotal:remaining/other.length);
    const rounded:Shares={core:Math.round(updated.core*10)/10,adjacent:Math.round(updated.adjacent*10)/10,transform:Math.round(updated.transform*10)/10};
    const residue=Math.round((100-(Object.values(rounded) as number[]).reduce((sum,value)=>sum+value,0))*10)/10;
    rounded.transform=Math.round((rounded.transform+residue)*10)/10;
    return {...current,annualShares:{...current.annualShares,[activeYear]:rounded}};
  });
  const setAllocation=(id:number,value:number,selected:boolean)=>setState(current=>{
    const next={...(current.allocations[activeYear]??{})};
    if(!selected)delete next[id];else next[id]=Math.max(0,Number(value)||0);
    return {...current,allocations:{...current.allocations,[activeYear]:next}};
  });
  const copyPrevious=()=>{
    if(activeYear<=YEARS[0])return;
    const previous=activeYear-1;
    setState(current=>({...current,annualShares:{...current.annualShares,[activeYear]:{...(current.annualShares[previous]??{core:60,adjacent:30,transform:10})}},allocations:{...current.allocations,[activeYear]:{...(current.allocations[previous]??{})}}}));
  };
  const reset=()=>{setState(defaultMovementState() as State);setWeightMode(false);};

  return <main className="app-page movement-journey" dir="rtl">
    <header className="movement-heading"><div><span className="overline">از فرصت تا نقشه پرتفوی هدف</span><h1>مسیر حرکت</h1><p>پل تصمیم‌گیری میان تحلیل فرصت‌های رشد، سیاست سرمایه‌گذاری و ترکیب هدف پرتفوی در افق ۱۴۰۶ تا ۱۴۱۴.</p></div><div className="movement-summary"><span><b>{faInt(records.length)}</b><small>فرصت کلان</small></span><i/><span><b>{faInt(missionPassed.length)}</b><small>عبور از مأموریت</small></span><i/><span><b>{faInt(detailedRows.length)}</b><small>دارای تحلیل تفصیلی</small></span></div></header>
    <nav className="movement-steps" aria-label="مراحل مسیر حرکت">{STAGES.map((item,index)=><button key={item.id} className={stage===item.id?"active":index<selectedStageIndex?"complete":""} onClick={()=>setStage(item.id)}><span>{index<selectedStageIndex?<Check/>:faInt(index+1)}</span><b>{item.label}</b><small>{item.caption}</small>{index<STAGES.length-1&&<ChevronLeft/>}</button>)}</nav>
    <section className="movement-content">
      {stage==="mission"&&<>
        <header className="movement-section-title"><div><span className="movement-step-kicker">مرحله ۱ · غربال بدون امتیازدهی</span><h2>مأموریت گروه، مرز حضور را تعیین می‌کند</h2><p>وضعیت مأموریتی صرفاً فیلتر تصمیم است؛ هیچ‌یک از امتیازهای علمی فرصت تغییر نمی‌کند.</p></div><div className="movement-tools"><label><Search/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="جست‌وجوی فرصت…"/></label><button onClick={reset}><RotateCcw/> بازنشانی مسیر</button></div></header>
        <div className="movement-table-wrap"><table className="movement-table"><thead><tr><th>فرصت</th><th>امتیاز رشد</th><th>تناسب راهبردی</th><th>امتیاز ترکیبی ماتریس</th><th>طبقه</th><th>وضعیت مأموریت</th><th>شرط ورود</th></tr></thead><tbody>{filtered.map(row=><tr key={row.id}><td><b>{row.name}</b><small>شناسه {faInt(row.id)}</small></td><td>{fa(row.x,2)} <small>از ۹٫۵</small></td><td>{fa(row.dynamicY,2)} <small>از ۹٫۵</small></td><td><strong className="movement-score">{fa(row.priority,1)}</strong><small>از ۱۰۰</small></td><td><span className={`horizon-tag ${row.horizon}`}>{HORIZONS.find(h=>h.key===row.horizon)?.label??row.horizon}</span></td><td><select value={row.mission} onChange={e=>setMission(row.id,e.target.value)}>{MISSION_OPTIONS.map(option=><option key={option}>{option}</option>)}</select></td><td>{row.mission==="مشروط"?<div className="condition-editor"><select value={row.condition.key} onChange={e=>setCondition(row.id,e.target.value)}><option value="">ثبت شرط…</option>{CONDITIONS.map(item=><option key={item}>{item}</option>)}</select>{row.condition.key==="سایر"&&<input value={row.condition.note} onChange={e=>setCondition(row.id,"سایر",e.target.value)} placeholder="شرح شرط"/>}</div>:<span className="muted-cell">{row.mission==="خارج از مأموریت"?"در مراحل بعد نمایش داده نمی‌شود":"—"}</span>}</td></tr>)}</tbody></table></div>
        <footer className="movement-footnote"><Shield/><span>خارج از مأموریت در پایگاه داده باقی می‌ماند و امتیازهای کلان آن حذف یا دستکاری نمی‌شود.</span><button onClick={()=>setStage("focus")}>ادامه به تمرکز فرصت‌ها <ArrowLeft/></button></footer>
      </>}

      {stage==="focus"&&<>
        <header className="movement-section-title"><div><span className="movement-step-kicker">مرحله ۲ · آستانه‌ها قابل تنظیم‌اند</span><h2>ظرفیت تیم را روی فرصت‌های درست متمرکز کنید</h2><p>پیشنهاد اولیه فقط از امتیاز ترکیبی فعلی ماتریس می‌آید و برای مدیر قابل تغییر است.</p></div><details className="movement-thresholds"><summary><CircleHelp/> تنظیم پیشنهاد اولیه <ChevronDown/></summary><label>بررسی عمیق از <input type="number" min="0" max="100" value={state.thresholds.deep} onChange={e=>{const deep=Math.max(Number(e.target.value)||0,state.thresholds.monitor);update({thresholds:{...state.thresholds,deep}})}}/> به بالا</label><label>رصد از <input type="number" min="0" max="100" value={state.thresholds.monitor} onChange={e=>{const monitor=Math.min(Number(e.target.value)||0,state.thresholds.deep);update({thresholds:{...state.thresholds,monitor}})}}/> به بالا</label><small>مقادیر پایه ۶۵ و ۴۰ هستند؛ میانبر پیشنهاد، امتیاز جدید تولید نمی‌کند.</small></details></header>
        <div className="movement-gate-counts">{FOCUS_OPTIONS.map(option=><div key={option}><span>{option}</span><b>{faInt(focusRows.filter(row=>row.focus===option).length)}</b></div>)}</div>
        <div className="movement-table-wrap"><table className="movement-table"><thead><tr><th>فرصت واجد مأموریت</th><th>امتیاز ترکیبی موجود</th><th>امتیاز رشد</th><th>تناسب راهبردی</th><th>طبقه</th><th>پیشنهاد</th><th>تصمیم مدیر</th></tr></thead><tbody>{focusRows.map(row=><tr key={row.id}><td><b>{row.name}</b></td><td><strong className="movement-score">{fa(row.priority,1)}</strong><small>از ۱۰۰</small></td><td>{fa(row.x,2)}</td><td>{fa(row.dynamicY,2)}</td><td><span className={`horizon-tag ${row.horizon}`}>{HORIZONS.find(h=>h.key===row.horizon)?.label}</span></td><td><span className="suggested-focus">{suggestFocus(row.priority,state.thresholds)}</span></td><td><select value={row.focus} onChange={e=>setFocus(row.id,e.target.value)}>{FOCUS_OPTIONS.map(option=><option key={option}>{option}</option>)}</select></td></tr>)}</tbody></table></div>
        <footer className="movement-footnote"><Target/><span>{faInt(records.length-missionPassed.length)} فرصت خارج از مأموریت از این مرحله کنار گذاشته شده‌اند.</span><button onClick={()=>setStage("isic")}>مشاهده تحلیل تفصیلی <ArrowLeft/></button></footer>
      </>}

      {stage==="isic"&&<>
        <header className="movement-section-title"><div><span className="movement-step-kicker">مرحله ۳ · فقط بررسی عمیق و دارای نگاشت</span><h2>تحلیل تفصیلی فعالیت‌های زیر‌بخش</h2><p>امتیاز زیر‌بخش‌ها به‌صورت صدکی و با وزن‌های قابل تنظیم محاسبه می‌شود؛ امتیاز تفصیلی از امتیاز کلان جدا می‌ماند.</p></div><div className="isic-weight-controls"><select value={preset} onChange={e=>{const value=e.target.value as keyof typeof ISIC_PRESETS|"custom";setState(current=>({...current,isicPreset:value}));setWeightMode(value==="custom");}}>{Object.entries(ISIC_PRESETS).map(([key,item])=><option key={key} value={key}>{item.label}</option>)}<option value="custom">سفارشی</option></select><button onClick={()=>{setState(current=>({...current,isicPreset:"balanced",customWeights:{...ISIC_PRESETS.balanced.weights}}));setWeightMode(false);}}>بازگشت به متوازن</button></div></header>
        <div className="isic-weight-strip">{ISIC_INDICATORS.map(indicator=><label key={indicator.key}><span>{indicator.label}</span>{weightMode?<><input type="number" min="0" max="100" value={customWeights[indicator.key]} onChange={e=>setState(current=>({...current,isicPreset:"custom",customWeights:{...current.customWeights,[indicator.key]:Number(e.target.value)}}))}/><small>نهایی {fa(effectiveWeights[indicator.key],1)}٪</small></>:<b>{fa(effectiveWeights[indicator.key],1)}٪</b>}</label>)}<strong>جمع وزن نهایی: {fa(Object.values(effectiveWeights).reduce((sum,value)=>sum+value,0),1)}٪</strong></div>
        <div className="movement-gate-counts isic-quality-counts"><div><span>فرصت بررسی عمیق</span><b>{faInt(deepRows.length)}</b></div><div><span>دارای نگاشت تفصیلی معتبر</span><b>{faInt(detailedRows.length)}</b></div><div><span>بدون داده تفصیلی معتبر</span><b>{faInt(deepRows.length-detailedRows.length)}</b></div></div>
        <div className="movement-table-wrap"><table className="movement-table"><thead><tr><th>بخش کلان</th><th>امتیاز کلان فرصت–ارتباط</th><th>امتیاز تفصیلی بخش</th><th>زیر‌بخش برتر</th><th>زیر‌بخش معتبر</th><th>سه زیر‌بخش برتر</th></tr></thead><tbody>{deepRows.map(row=>{const detail=row.detail;return <tr key={row.id}><td><b>{row.name}</b><small>{HORIZONS.find(h=>h.key===row.horizon)?.label}</small></td><td><strong>{fa(row.priority,1)}</strong><small>امتیاز ترکیبی موجود از ۱۰۰</small></td><td>{detail?.score==null?<span className="quality-insufficient">داده ناکافی</span>:<strong className="movement-score">{fa(detail.score,1)}<small> از ۱۰۰ · میانه</small></strong>}</td><td>{detail?.best?<><b className="activity-name">{detail.best.name}</b><small>{fa(detail.best.score,1)} · کد {detail.best.code}</small></>:"—"}</td><td>{detail?.validCount?faInt(detail.validCount):"—"} {detail?.activityCount?`از ${faInt(detail.activityCount)}`:""}</td><td><div className="top-activities">{(detail?.topThree??[]).map((activity,index)=><span key={activity.code}><i>{faInt(index+1)}</i>{activity.name}<b>{fa(activity.score,1)}</b></span>)}</div></td></tr>})}</tbody></table></div>
        {deepRows.length===0&&<div className="movement-empty">برای مشاهده تحلیل تفصیلی، دست‌کم یک فرصت را در مأموریت مجاز/مشروط و بررسی عمیق قرار دهید.</div>}
        <p className="isic-method-note">صدک‌ها بین فعالیت‌های معتبر همین فایل محاسبه شده‌اند. برای هر فعالیت، وزن مؤلفه‌های دارای مقدار واقعی دوباره نرمال می‌شود؛ فعالیت با کمتر از ۴ شاخص معتبر «داده ناکافی» می‌گیرد. امتیاز بخش، میانه زیر‌بخش‌های معتبر است و با امتیاز کلان جمع نمی‌شود.</p>
        <footer className="movement-footnote"><TrendingUp/><span>فایل داده ۱۴۵ فعالیت دارد؛ اتصال هر ردیف از شناسه بخش اصلی موجود در فایل انجام شده است.</span><button onClick={()=>setStage("board")}>تعیین سیاست هیئت‌مدیره <ArrowLeft/></button></footer>
      </>}

      {stage==="board"&&<>
        <header className="movement-section-title"><div><span className="movement-step-kicker">مرحله ۴ · ترجیح مستقل از مدل علمی</span><h2>سیاست سرمایه‌گذاری هیئت‌مدیره</h2><p>این ترجیح بر امتیاز کلان یا تفصیلی اثر نمی‌گذارد و فقط ورودی مستقل سیاست سرمایه‌گذاری است.</p></div><div className="board-scale">۱ بسیار پایین <i/> ۳ عادی <i/> ۵ راهبردی بالا</div></header>
        <div className="movement-table-wrap"><table className="movement-table"><thead><tr><th>فرصت</th><th>امتیاز کلان</th><th>امتیاز تفصیلی</th><th>سیاست هیئت‌مدیره</th><th>مأموریت</th><th>طبقه</th><th>دلیل ترجیح</th></tr></thead><tbody>{boardRows.map(row=>{const detail=isic.sectors[row.id];return <tr key={row.id}><td><b>{row.name}</b></td><td><strong className="movement-score">{fa(row.priority,1)}</strong><small>از ۱۰۰</small></td><td>{detail?.score==null?<span className="muted-cell">{deepRows.some(item=>item.id===row.id)?"داده ناکافی":"—"}</span>:<strong>{fa(detail.score,1)}<small> از ۱۰۰</small></strong>}</td><td><select className="board-score-select" aria-label={`امتیاز سیاست ${row.name}`} value={state.board[row.id]?.score??3} onChange={e=>setBoard(row.id,"score",Number(e.target.value))}>{[1,2,3,4,5].map(score=><option key={score} value={score}>{score} · {(["اولویت بسیار پایین","پایین","عادی","بالا","اولویت راهبردی بالا"])[score-1]}</option>)}</select></td><td><span className={`mission-tag ${row.mission===`مشروط`?"conditional":""}`}>{row.mission}</span>{row.mission==="مشروط"&&row.condition.key&&<small>{row.condition.key}</small>}</td><td><span className={`horizon-tag ${row.horizon}`}>{HORIZONS.find(h=>h.key===row.horizon)?.label}</span></td><td><input className="board-reason" value={state.board[row.id]?.reason??""} onChange={e=>setBoard(row.id,"reason",e.target.value)} placeholder="دلیل کوتاه ترجیح…"/></td></tr>})}</tbody></table></div>
        <footer className="movement-footnote"><CircleHelp/><span>مقدار آغازین همه فرصت‌ها ۳ است؛ تصمیم ثبت‌شده، امتیاز علمی یا رتبه ماتریس را بازنویسی نمی‌کند.</span><button onClick={()=>setStage("portfolio")}>ترکیب پرتفوی هدف <ArrowLeft/></button></footer>
      </>}

      {stage==="portfolio"&&<>
        <header className="movement-section-title"><div><span className="movement-step-kicker">مرحله ۵ · نقشه گذار، بدون برنامه مالی</span><h2>ترکیب هدف پرتفوی در افق ۱۴۰۶ تا ۱۴۱۴</h2><p>سهم هر افق را تعیین کنید، فرصت‌های قابل‌انتخاب را برگزینید و درصد آنها را دقیقاً به سهم همان افق برسانید.</p></div><button className="copy-year-button" disabled={activeYear===YEARS[0]} onClick={copyPrevious}><Copy/> کپی ترکیب و انتخاب‌های سال قبل</button></header>
        <div className="year-ribbon">{YEARS.map(year=><button key={year} className={activeYear===year?"active":""} onClick={()=>setActiveYear(year)}>{faInt(year)}</button>)}</div>
        <section className="year-policy-panel"><div className="year-policy-inputs">{HORIZONS.map(item=><label key={item.key} style={{"--horizon-color":item.color} as React.CSSProperties}><span><i/>{item.label}</span><div><input type="number" min="0" max="100" value={Math.round(annual[item.key])} onChange={e=>setAnnualShare(item.key,Number(e.target.value))}/><b>٪</b></div></label>)}<div className="year-total"><small>جمع هدف سال</small><b>{validatePortfolioShares(annual)?"۱۰۰٪":"نامعتبر"}</b></div></div><div className="year-mix-chart" aria-label="روند ترکیب هدف پرتفوی طی سال‌ها">{YEARS.map(year=>{const mix=state.annualShares[year]??{core:60,adjacent:30,transform:10};return <button key={year} className={year===activeYear?"selected":""} onClick={()=>setActiveYear(year)} title={`${faInt(year)} · هسته ${fa(mix.core,0)}٪ · مجاور ${fa(mix.adjacent,0)}٪ · تحولی ${fa(mix.transform,0)}٪`}><div><i style={{height:`${mix.transform}%`,background:HORIZONS[2].color}}/><i style={{height:`${mix.adjacent}%`,background:HORIZONS[1].color}}/><i style={{height:`${mix.core}%`,background:HORIZONS[0].color}}/></div><small>{faInt(year).slice(-2)}</small></button>})}</div></section>
        <div className="allocation-toolbar"><div><span>تخصیص فرصت‌های سال</span><small>{faInt(activeYear)} · مجموع انتخاب‌ها باید با سهم افق برابر باشد</small></div><div className="horizon-filters">{HORIZONS.map(item=><button key={item.key} className={activeHorizon===item.key?"active":""} style={{"--horizon-color":item.color} as React.CSSProperties} onClick={()=>setActiveHorizon(item.key)}>{item.label} <b>{fa(annual[item.key as HorizonKey],0)}٪</b></button>)}</div></div>
        <div className="allocation-balance-strip"><div><span>هدف این افق</span><b>{fa(annual[activeHorizon],1)}٪</b></div><div><span>تخصیص فعلی</span><b>{fa(annualValidation.totals?.[activeHorizon]??0,1)}٪</b></div><div><span>باقی‌مانده</span><b>{fa(annual[activeHorizon]-(annualValidation.totals?.[activeHorizon]??0),1)}٪</b></div><span className={annualValidation.valid?"allocation-ok":"allocation-pending"}>{annualValidation.valid?"ترکیب سال کامل است":"تخصیص سال هنوز کامل نشده"}</span></div>
        <div className="movement-table-wrap"><table className="movement-table allocation-table"><thead><tr><th>انتخاب</th><th>فرصت و طبقه‌بندی</th><th>امتیاز کلان</th><th>امتیاز تفصیلی</th><th>سیاست هیئت‌مدیره</th><th>مأموریت / تمرکز</th><th>درصد هدف این سال</th></tr></thead><tbody>{currentRows.map(row=>{const selected=Object.prototype.hasOwnProperty.call(allocation,row.id);const detail=isic.sectors[row.id];return <tr key={row.id} className={selected?"allocated":""}><td><input type="checkbox" checked={selected} onChange={e=>setAllocation(row.id,e.target.checked?0:0,e.target.checked)} aria-label={`انتخاب ${row.name}`}/></td><td><b>{row.name}</b><small><span className={`horizon-tag ${row.horizon}`}>{HORIZONS.find(h=>h.key===row.horizon)?.label}</span></small></td><td><strong className="movement-score">{fa(row.priority,1)}</strong></td><td>{detail?.score==null?<span className="muted-cell">—</span>:fa(detail.score,1)}</td><td><strong>{fa(state.board[row.id]?.score??3,0)} از ۵</strong></td><td><span className="mission-tag">{row.mission}</span><small>{row.focus}</small></td><td><label className="allocation-input"><input type="number" min="0" max="100" step="0.1" disabled={!selected} value={selected?allocation[row.id]:""} onChange={e=>setAllocation(row.id,Number(e.target.value),true)}/><span>٪</span></label></td></tr>})}</tbody></table></div>
        {currentRows.length===0&&<div className="movement-empty">در این طبقه فرصت قابل تخصیصی نیست. وضعیت مأموریت یا تمرکز فرصت‌ها را بازبینی کنید.</div>}
        <footer className="movement-footnote"><CircleHelp/><span>{annualValidation.reason} این نقشه ترکیب راهبردی پرتفوی است و تعهد سرمایه یا برنامه تأمین منابع محسوب نمی‌شود.</span><button className="save-status" disabled={!annualValidation.valid}><Check/> {annualValidation.valid?"نقشه این سال متوازن است":"برای تکمیل، درصد فرصت‌ها را تنظیم کنید"}</button></footer>
      </>}
    </section>
    <footer className="movement-persistence"><span><Check/> تصمیم‌های این مسیر روی همین مرورگر ذخیره می‌شوند.</span><button onClick={()=>{setState(loadSaved());setReady(true)}}><RotateCcw/> بازیابی ذخیره</button></footer>
  </main>;
}
