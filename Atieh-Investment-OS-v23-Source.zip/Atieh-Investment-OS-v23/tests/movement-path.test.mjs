import test from "node:test";
import assert from "node:assert/strict";
import master from "../public/data/movement-master-data.json" with { type: "json" };
import {
  FOCUS_CONFIG, HORIZONS, ISIC_INDICATORS, ISIC_PRESETS, YEARS, canEnterDetailedAnalysis,
  canSelectPortfolio, normalizeWeights, passesMissionGate, scoreIsicActivities,
  suggestFocus, validatePortfolioShares, validateYearAllocation,
} from "../lib/movement-model.mjs";

test("the source adapter has 145 rows and real 77-sector primary mappings", () => {
  assert.equal(master.length, 145);
  assert.ok(master.some((row) => row.include && row.parentId === 7));
  assert.ok(master.filter((row) => row.parentId !== null).every((row) => Number.isInteger(row.parentId) && row.parentName));
  assert.equal(ISIC_INDICATORS.length, 6);
});

test("Mission Gate and Focus Gate remain separate from model scores", () => {
  assert.equal(passesMissionGate("مجاز"), true);
  assert.equal(passesMissionGate("مشروط"), true);
  assert.equal(passesMissionGate("خارج از مأموریت"), false);
  assert.equal(canEnterDetailedAnalysis("مجاز", "بررسی عمیق", true), true);
  assert.equal(canEnterDetailedAnalysis("خارج از مأموریت", "بررسی عمیق", true), false);
  assert.equal(canEnterDetailedAnalysis("مشروط", "رصد", true), false);
  assert.equal(canEnterDetailedAnalysis("مجاز", "بررسی عمیق", false), false);
  assert.equal(canSelectPortfolio("مجاز", "رصد"), true);
  assert.equal(canSelectPortfolio("مجاز", "فعلاً متوقف"), false);
  assert.equal(suggestFocus(FOCUS_CONFIG.deep), "بررسی عمیق");
  assert.equal(suggestFocus(FOCUS_CONFIG.monitor), "رصد");
});

test("weight presets normalize to exactly 100 and weights change sub-sector rankings", () => {
  for (const preset of Object.values(ISIC_PRESETS)) {
    assert.equal(Object.values(normalizeWeights(preset.weights)).reduce((sum, value) => sum + value, 0), 100);
  }
  const balanced = scoreIsicActivities(master, ISIC_PRESETS.balanced.weights);
  const investment = scoreIsicActivities(master, ISIC_PRESETS.investment.weights);
  const rank = (result) => result.activities.filter((row) => row.score != null).sort((a, b) => b.score - a.score).map((row) => row.code);
  assert.notDeepEqual(rank(balanced), rank(investment));
  assert.equal(Object.values(balanced.weights).reduce((sum, value) => sum + value, 0), 100);
});

test("missing values are excluded and sparse activities report insufficient data", () => {
  const rows = [
    { code: "a", parentId: 1, include: true, readiness: "آماده تحلیل", indicators: { economicSize: 1, valueCreation: 1, investment: 1, productivity: 1, employmentGrowth: 1, firmGrowth: 1 } },
    { code: "b", parentId: 1, include: true, readiness: "آماده تحلیل", indicators: { economicSize: 9, valueCreation: 9, investment: 9, productivity: 9, employmentGrowth: 9, firmGrowth: 9 } },
    { code: "c", parentId: 2, include: true, readiness: "آماده تحلیل", indicators: { economicSize: 5, valueCreation: 5, investment: null, productivity: null, employmentGrowth: null, firmGrowth: null } },
    { code: "d", parentId: 2, include: true, readiness: "داده ناکافی", indicators: { economicSize: 0, valueCreation: 0, investment: 0, productivity: 0, employmentGrowth: 0, firmGrowth: 0 } },
  ];
  const result = scoreIsicActivities(rows);
  assert.equal(result.activities.find((row) => row.code === "c").score, null);
  assert.equal(result.activities.find((row) => row.code === "c").dataStatus, "داده ناکافی");
  assert.equal(result.activities.find((row) => row.code === "d").score, null);
  assert.equal(result.activities.find((row) => row.code === "d").dataStatus, "داده ناکافی");
  assert.equal(result.sectors[2].score, null);
  assert.equal(result.sectors[2].activityCount, 2);
  assert.equal(result.sectors[1].validCount, 2);
});

test("parent-sector score is the median and reports best plus top three", () => {
  const result = scoreIsicActivities(master, ISIC_PRESETS.balanced.weights);
  const sector = Object.values(result.sectors).find((row) => row.validCount >= 3);
  assert.ok(sector);
  assert.equal(sector.topThree.length, Math.min(3, sector.validCount));
  assert.equal(sector.best.code, sector.topThree[0].code);
  assert.ok(Number.isFinite(sector.score) && sector.score >= 0 && sector.score <= 100);
});

test("detailed sector scoring is gated while the percentile reference remains the full master", () => {
  const full = scoreIsicActivities(master, ISIC_PRESETS.balanced.weights);
  const targetId = Number(Object.keys(full.sectors).find((id) => full.sectors[id].validCount > 0));
  const targeted = scoreIsicActivities(master, ISIC_PRESETS.balanced.weights, [targetId]);
  assert.deepEqual(Object.keys(targeted.sectors), [String(targetId)]);
  assert.ok(targeted.activities.every((row) => row.parentId === targetId));
  assert.equal(targeted.sectors[targetId].score, full.sectors[targetId].score);
});

test("year shares and each selected horizon allocation must reconcile", () => {
  assert.equal(YEARS.length, 9);
  assert.equal(YEARS[0], 1406);
  assert.equal(YEARS.at(-1), 1414);
  assert.equal(validatePortfolioShares({ core: 60, adjacent: 30, transform: 10 }), true);
  assert.equal(validatePortfolioShares({ core: 60, adjacent: 30, transform: 9 }), false);
  const rows = [
    { id: 1, horizon: HORIZONS[0].key, mission: "مجاز", focus: "بررسی عمیق" },
    { id: 2, horizon: HORIZONS[1].key, mission: "مشروط", focus: "رصد" },
    { id: 3, horizon: HORIZONS[2].key, mission: "مجاز", focus: "بررسی عمیق" },
    { id: 4, horizon: HORIZONS[0].key, mission: "خارج از مأموریت", focus: "بررسی عمیق" },
  ];
  const targets = { core: 60, adjacent: 30, transform: 10 };
  const balanced = validateYearAllocation(targets, { 1: 60, 2: 30, 3: 10 }, rows);
  assert.equal(balanced.valid, true);
  assert.equal(balanced.totals.core, 60);
  assert.equal(validateYearAllocation(targets, { 1: 50, 2: 30, 3: 10 }, rows).valid, false);
  assert.equal(validateYearAllocation(targets, { 1: 60, 2: 30, 3: 10, 4: 1 }, rows).valid, false);
});
