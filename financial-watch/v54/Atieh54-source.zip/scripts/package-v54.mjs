import {readFile,writeFile,mkdir,copyFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
const source=path.resolve(import.meta.dirname,'..'),out=path.resolve(source,'../delivery-watch-v54');
await mkdir(out,{recursive:true});
const html=await readFile(path.join(source,'dist-standalone/IPS-Dashboard.html'));
await writeFile(path.join(out,'index.html'),html);
await copyFile(path.join(source,'data/policy/financial_watch_narratives_fa_v7_SITE.json'),path.join(out,'financial_watch_narratives_fa_v7_SITE.json'));
await copyFile(path.join(source,'README-v54.md'),path.join(out,'README.md'));
const files=['app/dashboard-app.tsx','app/watch-v7.css','components/financial-watch-policy.tsx','lib/watch-narrative.ts','scripts/build-watch-v7.mjs','tests/watch-v7.test.ts','tests/watch-ui-v53.test.tsx','package.json','static-main.tsx'];
for(const f of files){const dst=path.join(out,'changes',f);await mkdir(path.dirname(dst),{recursive:true});await copyFile(path.join(source,f),dst)}
const manifest={applicationVersion:'54.0.0',base:'financial-watch-v53',rulebookVersion:7,publishPrefix:'financial-watch/v54/',sourceSha256:'864b151a64df7ab339484bd0dfe78555673f758f71eb0dda64be831d7a4f11f7',htmlSha256:createHash('sha256').update(html).digest('hex'),htmlBytes:html.length,exactSourceMatches:6561,validation:{typecheck:'passed',standaloneBuild:'passed',pagesBuild:'passed',testsPassed:55,testsSkippedForMissingHistoricInterimFixture:4,edgeVisualReview:'local component preview: annual Caspian 1404/1403, Nour 1403 and portfolio'},date:'2026-11-23'};
await writeFile(path.join(out,'build-manifest.json'),JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify(manifest));
