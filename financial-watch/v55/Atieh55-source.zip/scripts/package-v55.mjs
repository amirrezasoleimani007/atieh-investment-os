import {readFile,writeFile,mkdir,copyFile} from 'node:fs/promises';
import {createHash} from 'node:crypto';
import path from 'node:path';
const source=path.resolve(import.meta.dirname,'..'),out=path.resolve(source,'../delivery-watch-v55');
await mkdir(out,{recursive:true});
const html=await readFile(path.join(source,'dist-standalone/IPS-Dashboard.html'));
await writeFile(path.join(out,'index.html'),html);
await copyFile(path.join(source,'README-v55.md'),path.join(out,'README.md'));
const files=['components/company-report-pilot.tsx','app/report-pilot.css','app/dashboard-app.tsx','lib/report-evidence.ts','lib/report-contract.mjs','server/openrouter-handler.mjs','server/openrouter-server.mjs','tests/report-pilot.test.ts','tests/openrouter-handler.test.mjs','package.json','OPENROUTER.example.env'];
for(const f of files){const dst=path.join(out,'changes',f);await mkdir(path.dirname(dst),{recursive:true});await copyFile(path.join(source,f),dst)}
const manifest={applicationVersion:'55.0.0',base:'financial-watch/v54',rulebookVersion:7,publishPrefix:'financial-watch/v55/',rulebookSha256:'864b151a64df7ab339484bd0dfe78555673f758f71eb0dda64be831d7a4f11f7',htmlSha256:createHash('sha256').update(html).digest('hex'),htmlBytes:html.length,exactSourceMatches:6561,reportMode:'local deterministic demo; optional server-side OpenRouter adapter',liveInferenceTested:false,privateFinancialDataIncluded:false,validation:{typecheck:'passed',standaloneBuild:'passed',pagesBuild:'passed',testsPassed:64,testsSkippedForMissingHistoricInterimFixture:4,apiTests:'mocked upstream only',edgeVisualReview:'annual Caspian: latest 1404 and selected 1403; radar, four paragraphs, stale report cleared'},date:'2026-11-23'};
await writeFile(path.join(out,'build-manifest.json'),JSON.stringify(manifest,null,2)+'\n');
console.log(JSON.stringify(manifest));
