import assert from "node:assert/strict";
import { readFile } from "node:fs/promises";
import test from "node:test";
import {
  isNearPolicyBoundary,
  resolveFinancialWatchPolicy,
  resolveTrendModifier,
  scoreToPolicyBand,
  type PolicyBand,
  type PolicyMatrixInput,
  type PolicyRulebookRuntime,
} from "../lib/financial-watch-policy";

interface SourceCombination {
  id: string;
  matrix_state_codes: string[];
  policy_family_code: string;
  policy_family_title: string;
  policy_posture: string;
  severity: string;
  rule_trace: string;
  priority_actions: string[];
  guardrail: string;
  comprehensive_policy: string;
  comprehensive_diagnosis: string;
}

interface SourceRulebook {
  meta: { combinations: number };
  combinations: SourceCombination[];
}

const sourcePath = new URL("../data/policy/financial_watch_policy_rulebook_6561_fa.json", import.meta.url);
const runtimePath = new URL("../public/data/financial_watch_policy_runtime.json", import.meta.url);
const source = JSON.parse(await readFile(sourcePath, "utf8")) as SourceRulebook;
const runtime = JSON.parse(await readFile(runtimePath, "utf8")) as PolicyRulebookRuntime;

const REPRESENTATIVE_SCORE: Record<PolicyBand, number> = { weak: 2, medium: 5, good: 8 };
const CODE_TO_BAND: Record<string, PolicyBand> = { W: "weak", M: "medium", G: "good" };

function inputsFromCodes(codes: string[]): PolicyMatrixInput[] {
  return codes.map((code, index) => {
    const suffix = code.split("-")[1];
    return {
      matrix: (index + 1) as 1 | 2 | 3 | 4,
      xScore: REPRESENTATIVE_SCORE[CODE_TO_BAND[suffix[0]]],
      yScore: REPRESENTATIVE_SCORE[CODE_TO_BAND[suffix[1]]],
    };
  });
}

test("score bands use the exact Rule Book boundaries", () => {
  assert.equal(scoreToPolicyBand(3.329), "weak");
  assert.equal(scoreToPolicyBand(3.33), "medium");
  assert.equal(scoreToPolicyBand(6.659), "medium");
  assert.equal(scoreToPolicyBand(6.66), "good");
  assert.equal(scoreToPolicyBand(null), null);
  assert.equal(isNearPolicyBoundary(3.20), true);
  assert.equal(isNearPolicyBoundary(3.50), false);
  assert.equal(isNearPolicyBoundary(6.65), true);
  assert.equal(isNearPolicyBoundary(7.00), false);
});

test("all 6,561 four-matrix combinations resolve exactly to the source Rule Book", () => {
  assert.equal(source.meta.combinations, 6561);
  assert.equal(source.combinations.length, 6561);
  assert.equal(runtime.combinations.length, 6561);

  for (const expected of source.combinations) {
    const actual = resolveFinancialWatchPolicy(runtime, inputsFromCodes(expected.matrix_state_codes));
    assert.ok(actual, `ترکیب ${expected.id} حل نشد`);
    assert.equal(actual.combinationId, expected.id);
    assert.deepEqual(actual.matrixStateCodes, expected.matrix_state_codes);
    assert.equal(actual.familyCode, expected.policy_family_code);
    assert.equal(actual.family.title, expected.policy_family_title);
    assert.equal(actual.family.posture, expected.policy_posture);
    assert.equal(actual.severity, expected.severity);
    assert.equal(actual.ruleTrace, expected.rule_trace);
    assert.deepEqual(actual.priorityActions, expected.priority_actions);
    assert.equal(actual.guardrail, expected.guardrail);
    assert.equal(actual.comprehensivePolicy, expected.comprehensive_policy);
    assert.equal(actual.comprehensiveDiagnosis, expected.comprehensive_diagnosis);
  }
});

test("the engine refuses incomplete inputs instead of inventing a policy", () => {
  const inputs = inputsFromCodes(["M1-WW", "M2-MM", "M3-GG", "M4-MG"]);
  inputs[2].xScore = null;
  assert.equal(resolveFinancialWatchPolicy(runtime, inputs), null);
});

test("trend modifiers protect liquidity and financial-structure deterioration", () => {
  assert.equal(resolveTrendModifier(runtime, Array(8).fill(6), Array(8).fill(5), 0.25).modifier?.code, "T1");
  assert.equal(resolveTrendModifier(runtime, Array(8).fill(5.1), Array(8).fill(5), 0.25).modifier?.code, "T2");
  assert.equal(resolveTrendModifier(runtime, Array(8).fill(4), Array(8).fill(5), 0.25).modifier?.code, "T3");
  assert.equal(resolveTrendModifier(runtime, Array(8).fill(5), null, 0.25).modifier?.code, "T4");

  const previous = Array(8).fill(5);
  const currentWithLiquidityDrop = [6, 6, 6, 6, 0, 6, 6, 6];
  const guarded = resolveTrendModifier(runtime, currentWithLiquidityDrop, previous, 0.25);
  assert.equal(guarded.modifier?.code, "T5");
  assert.deepEqual(guarded.criticalAxisDrops, [4]);
  assert.ok((guarded.delta ?? 0) >= 0.25, "میانگین کل باید بهبود ظاهری نشان دهد تا گاردریل واقعاً آزموده شود");
});
