import assert from "node:assert/strict";
import test from "node:test";
import { buildAssetProductivity, buildInvestmentPoints, DEFAULT_INVESTMENT_WEIGHTS, type ProductionModel } from "../lib/investment-engine";
import type { FinancialModel, FinancialRecord } from "../lib/financial-engine";

const company = "آهن فولاد کاسپین";

function record(year: number, code: string, value: number | null, score: number | null = null): FinancialRecord {
  return {
    sourceRow: 1, nature: "بازرگانی", company, year, variable: code, normalizedVariable: code, code,
    unit: code === "152" ? "درصد" : "میلیون ریال", value, indexedValue: value, score,
    scoreIssue: score === null ? "missing" : null, natureImputed: false,
  };
}

function model(records: FinancialRecord[], years = [1403, 1404]): FinancialModel {
  const codeIndex = new Map<string, Map<number, Map<string, FinancialRecord>>>();
  const byYear = new Map<number, Map<string, FinancialRecord>>();
  for (const item of records) {
    const byCode = byYear.get(item.year) ?? new Map<string, FinancialRecord>();
    byCode.set(item.code, item);
    byYear.set(item.year, byCode);
  }
  codeIndex.set(company, byYear);
  return { companies: [company], years, codeIndex, validRecords: records } as unknown as FinancialModel;
}

const caspianRecords = [
  record(1404, "111", 8_028_567), record(1403, "134", 1_564_570), record(1404, "134", 2_620_565),
  record(1404, "152", 3.84, 7.404932552394582),
  record(1403, "128", 303_445), record(1404, "128", 749_596),
  record(1403, "129", 482_235), record(1404, "129", 705_440),
  record(1403, "130", 343_921), record(1404, "130", 693_620),
  record(1403, "132", 0), record(1404, "132", 0),
  record(1403, "127", 1_175), record(1404, "127", 1_175),
  record(1403, "125", 228_096), record(1404, "125", 344_159),
  record(1403, "126", 124), record(1404, "126", 0),
  record(1404, "165", 45), record(1404, "166", 130), record(1404, "167", 70), record(1404, "168", 105),
];

test("Caspian 1404 asset turnover and average asset composition reconcile", () => {
  const { result, warnings } = buildAssetProductivity(model(caspianRecords), company, 1404);
  assert.ok(result);
  assert.equal(result.averageTotalAssets, 2_092_567.5);
  assert.ok(Math.abs((result.rawTurnover ?? 0) - 3.8367063428) < 1e-8);
  assert.equal(result.storedTurnover, 3.84);
  assert.equal(result.turnoverScore / 10, 0.7404932552394582);
  assert.deepEqual(Object.fromEntries(result.assetComposition.map((item) => [item.key, item.amount])), {
    receivables: 593_837.5, inventory: 526_520.5, cash: 518_770.5,
    investments: 1_175, fixed: 286_189.5, other: 166_074.5,
  });
  assert.equal(result.reconciliationDifference, 0);
  assert.equal(result.reconciliationOk, true);
  assert.equal(warnings.length, 0);
});

test("Y uses only score 152 and never the raw turnover", () => {
  const capital = ["176", "150", "175", "144"].map((code) => record(1404, code, 1, 5));
  const points = buildInvestmentPoints(model([...caspianRecords, ...capital]), null, DEFAULT_INVESTMENT_WEIGHTS, "metil");
  const point = points.find((item) => item.year === 1404);
  assert.ok(point);
  assert.equal(point.verticalMetric, "asset-productivity");
  assert.equal(point.y, 0.7404932552394582);
  assert.notEqual(point.y, 3.84);
});

test("missing component is not treated as zero and stays in residual", () => {
  const incomplete = caspianRecords.filter((item) => item.code !== "129");
  const { result, warnings } = buildAssetProductivity(model(incomplete), company, 1404);
  assert.ok(result);
  assert.equal(result.assetComposition.find((item) => item.key === "receivables")?.amount, null);
  assert.equal(result.assetComposition.find((item) => item.key === "other")?.amount, 759_912);
  assert.ok(warnings.some((warning) => warning.includes("تفکیک بعضی اقلام")));
});

test("1405 point is absent without its own score 152", () => {
  const capital = ["176", "150", "175", "144"].map((code) => record(1404, code, 1, 5));
  const points = buildInvestmentPoints(model([...caspianRecords, ...capital], [1403, 1404, 1405]), null, DEFAULT_INVESTMENT_WEIGHTS, "metil");
  assert.ok(points.some((item) => item.year === 1404));
  assert.ok(!points.some((item) => item.year === 1405));
});

test("production company continues to use utilization", () => {
  const capital = ["176", "150", "175", "144"].map((code) => record(1404, code, 1, 5));
  const production: ProductionModel = {
    fileName: "production.xlsx", importedAt: "", companies: [company], years: [1404], issues: [],
    summary: { totalRows: 1, validRows: 1, companies: 1, years: 1, productionLines: 1, warnings: 0 },
    records: [{ sourceRow: 2, company, equipment: "خط اصلی", year: 1404, capacity: 100, production: 75, utilization: .75, grossMargin: null, salesRevenue: null }],
  };
  const points = buildInvestmentPoints(model([...caspianRecords, ...capital]), production, DEFAULT_INVESTMENT_WEIGHTS, "atieh");
  const point = points.find((item) => item.year === 1404);
  assert.ok(point);
  assert.equal(point.verticalMetric, "utilization");
  assert.equal(point.y, .75);
  assert.equal(point.assetProductivity, null);
});
