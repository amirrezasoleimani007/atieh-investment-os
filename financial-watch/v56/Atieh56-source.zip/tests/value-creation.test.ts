import assert from "node:assert/strict";
import test from "node:test";
import * as XLSX from "xlsx";
import { buildFinancialModel } from "../lib/financial-engine";
import { parseProfitWorkbook } from "../lib/profit-engine";
import {
  buildValueCreationAnalysis,
  buildCompanySpreadRanking,
  decomposeValueChange,
  runProductMarginScenario,
  runValueScenario,
  solveValueTarget,
  type ProductInsight,
  type ValueSnapshot,
} from "../lib/value-creation-engine";

const company = "آتیه تجارت نقش جهان قشم";
const headers = [
  "ماهیت",
  "شرکت",
  "سال",
  "متغیر",
  "کد متغیر",
  "واحد",
  "مقدار",
  "امتیاز",
  "نشان",
];

function row(year: number, code: string, value: number, unit = "میلیون ریال") {
  return {
    ماهیت: "بازرگانی",
    شرکت: company,
    سال: year,
    متغیر: `شاخص ${code}`,
    "کد متغیر": code,
    واحد: unit,
    مقدار: value,
    امتیاز: 5,
    نشان: value,
  };
}

test("reproduces the mandatory 1404 control company values", () => {
  const rows = [
    row(1403, "134", 6_100_000),
    row(1403, "130", 300_000),
    row(1403, "132", 159_492),
    row(1404, "134", 14_841_404),
    row(1404, "130", 302_676),
    row(1404, "132", 1_104_323),
    row(1404, "148", 691_383.353),
    row(1404, "179", 0.37082, "درصد"),
    row(1404, "182", 0.202896, "درصد"),
    row(1404, "111", 15_000_000),
    row(1404, "112", -13_000_000),
    row(1404, "129", 5_000_000),
    row(1404, "128", 3_000_000),
    row(1404, "118", 900_000),
    row(1404, "124", 650_000),
    row(1404, "165", 84, "روز"),
    row(1404, "166", 122, "روز"),
    row(1404, "167", 61, "روز"),
    row(1404, "168", 145, "روز"),
    row(1404, "152", 1.2, "نسبت"),
  ];
  const financial = buildFinancialModel(rows, headers, "control.xlsx");
  const analysis = buildValueCreationAnalysis(financial, null, company, 1404);
  assert.ok(analysis.selected);
  assert.equal(analysis.selected.beginningIc, 5_640_508);
  assert.equal(analysis.selected.endIc, 13_434_405);
  assert.equal(analysis.selected.averageIc, 9_537_456.5);
  assert.ok(Math.abs(analysis.selected.roic - 0.0724915) < 0.000001);
  assert.ok(Math.abs(analysis.selected.spread - -0.2983285) < 0.000001);
});

test("company spread ranking is descending, preserves zero and excludes other-year fallbacks", () => {
  const companyRows = (name: string, nopat: number, year = 1404) => [
    row(year - 1, "134", 1000), row(year - 1, "130", 0), row(year - 1, "132", 0),
    row(year, "134", 1000), row(year, "130", 0), row(year, "132", 0),
    row(year, "148", nopat), row(year, "179", 0.2, "درصد"),
    row(year, "111", 2000), row(year, "112", -1200), row(year, "129", 100), row(year, "128", 100),
  ].map((item) => ({ ...item, شرکت: name }));
  const financial = buildFinancialModel([
    ...companyRows("شرکت مثبت", 400), ...companyRows("شرکت منفی", 100),
    ...companyRows("شرکت صفر", 200), ...companyRows("فقط سال قبل", 500, 1403),
  ], headers, "ranking.xlsx");
  const ranked = buildCompanySpreadRanking(financial, null, null, "metil", 1404, "actual");
  assert.deepEqual(ranked.map((item) => item.company), ["شرکت مثبت", "شرکت صفر", "شرکت منفی", "فقط سال قبل"]);
  assert.deepEqual(ranked.map((item) => item.spread), [0.2, 0, -0.1, null]);
  assert.ok(buildCompanySpreadRanking(financial, null, null, "metil", 1402, "actual").every((item) => item.spread === null));
  assert.ok(buildCompanySpreadRanking(financial, null, null, "metil", 1405, "budget").every((item) => item.spread === null));
});

test("normalizes Profit COGS and isolates a mislabeled budget total", () => {
  const sheet = XLSX.utils.json_to_sheet([
    {
      شرکت: "پولای بهیز",
      سال: "بودجه 1405",
      واحد: "دلار",
      محصول: "محصول الف",
      "درآمد عملیاتی": 100,
      "بهای تمام شده درآمد عملیاتی": 60,
      "سود ناخالص": 40,
      " سود عملیاتی بودجه 1405 ": null,
      " سود خالص بودجه 1405 ": null,
    },
    {
      شرکت: "پولای بهیز",
      سال: 1402,
      واحد: "دلار",
      محصول: "جمع",
      "درآمد عملیاتی": 100,
      "بهای تمام شده درآمد عملیاتی": -60,
      "سود ناخالص": 40,
      " سود عملیاتی بودجه 1405 ": 20,
      " سود خالص بودجه 1405 ": 15,
    },
  ]);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, sheet, "Profit");
  const data = XLSX.write(workbook, {
    type: "array",
    bookType: "xlsx",
  }) as ArrayBuffer;
  const model = parseProfitWorkbook(data, "profit.xlsx");
  assert.equal(model.records[0].normalizedCogs, 60);
  assert.equal(model.records[0].calculatedGrossProfit, 40);
  assert.equal(model.records[1].year, 1405);
  assert.equal(model.records[1].yearLabelSuspect, true);
  assert.ok(model.issues.some((issue) => issue.type === "year-label"));
});

function snapshot(overrides: Partial<ValueSnapshot> = {}): ValueSnapshot {
  return {
    company,
    year: 1404,
    isEstimated: false,
    beginningIc: 900,
    endIc: 1100,
    averageIc: 1000,
    averageTotalAssets: 1200,
    averageReceivables: 280,
    averageInventory: 100,
    averageOtherIc: 620,
    nopat: 100,
    roic: 0.1,
    wacc: 0.2,
    spread: -0.1,
    taxRate: 0.2,
    revenue: 3650,
    cogs: -1825,
    grossProfit: 1825,
    receivables: 300,
    inventory: 120,
    operatingProfit: 125,
    netProfit: 90,
    dso: 28,
    dio: 20,
    dpo: 15,
    ccc: 33,
    assetTurnover: 1.5,
    ...overrides,
  };
}

test("DSO and DIO sensitivity reduce average IC directly", () => {
  const result = runValueScenario(snapshot(), 0, 10, 10, 0);
  assert.equal(result.releasedCapital, 150);
  assert.equal(result.newAverageIc, 850);
  assert.ok(Math.abs(result.roic - 100 / 850) < 1e-12);
});

test("an unrelated missing working-capital driver does not invalidate a profit scenario", () => {
  const result = runValueScenario(
    snapshot({ dso: null, dio: null }),
    1,
    0,
    0,
    0,
  );
  assert.equal(result.feasible, true);
  assert.equal(result.releasedCapital, 0);
  assert.ok(result.addedNopat > 0);
});

test("target solver rejects impossible single-driver DSO and DIO recommendations", () => {
  const result = solveValueTarget(snapshot(), 0);
  assert.equal(result.icReduction, 500);
  assert.equal(result.dso.feasible, false);
  assert.equal(result.dio.feasible, false);
  assert.ok((result.dso.theoretical ?? 0) > 28);
  assert.ok((result.dio.theoretical ?? 0) > 20);
});

test("Shapley profit and capital effects reconcile ROIC and Spread changes", () => {
  const previous = snapshot({
    year: 1403,
    nopat: 100,
    averageIc: 1000,
    roic: 0.1,
    wacc: 0.18,
    spread: -0.08,
  });
  const current = snapshot({
    year: 1404,
    nopat: 150,
    averageIc: 1200,
    roic: 0.125,
    wacc: 0.2,
    spread: -0.075,
  });
  const result = decomposeValueChange(previous, current);
  assert.ok(result);
  assert.ok(
    Math.abs(result.profitEffect + result.capitalEffect - result.roicChange) <
      1e-12,
  );
  assert.ok(
    Math.abs(
      result.profitEffect +
        result.capitalEffect -
        result.waccChange -
        result.spreadChange,
    ) < 1e-12,
  );
});

test("product margin sensitivity flows through gross profit, NOPAT, ROIC and Spread", () => {
  const product: ProductInsight = {
    sourceRow: 2,
    company,
    companyKey: company,
    rawYear: "1404",
    year: 1404,
    isBudget: false,
    yearLabelSuspect: false,
    unit: "میلیون ریال",
    product: "محصول الف",
    isTotal: false,
    revenue: 500,
    rawCogs: -350,
    normalizedCogs: 350,
    reportedGrossProfit: 150,
    calculatedGrossProfit: 150,
    calculatedGrossMargin: 0.3,
    budgetOperatingProfit: null,
    budgetNetProfit: null,
    grossProfitDifference: 0,
    revenueMix: 0.5,
    grossProfitContribution: 0.6,
  };
  const result = runProductMarginScenario(snapshot(), product, 2);
  assert.equal(result.addedGrossProfit, 10);
  assert.equal(result.addedNopat, 8);
  assert.ok(Math.abs(result.roic - 0.108) < 1e-12);
  assert.ok(Math.abs(result.spreadDelta - 0.008) < 1e-12);
  assert.equal(result.feasible, true);
});

test("budget estimate builds average IC from average AR, inventory and other IC", () => {
  const rows = [
    row(1403, "134", 1050),
    row(1403, "130", 40),
    row(1403, "132", 10),
    row(1404, "134", 1150),
    row(1404, "130", 40),
    row(1404, "132", 10),
    row(1404, "133", 1100),
    row(1404, "131", 50),
    row(1404, "125", 40),
    row(1404, "126", 0),
    row(1404, "127", 10),
    row(1404, "148", 100),
    row(1404, "179", 0.2, "درصد"),
    row(1404, "182", 0.2, "درصد"),
    row(1404, "111", 3650),
    row(1404, "112", -1825),
    row(1404, "113", 1825),
    row(1404, "129", 300),
    row(1404, "128", 120),
    row(1404, "118", 125),
    row(1404, "124", 90),
    row(1404, "165", 20, "روز"),
    row(1404, "166", 28, "روز"),
    row(1404, "167", 15, "روز"),
    row(1404, "168", 33, "روز"),
    row(1404, "152", 1.5, "نسبت"),
  ];
  const financial = buildFinancialModel(rows, headers, "budget-control.xlsx");
  const sheet = XLSX.utils.json_to_sheet([
    {
      شرکت: company,
      سال: "بودجه 1405",
      واحد: "میلیون ریال",
      محصول: "محصول الف",
      "درآمد عملیاتی": 7300,
      "بهای تمام شده درآمد عملیاتی": -3650,
      "سود ناخالص": 3650,
      " سود عملیاتی بودجه 1405 ": null,
      " سود خالص بودجه 1405 ": null,
    },
    {
      شرکت: company,
      سال: "بودجه 1405",
      واحد: "میلیون ریال",
      محصول: "جمع",
      "درآمد عملیاتی": 7300,
      "بهای تمام شده درآمد عملیاتی": -3650,
      "سود ناخالص": 3650,
      " سود عملیاتی بودجه 1405 ": 500,
      " سود خالص بودجه 1405 ": 350,
    },
  ]);
  const workbook = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(workbook, sheet, "Profit");
  const data = XLSX.write(workbook, {
    type: "array",
    bookType: "xlsx",
  }) as ArrayBuffer;
  const profit = parseProfitWorkbook(data, "profit-budget.xlsx");
  const analysis = buildValueCreationAnalysis(financial, profit, company, 1404);
  assert.ok(analysis.selected && analysis.budget);
  const expected =
    (7300 / 365) * 28 +
    (3650 / 365) * 20 +
    10 +
    40 +
    (1100 - 40 - 10 - 300 - 120) * 2;
  assert.ok(Math.abs(analysis.budget.averageIc - expected) < 1e-12);
});
