import assert from "node:assert/strict";
import test from "node:test";
import * as XLSX from "xlsx";
import { canonicalCompanyKey } from "../lib/company-resolver";
import { buildFinancialModel } from "../lib/financial-engine";
import {
  parseProfitWorkbook,
  type ProfitModel,
  type ProfitRecord,
} from "../lib/profit-engine";
import {
  buildPlanningScenarioSnapshot,
  buildScenarioAssetComposition,
} from "../lib/planning-scenario-engine";
import {
  buildCapitalBridge,
  buildProductRoicDrivers,
  buildManagementVerdict,
  calculateCapitalAllocationLimit,
  calculateGrowthEconomics,
  rankScenarioActions,
} from "../lib/planning-decision-engine";
import type { ValueSnapshot } from "../lib/value-creation-engine";
import { calibrateScenarioScore } from "../lib/scenario-score-engine";
import type { ProductionModel } from "../lib/investment-engine";
import { calculateCompanyUtilization } from "../lib/utilization-engine";

const company = "آهن فولاد کاسپین";
function row(
  code: number,
  value: number,
  score: number | null = null,
  year = 1404,
  companyName = company,
  nature = "بازرگانی/خدماتی",
) {
  return {
    ماهیت: nature,
    شرکت: companyName,
    سال: year,
    متغیر: String(code),
    "کد متغیر": code,
    واحد:
      code === 152
        ? "برابر"
        : [144, 150, 175, 176, 179, 182].includes(code)
          ? "درصد"
          : "میلیون ریال",
    مقدار: value,
    امتیاز: score,
    نشان: null,
  };
}
function financial() {
  const base = [
    [111, 8028567],
    [125, 344159],
    [126, 0],
    [127, 1175],
    [128, 749596],
    [129, 705440],
    [130, 693620],
    [131, 345334],
    [132, 0],
    [133, 2275231],
    [134, 2620565],
    [165, 26.72],
    [166, 27],
    [167, 57.64],
    [175, 0.02],
    [179, 0.384],
    [182, 0.21],
  ] as const;
  const calibration = [144, 150, 152, 176].flatMap((code) => [
    row(code, 0, 1, 1403),
    row(code, 1, 9, 1404),
  ]);
  const rows = [
    ...base.map(([code, value]) => row(code, value)),
    ...calibration,
  ];
  return buildFinancialModel(rows, Object.keys(rows[0]), "control.xlsx");
}
function profit(): ProfitModel {
  const rec: ProfitRecord = {
    sourceRow: 2,
    company,
    companyKey: canonicalCompanyKey(company),
    group: "فولاد متیل",
    holding: "metil",
    rawYear: "بودجه 1405",
    year: 1405,
    isBudget: true,
    yearLabelSuspect: false,
    unit: "میلیون ریال",
    product: "جمع",
    isTotal: true,
    revenue: 11496112.627367951,
    rawCogs: -9663241.425084203,
    normalizedCogs: 9663241.425084203,
    reportedGrossProfit: 1832871.2022837475,
    calculatedGrossProfit: 1832871.2022837475,
    calculatedGrossMargin: 0.1594339984,
    budgetOperatingProfit: 1557214.3272837475,
    budgetNetProfit: 1020266.4954628106,
    grossProfitDifference: 0,
  };
  return {
    fileName: "Profit.xlsx",
    importedAt: "",
    records: [rec],
    companies: [company],
    issues: [],
    summary: {
      rows: 1,
      validRows: 1,
      companies: 1,
      actualYears: [],
      budgetCompanies: 1,
      warnings: 0,
    },
  };
}

test("company resolver joins required spelling aliases", () => {
  assert.equal(
    canonicalCompanyKey("حدیدکاران لرستان"),
    canonicalCompanyKey("حدید کاران لرستان"),
  );
  assert.equal(
    canonicalCompanyKey("فولاد فرایند متیل کویر"),
    canonicalCompanyKey("فولاد فرآیند متیل کویر"),
  );
});

test("Profit group is parsed and gross mismatch uses computed amount", () => {
  const ws = XLSX.utils.json_to_sheet([
    {
      شرکت: "صنایع آهن و فولاد توس",
      سال: "بودجه 1405",
      واحد: "میلیون ریال",
      محصول: "جمع",
      "درآمد عملیاتی": 19110380,
      "بهای تمام شده درآمد عملیاتی": -14675147,
      "سود ناخالص": 319,
      "سود عملیاتی بودجه 1405": 4185833,
      "سود خالص بودجه 1405": 3375999,
      گروه: "فولاد متیل",
    },
  ]);
  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
  const bytes = XLSX.write(wb, {
    type: "array",
    bookType: "xlsx",
  }) as ArrayBuffer;
  const model = parseProfitWorkbook(bytes, "Profit.xlsx"),
    total = model.records[0];
  assert.equal(total.holding, "metil");
  assert.equal(total.calculatedGrossProfit, 4435233);
  assert.equal(total.reportedGrossProfit, 319);
  assert.ok(
    model.issues.some((issue) => issue.type === "gross-profit-mismatch"),
  );
});

test("Caspian 1405 schedule, CCC, NOPAT, ROIC, Spread and turnover reconcile", () => {
  const s = buildPlanningScenarioSnapshot(
    financial(),
    profit(),
    null,
    "metil",
    company,
  )!;
  assert.ok(s);
  assert.ok(Math.abs(s.assetSchedule.receivables - 850397.3724) < 0.01);
  assert.ok(Math.abs(s.assetSchedule.inventory - 707402.2216) < 0.01);
  assert.ok(Math.abs(s.assetSchedule.otherCurrentAssets - 181242.8614) < 0.01);
  assert.ok(Math.abs(s.assetSchedule.averageTotalAssets - 2777996.4554) < 0.01);
  assert.ok(
    Math.abs(s.assetSchedule.averageInvestedCapital - 2084376.4554) < 0.01,
  );
  assert.ok(Math.abs(s.assetTurnover - 4.13827476) < 1e-7);
  assert.ok(Math.abs(s.nopat - 1230199.3186) < 0.01);
  assert.ok(Math.abs(s.roic - 0.59020016) < 1e-7);
  assert.ok(Math.abs(s.spread - 0.20620016) < 1e-7);
  assert.notEqual(s.revenueGrowth,null);
  assert.ok(Math.abs(s.revenueGrowth! - 0.43190094) < 1e-7);
  assert.ok(Math.abs(s.ccc + 3.92) < 1e-9);
  assert.equal(s.assetSchedule.cash, 693620);
});

test("product budget lines are ranked by comparable one-point ROIC sensitivity", () => {
  const s = buildPlanningScenarioSnapshot(financial(), profit(), null, "metil", company)!;
  const makeDetail = (productName: string, revenue: number, grossProfit: number): ProfitRecord => ({
    ...profit().records[0], sourceRow: revenue, product: productName, isTotal: false,
    revenue, normalizedCogs: revenue - grossProfit, calculatedGrossProfit: grossProfit,
    calculatedGrossMargin: grossProfit / revenue,
  });
  const drivers = buildProductRoicDrivers(s, [
    makeDetail("محصول کوچک", 100_000, 20_000),
    makeDetail("محصول بزرگ", 500_000, 75_000),
  ]);
  assert.equal(drivers[0].label, "محصول بزرگ");
  assert.equal(drivers[0].marginDeltaPp, 1);
  assert.ok(Math.abs(drivers[0].addedNopat - 3_950) < 1e-9);
  assert.ok(Math.abs(drivers[0].roicGain - 3_950 / s.assetSchedule.averageInvestedCapital) < 1e-12);
  assert.ok(Math.abs(drivers.reduce((sum, row) => sum + row.sensitivityShare, 0) - 1) < 1e-12);
});

test("scenario score is monotonic and clamps outside calibration", () => {
  const m = financial();
  const middle = calibrateScenarioScore(m, company, "metil", "144", 0.5),
    high = calibrateScenarioScore(m, company, "metil", "144", 5);
  assert.ok(middle.score !== null && high.score !== null);
  assert.ok(middle.score! <= high.score!);
  assert.equal(high.score, 10);
  assert.equal(middle.scoreSource, "frozen-linear");
  assert.deepEqual(middle.calibrationYears, [1403, 1404]);
});

test("frozen score uses piecewise fallback and company-only carry-forward", () => {
  const rows = [
    row(144, 0, 1, 1401), row(144, 1, 7, 1402), row(144, 2, 8, 1403),
    row(150, .2, 6, 1404),
    row(144, 1, 10, 1404, "شرکت دیگر"),
  ];
  const model = buildFinancialModel(rows, Object.keys(rows[0]), "frozen.xlsx");
  const piecewise = calibrateScenarioScore(model, company, "metil", "144", 1.5);
  assert.equal(piecewise.scoreSource, "frozen-piecewise");
  assert.equal(piecewise.score, 7.5);
  assert.ok(piecewise.calibrationYears.every((year) => year <= 1404));
  const carry = calibrateScenarioScore(model, company, "metil", "150", .9);
  assert.equal(carry.scoreSource, "carry-forward");
  assert.equal(carry.score, 6);
});

test("Product 1405 utilization drives Y but financial turnover remains available", () => {
  const p: ProductionModel = {
    fileName: "Product.xlsx",
    importedAt: "",
    companies: [company],
    years: [1405],
    issues: [],
    summary: {
      totalRows: 1,
      validRows: 1,
      companies: 1,
      years: 1,
      productionLines: 1,
      warnings: 0,
    },
    records: [
      {
        sourceRow: 2,
        company,
        equipment: "خط",
        year: 1405,
        capacity: 660000,
        production: 510000,
        utilization: 510000 / 660000,
        grossMargin: 0.0884,
        salesRevenue: null,
      },
    ],
  };
  const s = buildPlanningScenarioSnapshot(
    financial(),
    profit(),
    p,
    "atieh",
    company,
  );
  assert.equal(
    s,
    null,
    "group routing prevents Metil Profit from entering Atieh",
  );
  const atiehProfit = {
    ...profit(),
    records: profit().records.map((r) => ({
      ...r,
      group: "آتیه فولاد",
      holding: "atieh" as const,
    })),
  };
  const a = buildPlanningScenarioSnapshot(
    financial(),
    atiehProfit,
    p,
    "atieh",
    company,
  )!;
  assert.ok(Math.abs((a.utilization ?? 0) - 0.77272727) < 1e-8);
  assert.equal(a.map.y, a.utilization);
  assert.ok(a.assetTurnover > 0);
});

test("Atieh Sanat utilization uses 30/70 product weighting", () => {
  const result = calculateCompanyUtilization("آتیه صنعت افق نقش جهان", [
    { sourceRow: 1, company: "آتیه صنعت افق نقش جهان", equipment: "بنتونیت", year: 1405, capacity: 72000, production: 31000 },
    { sourceRow: 2, company: "آتیه صنعت افق نقش جهان", equipment: "کوردوایر ۱", year: 1405, capacity: 3000, production: 3000 },
    { sourceRow: 3, company: "آتیه صنعت افق نقش جهان", equipment: "کوردوایر ۲", year: 1405, capacity: 3000, production: 2500 },
  ]);
  assert.ok(Math.abs(result.value! - 0.7708333333333333) < 1e-12);
  assert.equal(result.groups[0].weight, 0.3);
  assert.equal(result.groups[1].weight, 0.7);
});

test("both release treatments preserve the required balance-sheet behavior", () => {
  const f = financial(),
    p = profit();
  const base = buildPlanningScenarioSnapshot(f, p, null, "metil", company)!;
  const retained = buildPlanningScenarioSnapshot(f, p, null, "metil", company, {
    dsoReduction: 5,
    dioReduction: 5,
    releaseTreatment: "cash-retained",
  })!;
  const exits = buildPlanningScenarioSnapshot(f, p, null, "metil", company, {
    dsoReduction: 5,
    dioReduction: 5,
    releaseTreatment: "cash-exits",
  })!;
  assert.ok(
    Math.abs(
      retained.assetSchedule.averageTotalAssets -
        base.assetSchedule.averageTotalAssets,
    ) < 1e-6,
  );
  assert.ok(
    retained.assetSchedule.averageInvestedCapital <
      base.assetSchedule.averageInvestedCapital,
  );
  assert.ok(Math.abs(retained.assetTurnover - base.assetTurnover) < 1e-9);
  assert.ok(
    exits.assetSchedule.averageTotalAssets <
      base.assetSchedule.averageTotalAssets,
  );
  assert.ok(exits.assetTurnover > base.assetTurnover);
});

test("scenario asset composition exactly reconciles to the 1405 schedule", () => {
  const s = buildPlanningScenarioSnapshot(
    financial(),
    profit(),
    null,
    "metil",
    company,
  )!;
  const composition = buildScenarioAssetComposition(s.assetSchedule);
  assert.equal(composition.length, 6);
  assert.ok(
    Math.abs(
      composition.reduce((sum, item) => sum + item.amount, 0) -
        s.assetSchedule.averageTotalAssets,
    ) < 1e-9,
  );
  assert.ok(
    Math.abs(composition.reduce((sum, item) => sum + item.share, 0) - 1) <
      1e-12,
  );
});

test("missing operating profit or tax never becomes an assumed zero", () => {
  const missingProfit = {
    ...profit(),
    records: profit().records.map((item) => ({
      ...item,
      budgetOperatingProfit: null,
    })),
  };
  assert.equal(
    buildPlanningScenarioSnapshot(
      financial(),
      missingProfit,
      null,
      "metil",
      company,
    ),
    null,
  );
  const missingTax = financial();
  missingTax.codeIndex.get(company)?.get(1404)?.delete("182");
  assert.equal(
    buildPlanningScenarioSnapshot(missingTax, profit(), null, "metil", company),
    null,
  );
});

test("budget unit guard rejects Profit amounts incompatible with Financial", () => {
  const mismatched = { ...profit(), records: profit().records.map((item) => ({ ...item, unit: "دلار" })) };
  assert.equal(buildPlanningScenarioSnapshot(financial(), mismatched, null, "metil", company), null);
});

test("growth economics, capital bridge, ranking and management verdict are controlled", () => {
  const budget = buildPlanningScenarioSnapshot(
    financial(),
    profit(),
    null,
    "metil",
    company,
  )!;
  const margin = buildPlanningScenarioSnapshot(
    financial(),
    profit(),
    null,
    "metil",
    company,
    { operatingMarginDelta: 0.01 },
  )!;
  const dso = buildPlanningScenarioSnapshot(
    financial(),
    profit(),
    null,
    "metil",
    company,
    { dsoReduction: 10, releaseTreatment: "cash-retained" },
  )!;
  const actual: ValueSnapshot = {
    company,
    year: 1404,
    isEstimated: false,
    beginningIc: 1_800_000,
    endIc: 2_000_000,
    averageIc: 1_900_000,
    averageTotalAssets: 2_600_000,
    averageReceivables: 700_000,
    averageInventory: 700_000,
    averageOtherIc: 500_000,
    nopat: 1_000_000,
    roic: 1_000_000 / 1_900_000,
    wacc: 0.384,
    spread: 1_000_000 / 1_900_000 - 0.384,
    taxRate: 0.21,
    revenue: 8_028_567,
    cogs: -7_000_000,
    grossProfit: 1_028_567,
    receivables: 705_440,
    inventory: 749_596,
    operatingProfit: 1_265_823,
    netProfit: 900_000,
    dso: 27,
    dio: 26.72,
    dpo: 57.64,
    ccc: -3.92,
    assetTurnover: 3.08,
  };
  const economics = calculateGrowthEconomics(actual, budget);
  assert.equal(economics.capitalState, "added");
  assert.ok(economics.incrementalReturn !== null);
  const expectedComparableNopat = actual.operatingProfit! * (1 - actual.taxRate);
  assert.equal(economics.comparableActualNopat, expectedComparableNopat);
  assert.equal(economics.deltaNopat, budget.nopat - expectedComparableNopat);
  const bridge = buildCapitalBridge(actual, budget);
  assert.ok(Math.abs(bridge.reconciliationDifference) < 1e-9);
  const ranked = rankScenarioActions(budget, [
    { key: "dso", label: "DSO", snapshot: dso },
    { key: "margin", label: "Margin", snapshot: margin },
  ]);
  assert.ok(ranked[0].spreadGain >= ranked[1].spreadGain);
  const limit = calculateCapitalAllocationLimit(budget);
  assert.equal(limit.economicCapitalLimit, budget.nopat / budget.wacc);
  assert.ok(Math.abs(limit.capitalGap! - (budget.assetSchedule.averageInvestedCapital - limit.economicCapitalLimit!)) < 1e-9);
  const verdict = buildManagementVerdict(
    actual,
    budget,
    margin,
    buildScenarioAssetComposition(budget.assetSchedule),
    economics,
    ranked[0],
  );
  assert.ok(verdict.length >= 3 && verdict.length <= 4);
  assert.ok(verdict.some((line) => line.includes("اولویت نخست")));
});
