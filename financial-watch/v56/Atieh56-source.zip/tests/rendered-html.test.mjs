import assert from "node:assert/strict";
import { readFile, stat } from "node:fs/promises";
import test from "node:test";

const developmentPreviewMeta =
  /<meta(?=[^>]*\bname=["']codex-preview["'])(?=[^>]*\bcontent=["']development["'])[^>]*>/i;

test("renders production metadata without a development preview marker", async () => {
  const workerUrl = new URL("../dist/server/index.js", import.meta.url);
  workerUrl.searchParams.set("test", `${process.pid}-${Date.now()}`);
  const { default: worker } = await import(workerUrl.href);

  const response = await worker.fetch(
    new Request("http://localhost/", {
      headers: { accept: "text/html" },
    }),
    {
      ASSETS: {
        fetch: async () => new Response("Not found", { status: 404 }),
      },
    },
    {
      waitUntil() {},
      passThroughOnException() {},
    },
  );

  assert.equal(response.status, 200);
  assert.match(
    response.headers.get("content-type") ?? "",
    /^text\/html\b/i,
  );
  assert.doesNotMatch(await response.text(), developmentPreviewMeta);
});

test("investment analysis exposes the value-creation engine and controlled Profit import", async () => {
  const dashboard = await readFile(new URL("../app/dashboard-app.tsx", import.meta.url), "utf8");
  const investment = await readFile(new URL("../components/investment-analysis.tsx", import.meta.url), "utf8");
  const valueCreationUi = await readFile(new URL("../components/value-creation-engine.tsx", import.meta.url), "utf8");
  const engine = await readFile(new URL("../lib/value-creation-engine.ts", import.meta.url), "utf8");

  assert.match(dashboard, /parseProfitWorkbook/);
  assert.match(dashboard, /دیتابیس سود و بودجه \(Profit\)/);
  assert.match(investment, /موتور ارزش‌آفرینی/);
  assert.match(valueCreationUi, /موتور ارزش‌آفرینی · عملکرد واقعی/);
  assert.match(valueCreationUi, /مقایسه سودها مستقل از مقیاس درآمد/);
  assert.match(valueCreationUi, /بازگشت به حالت پایه/);
  assert.match(valueCreationUi, /BASE_SCENARIO/);
  assert.match(valueCreationUi, /وضعیت.*علت.*جزء.*اقدام.*هدف/s);
  assert.match(valueCreationUi, /runProductMarginScenario/);
  assert.match(engine, /"134"/);
  assert.match(engine, /"130"/);
  assert.match(engine, /"132"/);
  assert.match(engine, /"148"/);
  assert.match(engine, /"179"/);
  assert.match(engine, /snapshot\.averageIc - releasedCapital/);
  assert.match(engine, /decomposeValueChange/);
  assert.match(engine, /dsoTheory/);
  assert.match(engine, /dioTheory/);
  assert.match(engine, /addedGrossProfit/);
});

test("financial watch uses the immutable 6,561-combination policy Rule Book", async () => {
  const dashboard = await readFile(new URL("../app/dashboard-app.tsx", import.meta.url), "utf8");
  const policyUi = await readFile(new URL("../components/financial-watch-policy.tsx", import.meta.url), "utf8");
  const policyEngine = await readFile(new URL("../lib/financial-watch-policy.ts", import.meta.url), "utf8");
  const generator = await readFile(new URL("../scripts/build-policy-rulebook.mjs", import.meta.url), "utf8");
  const buildScript = await readFile(new URL("../scripts/build-verified.sh", import.meta.url), "utf8");
  const pagesPackager = await readFile(new URL("../scripts/package-github-pages.mjs", import.meta.url), "utf8");

  assert.match(dashboard, /<FinancialWatchPolicy/);
  assert.match(policyUi, /قاعده‌محور و قابل ردیابی/);
  assert.match(policyUi, /سه اقدام نخست/);
  assert.match(policyUi, /محدودیت و اقدام احتیاطی/);
  assert.match(policyUi, /جمع‌بندی مدیریتی وضعیت/);
  assert.match(policyUi, /نزدیک مرز/);
  assert.match(policyEngine, /criticalAxisIndices = \[4, 5\]/);
  assert.match(generator, /comprehensive_diagnosis/);
  assert.match(policyEngine, /offset \* 9 \+ position/);
  assert.match(generator, /6561/);
  assert.match(generator, /deterministic base-9 order/);
  assert.match(buildScript, /build-policy-rulebook\.mjs/);
  assert.match(policyUi, /financial_watch_policy_runtime\.manifest\.json/);
  assert.match(pagesPackager, /policyPartNames/);
});

test("ships the Excel reader inside the dashboard bundle", async () => {
  const manifest = JSON.parse(
    await readFile(new URL("../dist/client/.vite/manifest.json", import.meta.url), "utf8"),
  );
  const dashboard = manifest["app/dashboard-app.tsx"];

  assert.ok(dashboard, "dashboard entry is missing from the client manifest");
  assert.ok(
    !(dashboard.dynamicImports ?? []).some((entry) => /(^|\/)xlsx(\/|$)/i.test(entry)),
    "xlsx must not be fetched as a lazy chunk after a user selects a file",
  );

  const dashboardAsset = new URL(`../dist/client/${dashboard.file}`, import.meta.url);
  assert.ok((await stat(dashboardAsset)).size > 500_000, "Excel reader is not embedded in the dashboard asset");
  assert.match(await readFile(dashboardAsset, "utf8"), /0\.18\.5/);
});

test("keeps both holding databases in memory and exposes a dashboard switch", async () => {
  const source = await readFile(new URL("../app/dashboard-app.tsx", import.meta.url), "utf8");

  assert.match(source, /type HoldingModels = Record<HoldingSelection, FinancialModel \| null>/);
  assert.match(source, /role="tablist" aria-label="انتخاب هلدینگ برای نمایش"/);
  assert.match(source, /models=\{models\}/);
  assert.match(source, /onFile=\{\(file\) => handleFile\(holding, file\)\}/);
});

test("scatter points expose analytical hover details and every axis has code-based formula help", async () => {
  const source = await readFile(new URL("../components/scatter-chart.tsx", import.meta.url), "utf8");
  const engine = await readFile(new URL("../lib/financial-engine.ts", import.meta.url), "utf8");

  const tooltipStart = source.indexOf("function TooltipContent");
  const tooltipEnd = source.indexOf("export default function ScatterChart");
  const tooltipSource = source.slice(tooltipStart, tooltipEnd);

  assert.match(tooltipSource, /<strong>\{point\.company\}<\/strong>/);
  assert.match(tooltipSource, /point\.year/);
  assert.match(tooltipSource, /point\.regionTitle/);
  assert.match(tooltipSource, /component\.originalWeight/);
  assert.match(source, /axisHelp\("x", definition\.xLabel, xFormula\)/);
  assert.match(source, /axisHelp\("y", definition\.yLabel, yFormula\)/);
  assert.match(source, /AXIS_FORMULAS/);
  assert.match(source, /axis-component-row/);
  assert.match(source, /component\.originalWeight/);
  assert.match(source, /فرمول نهایی/);
  assert.match(source, /۰٫۵۵ × رشد درآمد \+ ۰٫۴۵ × رشد سود عملیاتی/);
  assert.match(source, /۰٫۶۰ × حاشیه FCF \+ ۰٫۴۰ × FCF\/EBITDA/);

  for (const code of ["144", "186", "146", "178", "152", "154", "176", "151", "164", "163", "173", "174", "155", "162", "169", "175", "170"]) {
    assert.match(engine, new RegExp(`scatterCodeComponent\\(model, company, year, "${code}"`));
  }
  assert.match(engine, /"phase1"/);
  assert.match(engine, /"phase2"/);
  assert.match(engine, /"phase3"/);
  assert.match(engine, /"phase4"/);
  assert.match(engine, /وزن‌ها بازتوزیع نمی‌شوند/);
});

test("dynamic ranking uses the six-dimension thirteen-indicator model", async () => {
  const engine = await readFile(new URL("../lib/dynamic-ranking-engine.ts", import.meta.url), "utf8");
  const page = await readFile(new URL("../components/dynamic-ranking.tsx", import.meta.url), "utf8");

  for (const code of ["144", "186", "187", "146", "176", "162", "175", "169", "174", "173", "164", "152", "168"]) {
    assert.match(engine, new RegExp(`code: "${code}"`));
  }
  assert.equal((engine.match(/baseWeight: 0\.2/g) ?? []).length, 3);
  assert.equal((engine.match(/baseWeight: 0\.15/g) ?? []).length, 2);
  assert.equal((engine.match(/baseWeight: 0\.1,/g) ?? []).length, 1);
  assert.match(engine, /MINIMUM_DIMENSION_COVERAGE = 0\.6/);
  assert.match(engine, /VALID_SCORE_COVERAGE = 0\.75/);
  assert.match(engine, /denseRanks/);
  assert.match(engine, /row\.validity === "valid"/);
  assert.match(engine, /Math\.abs\(scoreDifference\) > 1e-12/);
  assert.match(engine, /blendScenarioWeights/);
  assert.match(engine, /redistributeRankingWeight/);
  assert.match(page, /وزن‌دهی گرافیکی و زنده/);
  assert.match(page, /اثر وزن‌های فعال بر جایگاه شرکت‌ها/);
  assert.match(page, /مدل شش‌بُعدی مالی/);
  assert.match(page, /خروجی Excel/);
  assert.match(page, /MetricGuide/);
  assert.match(page, /وزن بُعد/);
  assert.match(page, /وزن داخلی شاخص/);
});

test("financial data center provides contextual tasks and immediate chart values", async () => {
  const dashboard = await readFile(new URL("../app/dashboard-app.tsx", import.meta.url), "utf8");

  assert.match(dashboard, /data-category-chips/);
  assert.match(dashboard, /data-guide-step/);
  assert.match(dashboard, /data-point-tooltip/);
  assert.match(dashboard, /onPointerEnter=\{\(event\) => showPoint/);
  assert.match(dashboard, /شرکت و سال را انتخاب کنید/);
  assert.match(dashboard, /مقایسه رو‌در‌رو بسازید/);
});

test("financial workbook import detects the data sheet and header row", async () => {
  const parser = await readFile(new URL("../lib/workbook-parser.ts", import.meta.url), "utf8");

  assert.match(parser, /workbook\.SheetNames\.flatMap/);
  assert.match(parser, /HEADER_SCAN_LIMIT = 30/);
  assert.match(parser, /matchedRequiredColumnCount/);
  assert.match(parser, /selected\.headerRowIndex \+ 2/);
});

test("market portfolio matrix is optional, validated and connected to live ranking rows", async () => {
  const dashboard = await readFile(new URL("../app/dashboard-app.tsx", import.meta.url), "utf8");
  const ranking = await readFile(new URL("../components/dynamic-ranking.tsx", import.meta.url), "utf8");
  const matrix = await readFile(new URL("../components/strategic-portfolio-matrix.tsx", import.meta.url), "utf8");
  const marketEngine = await readFile(new URL("../lib/market-engine.ts", import.meta.url), "utf8");

  assert.match(dashboard, /دیتابیس ارزیابی بازار/);
  assert.match(dashboard, /marketModel=\{marketModel\}/);
  assert.match(dashboard, /enableStrategicMatrix=\{holding === "atieh"\}/);
  assert.match(ranking, /rows=\{currentRows\}/);
  assert.match(matrix, /ماتریس راهبردی پرتفوی/);
  assert.match(matrix, /activeFinancialScore\(row, financialSelection\)/);
  assert.match(matrix, /financialAverage/);
  assert.match(matrix, /marketAverage/);
  assert.match(matrix, /percentileMidrank/);
  assert.match(matrix, /spreadHalfSpan/);
  assert.match(matrix, /دامنه پراکندگی نقاط/);
  assert.match(matrix, /const ONE_THIRD = 10 \/ 3/);
  assert.match(matrix, /const TWO_THIRDS = 20 \/ 3/);
  assert.match(matrix, /radius: 14/);
  assert.match(matrix, /جایگاه نمایشی مالی/);
  assert.match(matrix, /جایگاه نمایشی بازار/);
  assert.doesNotMatch(matrix, /matrix-hover-tooltip/);
  assert.match(matrix, /برای مشاهده جزئیات کامل شرکت، روی نقطه کلیک کنید/);
  assert.match(matrix, /drawer-company-title/);
  assert.match(matrix, /MarketRadar/);
  assert.match(matrix, /STRATEGIES/);
  assert.equal((matrix.match(/financial: "/g) ?? []).length, 9);
  assert.match(marketEngine, /canonicalCompanyName/);
  assert.match(marketEngine, /score < 0 \|\| score > 10/);
  assert.match(marketEngine, /بخش «.*» تکراری است/);
  assert.match(marketEngine, /ردیف «کل» موجود نیست/);
  for (const sourceLabel of ["اندازه و ضرورت", "رشد و آینده", "پایداری و تنوع", "رقابت و ورود", "توسعه و ریسک"]) {
    assert.match(marketEngine, new RegExp(sourceLabel));
  }
});

test("home and global exports use the official baseline ranking model", async () => {
  const performance = await readFile(new URL("../lib/performance-engine.ts", import.meta.url), "utf8");
  const dashboard = await readFile(new URL("../app/dashboard-app.tsx", import.meta.url), "utf8");

  assert.match(performance, /buildDynamicRanking\(model, year, BASE_RANKING_WEIGHTS\)/);
  assert.doesNotMatch(performance, /function activeWeights/);
  assert.match(dashboard, /امتیاز رسمی سالانه/);
  assert.doesNotMatch(dashboard, /امتیاز سالانه سفارشی/);
});
