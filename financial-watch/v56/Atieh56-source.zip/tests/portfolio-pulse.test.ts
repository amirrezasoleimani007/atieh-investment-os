import assert from "node:assert/strict";
import test from "node:test";
import { aggregatePortfolioRows, decomposeCompanyRoicChange, type PortfolioPulseCompany } from "../lib/portfolio-pulse-engine";

const row = (company: string, ic: number, nopat: number, wacc: number): PortfolioPulseCompany => {
  const roic = nopat / ic;
  return { company, period: "actual", year: 1404, investedCapital: ic, beginningInvestedCapital: ic, endingInvestedCapital: ic, nopat, operatingProfit: nopat, taxRate: 0, netProfit: nopat, roic, wacc, spread: roic - wacc, economicProfit: nopat - ic * wacc };
};

test("portfolio ROIC and WACC use invested-capital weighting", () => {
  const result = aggregatePortfolioRows([
    row("شرکت بزرگ", 900, 180, .10),
    row("شرکت کوچک", 100, 40, .30),
  ])!;
  assert.equal(result.investedCapital, 1000);
  assert.equal(result.nopat, 220);
  assert.equal(result.netProfit, 220);
  assert.equal(result.netProfitCompanyCount, 2);
  assert.ok(Math.abs(result.roic - .22) < 1e-12);
  assert.ok(Math.abs(result.wacc - .12) < 1e-12);
  assert.ok(Math.abs(result.spread - .10) < 1e-12);
  assert.equal(result.economicProfit, 100);
});

test("missing net profit is excluded instead of being treated as zero", () => {
  const available = row("دارای سود", 500, 100, .10);
  const missing = { ...row("فاقد داده سود", 500, 50, .10), netProfit: null };
  const result = aggregatePortfolioRows([available, missing])!;
  assert.equal(result.netProfit, 100);
  assert.equal(result.netProfitCompanyCount, 1);
});

test("capital quality separates positive and negative spread companies", () => {
  const result = aggregatePortfolioRows([
    row("ارزش‌آفرین", 600, 120, .10),
    row("ارزش‌زدا", 400, 20, .10),
  ])!;
  assert.equal(result.valueCreatingCapital, 600);
  assert.equal(result.valueDestroyingCapital, 400);
  assert.equal(result.valueCreatingShare, .6);
});

test("NOPAT and capital effects exactly reconcile company ROIC change", () => {
  const previous = row("شرکت", 1000, 100, .1);
  const current = row("شرکت", 800, 120, .1);
  const result = decomposeCompanyRoicChange(previous, current)!;
  assert.ok(Math.abs(result.total - (current.roic - previous.roic)) < 1e-12);
  assert.ok(Math.abs(result.controlDifference) < 1e-12);
});
