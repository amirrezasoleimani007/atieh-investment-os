import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, existsSync } from 'node:fs';
import * as XLSX from 'xlsx';
import { buildFinancialModel, buildAxisMatrix, DEFAULT_SETTINGS } from '../lib/financial-engine';
import { parseReportPeriod, selectReportModel } from '../lib/report-period';
import { buildValueCreationAnalysis } from '../lib/value-creation-engine';
import { scoreCompanyYear, BASE_RANKING_WEIGHTS } from '../lib/dynamic-ranking-engine';
import { serializeWorkspace, deserializeWorkspace } from '../lib/data-reliability';

const inputPath = process.env.IPS_INTERIM_WORKBOOK ?? '../upload/2.Metil.xlsx';
const hasInput = existsSync(inputPath);
const workbook = hasInput ? XLSX.read(readFileSync(inputPath)) : null;
const rows = workbook ? XLSX.utils.sheet_to_json<Record<string, unknown>>(workbook.Sheets[workbook.SheetNames[0]], {defval:null}) : [];
const headers = Object.keys(rows[0] ?? {});
const source = buildFinancialModel(rows, headers, '2.Metil.xlsx');
const annual = selectReportModel(source, 'annual');
const interim = selectReportModel(source, 'half-year');

test('period keys cannot collide, and unsupported periods are rejected', () => {
 assert.equal(parseReportPeriod('1404'),1404);
 assert.equal(parseReportPeriod('۱۴۰۴-۰۶'),140406);
 assert.equal(parseReportPeriod('1405/06'),140506);
 assert.equal(parseReportPeriod('1404-09'),null);
 assert.equal(parseReportPeriod(140406),140406);
});
test('real file isolates every annual/interim observation and score', {skip: !hasInput}, () => {
 assert.deepEqual(interim.years,[1404,1405]);
 assert.equal(interim.companies.length,22);
 assert.equal(interim.validRecords.length,3381);
 assert.ok(annual.years.every(y=>y<=1404));
 for(const r of interim.validRecords){
  const original=source.validRecords.find(x=>x.company===r.company&&x.year===r.year*100+6&&x.code===r.code);
  assert.ok(original);
  assert.equal(r.value,original.value);assert.equal(r.score,original.score);
 }
 const annualOnly=buildFinancialModel(rows.filter(r=>!String(r['سال']).includes('-')),headers,'annual');
 assert.deepEqual(annual.validRecords.map(r=>[r.company,r.year,r.code,r.value,r.score]),annualOnly.validRecords.map(r=>[r.company,r.year,r.code,r.value,r.score]));
});
test('axis and ranking histories contain only the chosen report family', {skip: !hasInput}, () => {
 const matrix=buildAxisMatrix(interim,DEFAULT_SETTINGS);
 for(const years of matrix.values()) assert.ok([...years.keys()].every(y=>[1404,1405].includes(y)));
 const company=interim.companies[0];
 assert.equal(scoreCompanyYear(interim,company,1403,BASE_RANKING_WEIGHTS).score,null);
});
test('interim ROIC uses prior December opening, and equivalent half-year WACC', {skip: !hasInput}, () => {
 let count=0;
 for(const company of interim.companies){
  const result=buildValueCreationAnalysis(interim,null,company,1405);
  const s=result.selected;if(!s)continue;count++;
  const v=(m:typeof annual,y:number,c:string)=>m.codeIndex.get(company)?.get(y)?.get(c)?.value ?? null;
  const opening=v(annual,1404,'134')!-v(annual,1404,'130')!-v(annual,1404,'132')!;
  assert.equal(s.beginningIc,opening);
  assert.equal(s.periodDays,186);
  assert.equal(s.roic,s.nopat/s.averageIc);
  assert.ok(Math.abs(s.wacc-(Math.sqrt(1+v(interim,1405,'179')!)-1))<1e-12);
  assert.equal(result.budget,null);
  assert.ok(result.actuals.every(x=>[1404,1405].includes(x.year)));
 }
 assert.ok(count>0,'real file should produce interim value analyses');
});
test('workspace round trip preserves original period keys', {skip: !hasInput}, () => {
 const restored=deserializeWorkspace(serializeWorkspace({models:{atieh:null,metil:source},settings:DEFAULT_SETTINGS,holding:'metil'}));
 const model=(restored.models as any).metil;
 assert.deepEqual(selectReportModel(model,'half-year').years,[1404,1405]);
});
