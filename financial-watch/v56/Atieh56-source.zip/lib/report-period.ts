import { buildFinancialModel, type FinancialModel } from './financial-engine';

export type ReportKind = 'annual' | 'half-year';

// Annual keys retain their historic value. Interim keys have an explicit month suffix.
export function parseReportPeriod(input: unknown): number | null {
  const text = String(input ?? '').trim().replace(/[۰-۹]/g, c => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(c))).replace(/[٠-٩]/g, c => String('٠١٢٣٤٥٦٧٨٩'.indexOf(c)));
  const match = text.match(/^(1[3-6]\d{2})(?:[-/]0?6)?$/);
  if (match) return text.includes('-') || text.includes('/') ? Number(match[1]) * 100 + 6 : Number(match[1]);
  if (/^1[3-6]\d{2}06$/.test(text)) return Number(text);
  return null;
}

export function reportKind(key: number): ReportKind {
  return key > 10000 ? 'half-year' : 'annual';
}

export function selectReportModel(source: FinancialModel, kind: ReportKind): FinancialModel {
  const rows = source.records.filter(record => reportKind(record.year) === kind).map(record => ({
    'ماهیت': record.nature, 'شرکت': record.company,
    'سال': kind === 'half-year' ? Math.floor(record.year / 100) : record.year,
    'متغیر': record.variable, 'کد متغیر': record.code, 'واحد': record.unit,
    'مقدار': record.value, 'امتیاز': record.score, 'نشان': record.indexedValue,
  }));
  const model = buildFinancialModel(rows, ['ماهیت','شرکت','سال','متغیر','کد متغیر','واحد','مقدار','امتیاز','نشان'], source.fileName);
  model.importedAt = source.importedAt;
  model.reportKind = kind;
  if (kind === 'half-year') model.annualOpeningModel = selectReportModel(source, 'annual');
  return model;
}
