import * as XLSX from "xlsx";

export const MARKET_DIMENSIONS = [
  { key: "size", source: "اندازه و ضرورت", label: "اندازه و اهمیت بازار" },
  { key: "growth", source: "رشد و آینده", label: "رشد و چشم‌انداز بازار" },
  { key: "stability", source: "پایداری و تنوع", label: "پایداری و تنوع تقاضا" },
  { key: "competition", source: "رقابت و ورود", label: "ساختار رقابت و موانع ورود" },
  { key: "development", source: "توسعه و ریسک", label: "ظرفیت توسعه و ریسک بازار" },
] as const;

export type MarketDimensionKey = (typeof MARKET_DIMENSIONS)[number]["key"];

export interface MarketIssue {
  severity: "error" | "warning";
  row: number | null;
  company: string | null;
  message: string;
}

export interface MarketCompanyData {
  name: string;
  canonicalName: string;
  total: number | null;
  dimensions: Record<MarketDimensionKey, number | null>;
  duplicateSections: string[];
}

export interface MarketModel {
  fileName: string;
  importedAt: Date;
  companies: MarketCompanyData[];
  byCanonicalName: Map<string, MarketCompanyData>;
  issues: MarketIssue[];
  summary: {
    totalRows: number;
    companies: number;
    validTotals: number;
    errors: number;
    warnings: number;
  };
}

const COMPANY_ALIASES: Record<string, string> = {
  "شرکت فولاد متیل": "فولاد متیل",
  "گروه فولاد متیل": "فولاد متیل",
  "شرکت صنایع برش ورق های فولادی مبارکه": "صنایع برش",
  "صنایع برش ورق های فولادی مبارکه": "صنایع برش",
  "صنایع برش ورق فولادی مبارکه": "صنایع برش",
  "شرکت پولاد بهیز": "پولاد بهیز",
  "پولای بهیز": "پولاد بهیز",
  "شرکت آتیه تجارت نقش جهان قشم": "آتیه تجارت",
  "آتیه تجارت نقش جهان قشم": "آتیه تجارت",
  "آتیه تجارت": "آتیه تجارت",
  "شرکت نورد لوله کوثر اسپادانا": "نورد لوله کوثر اسپادانا",
  "نورد لوله کوثر صنعت اسپادانا": "نورد لوله کوثر اسپادانا",
  "شرکت ورق خودرو چهارمحال و بختیاری": "ورق خودرو",
  "ورق خودرو چهارمحال و بختیاری": "ورق خودرو",
  "ورق خودرو چهارمحال بختیاری": "ورق خودرو",
  "ورق خودرو": "ورق خودرو",
  "شرکت توکا رنگ": "توکا رنگ",
  "توکا رنگ فولاد سپاهان": "توکا رنگ",
  "شرکت آتیه صنعت افق نقش جهان": "آتیه صنعت افق",
  "آتیه صنعت افق نقش جهان": "آتیه صنعت افق",
  "آتیه صنعت افق": "آتیه صنعت افق",
  "شرکت کارگزاری مبین سرمایه": "مبین سرمایه",
  "کارگزاری مبین سرمایه": "مبین سرمایه",
};

export function normalizeMarketText(value: unknown): string {
  return String(value ?? "")
    .normalize("NFKC")
    .replace(/[يى]/g, "ی")
    .replace(/ك/g, "ک")
    .replace(/[\u200c\u200d\u200e\u200f]/g, " ")
    .replace(/[ـ]/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

export function canonicalCompanyName(value: unknown): string {
  const normalized = normalizeMarketText(value)
    .replace(/[()（）،,:؛.]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  return COMPANY_ALIASES[normalized] ?? normalized;
}

function normalizedHeader(value: unknown) {
  return normalizeMarketText(value).replace(/\s/g, "").toLowerCase();
}

function headerKind(value: unknown): "company" | "section" | "score" | null {
  const header = normalizedHeader(value);
  if (/^(شرکت|نامشرکت|company|companyname)$/.test(header)) return "company";
  if (/^(بخش|بعد|مولفه|مؤلفه|dimension|section)$/.test(header)) return "section";
  if (/^(امتیاز|نمره|score|marketscore)$/.test(header)) return "score";
  return null;
}

function numericScore(value: unknown): number | null {
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  const normalized = normalizeMarketText(value)
    .replace(/[۰-۹]/g, (digit) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(digit)))
    .replace(/[٬,]/g, "")
    .replace(/٫/g, ".");
  if (!normalized) return null;
  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : null;
}

function sectionKey(value: unknown): "total" | MarketDimensionKey | null {
  const section = normalizeMarketText(value);
  if (/^(کل|امتیاز کل|جمع)$/.test(section)) return "total";
  const match = MARKET_DIMENSIONS.find((dimension) => dimension.source === section || dimension.label === section);
  return match?.key ?? null;
}

interface MarketSheetCandidate {
  sheet: XLSX.WorkSheet;
  sheetName: string;
  headerRowIndex: number;
  columns: { company: number; section: number; score: number };
  matched: number;
  dataRows: number;
}

function selectMarketSheet(workbook: XLSX.WorkBook): MarketSheetCandidate {
  const candidates: MarketSheetCandidate[] = [];
  workbook.SheetNames.forEach((sheetName) => {
    const sheet = workbook.Sheets[sheetName];
    if (!sheet) return;
    const rows = XLSX.utils.sheet_to_json<unknown[]>(sheet, { header: 1, raw: true, defval: null, blankrows: true });
    rows.slice(0, 30).forEach((row, headerRowIndex) => {
      const columns = { company: -1, section: -1, score: -1 };
      row.forEach((value, index) => {
        const kind = headerKind(value);
        if (kind) columns[kind] = index;
      });
      const matched = Object.values(columns).filter((index) => index >= 0).length;
      if (matched >= 2) {
        candidates.push({
          sheet,
          sheetName,
          headerRowIndex,
          columns,
          matched,
          dataRows: Math.max(0, rows.length - headerRowIndex - 1),
        });
      }
    });
  });
  candidates.sort((a, b) => b.matched - a.matched || b.dataRows - a.dataRows || a.headerRowIndex - b.headerRowIndex);
  const selected = candidates[0];
  if (!selected || selected.matched < 3) {
    throw new Error("ساختار دیتابیس بازار شناسایی نشد. ستون‌های «شرکت»، «بخش» و «امتیاز» لازم است.");
  }
  return selected;
}

export function parseMarketWorkbook(data: ArrayBuffer, fileName: string): MarketModel {
  const workbook = XLSX.read(data, { type: "array", raw: true, cellDates: false, cellFormula: false });
  if (!workbook.SheetNames.length) throw new Error("فایل Excel بازار فاقد شیت قابل خواندن است.");
  const selected = selectMarketSheet(workbook);
  const rows = XLSX.utils.sheet_to_json<unknown[]>(selected.sheet, {
    header: 1,
    range: selected.headerRowIndex + 1,
    raw: true,
    defval: null,
    blankrows: false,
  });
  const issues: MarketIssue[] = [];
  const grouped = new Map<string, { name: string; sections: Map<string, { value: number; row: number }[]> }>();

  rows.forEach((row, index) => {
    const sourceRow = selected.headerRowIndex + index + 2;
    const name = normalizeMarketText(row[selected.columns.company]);
    const section = normalizeMarketText(row[selected.columns.section]);
    const rawScore = row[selected.columns.score];
    if (!name && !section && (rawScore === null || rawScore === "")) return;
    if (!name) {
      issues.push({ severity: "error", row: sourceRow, company: null, message: "نام شرکت خالی است." });
      return;
    }
    const key = sectionKey(section);
    if (!key) {
      issues.push({ severity: "warning", row: sourceRow, company: name, message: `بخش «${section || "خالی"}» شناخته نشد و در محاسبه وارد نشد.` });
      return;
    }
    const score = numericScore(rawScore);
    if (score === null) {
      issues.push({ severity: "error", row: sourceRow, company: name, message: `امتیاز بخش «${section}» عددی نیست.` });
      return;
    }
    if (score < 0 || score > 10) {
      issues.push({ severity: "error", row: sourceRow, company: name, message: `امتیاز بخش «${section}» خارج از بازه صفر تا ۱۰ است.` });
      return;
    }
    const canonical = canonicalCompanyName(name);
    const company = grouped.get(canonical) ?? { name, sections: new Map() };
    const entries = company.sections.get(key) ?? [];
    entries.push({ value: score, row: sourceRow });
    company.sections.set(key, entries);
    grouped.set(canonical, company);
  });

  const companies = [...grouped.entries()].map(([canonicalName, groupedCompany]) => {
    const duplicateSections: string[] = [];
    groupedCompany.sections.forEach((entries, key) => {
      if (entries.length <= 1) return;
      duplicateSections.push(key);
      issues.push({
        severity: "error",
        row: entries[1].row,
        company: groupedCompany.name,
        message: `بخش «${key === "total" ? "کل" : MARKET_DIMENSIONS.find((item) => item.key === key)?.source ?? key}» تکراری است؛ مقدار آن تا رفع تکرار استفاده نمی‌شود.`,
      });
    });
    const valueFor = (key: string) => {
      const entries = groupedCompany.sections.get(key) ?? [];
      return entries.length === 1 ? entries[0].value : null;
    };
    const dimensions = Object.fromEntries(
      MARKET_DIMENSIONS.map((dimension) => [dimension.key, valueFor(dimension.key)]),
    ) as Record<MarketDimensionKey, number | null>;
    if (valueFor("total") === null && !(groupedCompany.sections.get("total")?.length ?? 0)) {
      issues.push({ severity: "warning", row: null, company: groupedCompany.name, message: "ردیف «کل» موجود نیست؛ شرکت روی ماتریس نمایش داده نمی‌شود." });
    }
    MARKET_DIMENSIONS.forEach((dimension) => {
      if (dimensions[dimension.key] === null) {
        issues.push({ severity: "warning", row: null, company: groupedCompany.name, message: `بُعد «${dimension.label}» مفقود است؛ در رادار خالی نمایش داده می‌شود.` });
      }
    });
    return {
      name: groupedCompany.name,
      canonicalName,
      total: valueFor("total"),
      dimensions,
      duplicateSections,
    } satisfies MarketCompanyData;
  });
  companies.sort((a, b) => a.name.localeCompare(b.name, "fa"));
  const byCanonicalName = new Map(companies.map((company) => [company.canonicalName, company]));
  return {
    fileName: selected.sheetName === workbook.SheetNames[0] ? fileName : `${fileName} · شیت ${selected.sheetName}`,
    importedAt: new Date(),
    companies,
    byCanonicalName,
    issues,
    summary: {
      totalRows: rows.length,
      companies: companies.length,
      validTotals: companies.filter((company) => company.total !== null).length,
      errors: issues.filter((issue) => issue.severity === "error").length,
      warnings: issues.filter((issue) => issue.severity === "warning").length,
    },
  };
}

export function marketCompanyFor(model: MarketModel, financialCompanyName: string) {
  return model.byCanonicalName.get(canonicalCompanyName(financialCompanyName)) ?? null;
}
