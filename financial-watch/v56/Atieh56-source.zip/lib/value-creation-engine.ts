import { normalizeText, type FinancialModel } from "@/lib/financial-engine";
import {independentRoic} from './roic-comparison';
import {
  financialRecordByCode,
  profitCompanyKey,
  profitRecordsForCompany,
  type ProfitModel,
  type ProfitRecord,
} from "@/lib/profit-engine";
import type { ProductionModel } from "@/lib/investment-engine";
import {
  buildPlanningScenarioSnapshot,
  type AssetSchedule,
  type FieldSource,
} from "@/lib/planning-scenario-engine";
import type { HoldingKey } from "@/lib/company-resolver";

export interface BudgetAssumptions {
  cash?: number;
}

export interface ValueSnapshot {
  periodDays?: number;
  company: string;
  year: number;
  isEstimated: boolean;
  beginningIc: number | null;
  endIc: number | null;
  averageIc: number;
  averageTotalAssets: number | null;
  averageReceivables: number | null;
  averageInventory: number | null;
  averageOtherIc: number | null;
  nopat: number;
  roic: number;
  wacc: number;
  spread: number;
  taxRate: number;
  revenue: number;
  cogs: number;
  grossProfit: number | null;
  receivables: number;
  inventory: number;
  operatingProfit: number | null;
  netProfit: number | null;
  dso: number | null;
  dio: number | null;
  dpo: number | null;
  ccc: number | null;
  assetTurnover: number | null;
  assetSchedule?: AssetSchedule;
  sources?: Record<string, FieldSource>;
}

export interface ProfitBridgeItem {
  key: string;
  label: string;
  value: number | null;
  kind: "base" | "negative" | "positive" | "total" | "nopat";
}
export interface ProfitStage {
  key: "revenue" | "gross" | "operating" | "net" | "nopat";
  label: string;
  technicalLabel: string;
  value: number | null;
  margin: number | null;
  previousValue: number | null;
  change: number | null;
}
export interface CapitalItem {
  key: string;
  label: string;
  value: number;
  group: "current" | "noncurrent" | "estimated";
}
export interface ProductInsight extends ProfitRecord {
  revenueMix: number | null;
  grossProfitContribution: number | null;
}
export interface ProductSensitivityResult {
  product: string;
  marginDeltaPp: number;
  addedGrossProfit: number;
  addedNopat: number;
  roic: number;
  spread: number;
  spreadDelta: number;
  feasible: boolean;
  message: string;
}
export interface ScenarioResult {
  key: string;
  label: string;
  changeLabel: string;
  roic: number;
  spread: number;
  spreadDelta: number;
  releasedCapital: number;
  addedNopat: number;
  newAverageIc: number;
  feasible: boolean;
  feasibilityMessage: string;
  appliedDsoReduction: number;
  appliedDioReduction: number;
}
export interface ValueDecomposition {
  fromYear: number;
  toYear: number;
  fromRoic: number;
  toRoic: number;
  profitEffect: number;
  capitalEffect: number;
  roicChange: number;
  waccChange: number;
  spreadChange: number;
  spreadControlDifference: number;
}
export interface SolverDriver {
  theoretical: number | null;
  feasible: boolean;
  current: number | null;
  target: number | null;
  message: string;
}
export interface TargetSolution {
  valid: boolean;
  message: string;
  targetRoic: number;
  requiredNopat: number | null;
  nopatGap: number | null;
  nopatGrowth: number | null;
  marginPp: number | null;
  requiredAverageIc: number | null;
  icReduction: number | null;
  icReductionPercent: number | null;
  capitalFeasible: boolean;
  dso: SolverDriver;
  dio: SolverDriver;
}
export interface ValueCreationAnalysis {
  company: string;
  years: number[];
  actuals: ValueSnapshot[];
  selected: ValueSnapshot | null;
  previous: ValueSnapshot | null;
  budget: ValueSnapshot | null;
  actualDecomposition: ValueDecomposition | null;
  budgetDecomposition: ValueDecomposition | null;
  bridge: ProfitBridgeItem[];
  capital: CapitalItem[];
  products: ProductInsight[];
  budgetProducts: ProductInsight[];
  scenarios: ScenarioResult[];
  warnings: string[];
  profitMatched: boolean;
  profitUnit: string | null;
  financialUnit: string | null;
  budgetAssumptions: Required<BudgetAssumptions> | null;
}

function value(
  model: FinancialModel,
  company: string,
  year: number,
  code: string,
) {
  return financialRecordByCode(model, company, year, code)?.value ?? null;
}
function computedIc(model: FinancialModel, company: string, year: number) {
  const assets = value(model, company, year, "134"),
    cash = value(model, company, year, "130"),
    shortTerm = value(model, company, year, "132");
  return assets === null || cash === null || shortTerm === null
    ? null
    : assets - cash - shortTerm;
}
function boundedTaxRate(rate: number | null | undefined) {
  return rate === null || rate === undefined || !Number.isFinite(rate)
    ? 0
    : Math.max(0, Math.min(0.6, rate));
}
function averageWorkingCapital(
  revenue: number,
  cogs: number,
  dso: number | null,
  dio: number | null,
  periodDays = 365,
) {
  return {
    averageReceivables:
      dso === null ? null : (revenue / periodDays) * Math.max(0, dso),
    averageInventory:
      dio === null ? null : (Math.abs(cogs) / periodDays) * Math.max(0, dio),
  };
}

function actualSnapshot(
  model: FinancialModel,
  company: string,
  year: number,
): ValueSnapshot | null {
  const openingModel = model.annualOpeningModel ?? model;
  const periodDays = model.reportKind === "half-year" ? 186 : 365;
  const beginningIc = computedIc(openingModel, company, year - 1),
    endIc = computedIc(model, company, year);
  const nopat = value(model, company, year, "148"),
    annualWacc = value(model, company, year, "179"),
    revenue = value(model, company, year, "111"),
    cogs = value(model, company, year, "112");
  const wacc = annualWacc === null || annualWacc <= -1 ? null : model.reportKind === 'half-year' ? Math.sqrt(1 + annualWacc) - 1 : annualWacc;
  const actualTaxRate=value(model,company,year,'182');
  if(actualTaxRate===null||!Number.isFinite(actualTaxRate)||actualTaxRate<0||actualTaxRate>0.6)return null;
  const receivables = value(model, company, year, "129"),
    inventory = value(model, company, year, "128");
  if (
    [
      beginningIc,
      endIc,
      nopat,
      wacc,
      revenue,
      cogs,
      receivables,
      inventory,
    ].some((item) => item === null)
  )
    return null;
  const averageIc = (beginningIc! + endIc!) / 2;
  if (!Number.isFinite(averageIc) || averageIc <= 0) return null;
  const dso = value(model, company, year, "166"),
    dio = value(model, company, year, "165");
  const { averageReceivables, averageInventory } = averageWorkingCapital(
    revenue!,
    cogs!,
    dso,
    dio,
    periodDays,
  );
  const averageOtherIc =
    averageReceivables === null || averageInventory === null
      ? null
      : averageIc - averageReceivables - averageInventory;
  const roic = nopat! / averageIc;
  const assetsBeginning = value(openingModel, company, year - 1, "134"),
    assetsEnding = value(model, company, year, "134");
  const averageTotalAssets =
    assetsBeginning === null || assetsEnding === null
      ? null
      : (assetsBeginning + assetsEnding) / 2;
  return {
    company,
    year,
    isEstimated: false,
    periodDays,
    beginningIc: beginningIc!,
    endIc: endIc!,
    averageIc,
    averageTotalAssets,
    averageReceivables,
    averageInventory,
    averageOtherIc,
    nopat: nopat!,
    roic,
    wacc: wacc!,
    spread: roic - wacc!,
    taxRate: actualTaxRate,
    revenue: revenue!,
    cogs: cogs!,
    grossProfit: value(model, company, year, "113"),
    receivables: receivables!,
    inventory: inventory!,
    operatingProfit: value(model, company, year, "118"),
    netProfit: value(model, company, year, "124"),
    dso,
    dio,
    dpo: value(model, company, year, "167"),
    ccc: value(model, company, year, "168"),
    assetTurnover: value(model, company, year, "152"),
  };
}

export interface CompanySpreadRow {
  company: string;
  spread: number | null;
  roic: number | null;
  wacc: number | null;
}

/** One row per company in the selected holding's FinancialModel; never borrow another year. */
export function buildCompanySpreadRanking(
  financial: FinancialModel,
  profit: ProfitModel | null,
  production: ProductionModel | null,
  holding: HoldingKey,
  year: number,
  basis: "actual" | "budget",
): CompanySpreadRow[] {
  return financial.companies.map((company) => {
    if(basis==='actual'){
      const r=independentRoic(financial,company,year),wacc=value(financial,company,year,'179');
      const finiteWacc=wacc!==null&&Number.isFinite(wacc)&&wacc>-1?(financial.reportKind === 'half-year' ? Math.sqrt(1+wacc)-1 : wacc):null;
      return {company,roic:r?.roic??null,wacc:finiteWacc,spread:r&&finiteWacc!==null?r.roic-finiteWacc:null};
    }
    const snapshot = basis === "budget"
      ? buildPlanningScenarioSnapshot(financial, profit, production, holding, company,{budgetYear:year})
      : actualSnapshot(financial, company, year);
    const valid = snapshot && [snapshot.spread, snapshot.roic, snapshot.wacc].every(Number.isFinite);
    return {
      company,
      spread: valid ? snapshot.spread : null,
      roic: valid ? snapshot.roic : null,
      wacc: valid ? snapshot.wacc : null,
    };
  }).sort((a, b) => {
    if (a.spread === null) return b.spread === null ? a.company.localeCompare(b.company, "fa") : 1;
    if (b.spread === null) return -1;
    return b.spread - a.spread || a.company.localeCompare(b.company, "fa");
  });
}

function productInsights(records: ProfitRecord[]) {
  const details = records.filter((record) => !record.isTotal);
  const revenue = details.reduce((sum, item) => sum + item.revenue, 0),
    grossProfit = details.reduce(
      (sum, item) => sum + item.calculatedGrossProfit,
      0,
    );
  return details
    .map((item) => ({
      ...item,
      revenueMix: revenue === 0 ? null : item.revenue / revenue,
      grossProfitContribution:
        grossProfit === 0 ? null : item.calculatedGrossProfit / grossProfit,
    }))
    .sort((a, b) => b.calculatedGrossProfit - a.calculatedGrossProfit);
}
function requestedReduction(requested: number, current: number | null) {
  if (requested <= 0) return { applied: 0, feasible: true };
  if (current === null || current < 0) return { applied: 0, feasible: false };
  const safe = Math.max(0, requested);
  return { applied: Math.min(safe, current), feasible: safe <= current + 1e-9 };
}
function scenario(
  snapshot: ValueSnapshot,
  key: string,
  label: string,
  changeLabel: string,
  marginDelta = 0,
  dsoReduction = 0,
  dioReduction = 0,
  otherIcReduction = 0,
): ScenarioResult {
  const dso = requestedReduction(dsoReduction, snapshot.dso),
    dio = requestedReduction(dioReduction, snapshot.dio);
  const addedNopat =
    snapshot.revenue * marginDelta * (1 - snapshot.taxRate);
  const releasedCapital =
    (dso.applied * snapshot.revenue) / (snapshot.periodDays ?? 365) +
    (dio.applied * Math.abs(snapshot.cogs)) / (snapshot.periodDays ?? 365) +
    Math.max(0, Math.min(1, otherIcReduction)) *
      Math.max(0, snapshot.averageOtherIc ?? 0);
  const newAverageIc = Math.max(1, snapshot.averageIc - releasedCapital),
    roic = (snapshot.nopat + addedNopat) / newAverageIc;
  const feasible = dso.feasible && dio.feasible;
  return {
    key,
    label,
    changeLabel,
    roic,
    spread: roic - snapshot.wacc,
    spreadDelta: roic - snapshot.roic,
    releasedCapital,
    addedNopat,
    newAverageIc,
    feasible,
    feasibilityMessage: feasible
      ? "در محدوده داده فعلی قابل بررسی است"
      : "اندازه سناریو از ظرفیت فعلی این اهرم بیشتر است",
    appliedDsoReduction: dso.applied,
    appliedDioReduction: dio.applied,
  };
}

function buildBudget(
  financial: FinancialModel,
  profit: ProfitModel,
  production: ProductionModel | null,
  holding: HoldingKey,
  selected: ValueSnapshot,
): ValueSnapshot | null {
  const snapshot = buildPlanningScenarioSnapshot(
    financial,
    profit,
    production,
    holding,
    selected.company,
  );
  if (!snapshot) return null;
  const schedule = snapshot.assetSchedule;
  return {
    company: snapshot.company,
    year: snapshot.year,
    isEstimated: true,
    beginningIc: null,
    endIc: null,
    averageIc: schedule.averageInvestedCapital,
    averageTotalAssets: schedule.averageTotalAssets,
    averageReceivables: schedule.receivables,
    averageInventory: schedule.inventory,
    averageOtherIc:
      schedule.averageInvestedCapital -
      schedule.receivables -
      schedule.inventory,
    nopat: snapshot.nopat,
    roic: snapshot.roic,
    wacc: snapshot.wacc,
    spread: snapshot.spread,
    taxRate: snapshot.taxRate,
    revenue: snapshot.revenue,
    cogs: snapshot.cogs,
    grossProfit: snapshot.grossProfit,
    receivables: schedule.receivables,
    inventory: schedule.inventory,
    operatingProfit: snapshot.operatingProfit,
    netProfit: snapshot.netProfit,
    dso: snapshot.dso,
    dio: snapshot.dio,
    dpo: snapshot.dpo,
    ccc: snapshot.ccc,
    assetTurnover: snapshot.assetTurnover,
    assetSchedule: schedule,
    sources: snapshot.sources,
  };
}

function bridge(
  model: FinancialModel,
  company: string,
  year: number,
): ProfitBridgeItem[] {
  return [
    ["revenue", "درآمد عملیاتی", "111", "base"],
    ["cogs", "بهای تمام‌شده", "112", "negative"],
    ["gross", "سود ناخالص", "113", "total"],
    ["opex", "هزینه‌های عملیاتی", "115", "negative"],
    ["other-op", "سایر عملیاتی", "117", "positive"],
    ["op", "سود عملیاتی", "118", "total"],
    ["finance", "هزینه مالی", "120", "negative"],
    ["non-op", "غیرعملیاتی", "121", "positive"],
    ["pbt", "سود قبل مالیات", "122", "total"],
    ["tax", "مالیات", "123", "negative"],
    ["net", "سود خالص", "124", "total"],
    ["nopat", "سود مبنای بازده سرمایه", "148", "nopat"],
  ].map(([key, label, code, kind]) => ({
    key,
    label,
    value: value(model, company, year, code),
    kind: kind as ProfitBridgeItem["kind"],
  }));
}
function capitalComposition(
  model: FinancialModel,
  company: string,
  year: number,
): CapitalItem[] {
  const currentAssets = value(model, company, year, "133") ?? 0,
    cash = value(model, company, year, "130") ?? 0,
    shortTerm = value(model, company, year, "132") ?? 0;
  const receivables = value(model, company, year, "129") ?? 0,
    inventory = value(model, company, year, "128") ?? 0,
    nonCurrent = value(model, company, year, "131") ?? 0;
  const ppe = value(model, company, year, "125") ?? 0,
    intangible = value(model, company, year, "126") ?? 0,
    longTerm = value(model, company, year, "127") ?? 0;
  return [
    { key: "ar", label: "دریافتنی‌ها", value: receivables, group: "current" },
    { key: "inventory", label: "موجودی", value: inventory, group: "current" },
    {
      key: "other-current",
      label: "سایر دارایی جاری درگیر",
      value: currentAssets - cash - shortTerm - receivables - inventory,
      group: "current",
    },
    { key: "ppe", label: "دارایی ثابت مشهود", value: ppe, group: "noncurrent" },
    {
      key: "intangible",
      label: "دارایی نامشهود",
      value: intangible,
      group: "noncurrent",
    },
    {
      key: "long-term",
      label: "سرمایه‌گذاری بلندمدت",
      value: longTerm,
      group: "noncurrent",
    },
    {
      key: "other-noncurrent",
      label: "سایر دارایی غیرجاری",
      value: nonCurrent - ppe - intangible - longTerm,
      group: "noncurrent",
    },
  ];
}

export function capitalForSnapshot(
  snapshot: ValueSnapshot,
  actualCapital: CapitalItem[],
): CapitalItem[] {
  if (!snapshot.isEstimated) return actualCapital;
  const s = snapshot.assetSchedule;
  if (!s) return [];
  return [
    {
      key: "average-ar",
      label: "متوسط دریافتنی برآوردی",
      value: s.receivables,
      group: "estimated",
    },
    {
      key: "average-inventory",
      label: "متوسط موجودی برآوردی",
      value: s.inventory,
      group: "estimated",
    },
    { key: "cash", label: "نقد برآوردی", value: s.cash, group: "estimated" },
    {
      key: "short-investment",
      label: "سرمایه‌گذاری کوتاه‌مدت",
      value: s.shortTermInvestments,
      group: "estimated",
    },
    {
      key: "other-current",
      label: "سایر دارایی جاری برآوردی",
      value: s.otherCurrentAssets,
      group: "estimated",
    },
    {
      key: "fixed",
      label: "دارایی ثابت مشهود",
      value: s.fixedAssets,
      group: "estimated",
    },
    {
      key: "intangible",
      label: "دارایی نامشهود",
      value: s.intangibleAssets,
      group: "estimated",
    },
    {
      key: "long-investment",
      label: "سرمایه‌گذاری بلندمدت",
      value: s.longTermInvestments,
      group: "estimated",
    },
    {
      key: "other-noncurrent",
      label: "سایر دارایی غیرجاری",
      value: s.otherNonCurrentAssets,
      group: "estimated",
    },
  ];
}
export function profitStagesForSnapshot(
  snapshot: ValueSnapshot,
  comparison: ValueSnapshot | null,
): ProfitStage[] {
  const values = {
    revenue: snapshot.revenue,
    gross: snapshot.grossProfit,
    operating: snapshot.operatingProfit,
    net: snapshot.netProfit,
    nopat: snapshot.nopat,
  };
  const previous = comparison
    ? {
        revenue: comparison.revenue,
        gross: comparison.grossProfit,
        operating: comparison.operatingProfit,
        net: comparison.netProfit,
        nopat: comparison.nopat,
      }
    : null;
  const defs: Array<{
    key: ProfitStage["key"];
    label: string;
    technicalLabel: string;
  }> = [
    { key: "revenue", label: "درآمد", technicalLabel: "درآمد (Revenue)" },
    {
      key: "gross",
      label: "سود ناخالص",
      technicalLabel: "سود ناخالص (Gross Profit)",
    },
    {
      key: "operating",
      label: "سود عملیاتی",
      technicalLabel: "سود عملیاتی (Operating Profit)",
    },
    { key: "net", label: "سود خالص", technicalLabel: "سود خالص (Net Profit)" },
    {
      key: "nopat",
      label: "سود مبنای بازده سرمایه",
      technicalLabel: "سود عملیاتی پس از مالیات (NOPAT)",
    },
  ];
  return defs.map((def) => {
    const currentValue = values[def.key],
      previousValue = previous?.[def.key] ?? null;
    return {
      ...def,
      value: currentValue,
      margin:
        currentValue === null || snapshot.revenue === 0
          ? null
          : currentValue / snapshot.revenue,
      previousValue,
      change:
        currentValue === null || previousValue === null || previousValue === 0
          ? null
          : (currentValue - previousValue) / Math.abs(previousValue),
    };
  });
}
export function decomposeValueChange(
  previous: ValueSnapshot | null,
  current: ValueSnapshot | null,
): ValueDecomposition | null {
  if (
    !previous ||
    !current ||
    previous.averageIc <= 0 ||
    current.averageIc <= 0
  )
    return null;
  const n0 = previous.nopat,
    n1 = current.nopat,
    i0 = previous.averageIc,
    i1 = current.averageIc;
  const profitEffect = 0.5 * (n1 / i0 - n0 / i0 + (n1 / i1 - n0 / i1));
  const capitalEffect = 0.5 * (n0 / i1 - n0 / i0 + (n1 / i1 - n1 / i0));
  const roicChange = current.roic - previous.roic,
    waccChange = current.wacc - previous.wacc,
    spreadChange = current.spread - previous.spread;
  return {
    fromYear: previous.year,
    toYear: current.year,
    fromRoic: previous.roic,
    toRoic: current.roic,
    profitEffect,
    capitalEffect,
    roicChange,
    waccChange,
    spreadChange,
    spreadControlDifference:
      profitEffect + capitalEffect - waccChange - spreadChange,
  };
}
export function buildStandardScenarios(snapshot: ValueSnapshot) {
  return [
    scenario(
      snapshot,
      "margin",
      "بهبود حاشیه سود عملیاتی",
      "+۱ واحد درصد",
      0.01,
    ),
    scenario(snapshot, "dso", "کاهش دوره وصول مطالبات", "−۱۰ روز", 0, 10),
    scenario(snapshot, "dio", "کاهش دوره نگهداری موجودی", "−۱۰ روز", 0, 0, 10),
    scenario(snapshot, "other", "کاهش سایر سرمایه درگیر", "−۵٪", 0, 0, 0, 0.05),
  ].sort((a, b) => b.spreadDelta - a.spreadDelta);
}

export function buildValueCreationAnalysis(
  financial: FinancialModel,
  profit: ProfitModel | null,
  company: string,
  selectedYear?: number,
  assumptions: BudgetAssumptions = {},
  production: ProductionModel | null = null,
  holding: HoldingKey = "atieh",
): ValueCreationAnalysis {
  const effectiveHolding = holding;
  const actuals = financial.years
    .map((year) => actualSnapshot(financial, company, year))
    .filter((item): item is ValueSnapshot => Boolean(item))
    .sort((a, b) => a.year - b.year);
  const years = actuals.map((item) => item.year),
    selected = selectedYear===undefined?(actuals.at(-1)??null):(actuals.find((item) => item.year === selectedYear)??null);
  const previous = selected
    ? (actuals.find((item) => item.year === selected.year-1) ?? null)
    : null;
  const profitRows = profitRecordsForCompany(profit, company, effectiveHolding),
    actualProfitRows = selected
      ? profitRows.filter(
          (record) => !record.isBudget && record.year === selected.year,
        )
      : [];
  const budgetYear=Math.max(-Infinity,...profitRows.filter(record=>record.isBudget).map(record=>record.year));
  const budgetRows = profitRows.filter((record) => record.isBudget&&record.year===budgetYear),
    warnings: string[] = [],
    profitMatched = profitRows.length > 0;
  const profitUnit = profitRows[0]?.unit ?? null,
    financialUnit = selected
      ? (financialRecordByCode(financial, company, selected.year, "111")
          ?.unit ?? null)
      : null;
  const unitsCompatible = Boolean(
    profitUnit &&
    financialUnit &&
    normalizeText(profitUnit) === normalizeText(financialUnit),
  );
  const budget =
    selected && profit && unitsCompatible && financial.reportKind !== 'half-year'
      ? buildBudget(financial, profit, production, effectiveHolding, selected)
      : null;
  if (profit && !profitMatched)
    warnings.push(
      "نام شرکت در دیتابیس سود (Profit) با قواعد تطبیق کنترل‌شده پیدا نشد؛ جزئیات محصول غیرفعال است.",
    );
  if (selected) {
    const storedIc = value(financial, company, selected.year, "149"),
      storedRoic = value(financial, company, selected.year, "150"),
      storedSpread = value(financial, company, selected.year, "176");
    if (
      storedIc !== null &&
      selected.endIc !== null &&
      Math.abs(storedIc - selected.endIc) >
        Math.max(1, Math.abs(selected.endIc) * 0.001)
    )
      warnings.push(
        "سرمایه درگیر ذخیره‌شده با محاسبه دارایی منهای نقد و سرمایه‌گذاری کوتاه‌مدت اختلاف دارد؛ مقدار محاسبه‌شده مبنا قرار گرفت.",
      );
    if (storedRoic !== null && Math.abs(storedRoic - selected.roic) > 0.001)
      warnings.push(
        "بازده سرمایه ذخیره‌شده (ROIC) با محاسبه مجدد بر مبنای میانگین سرمایه درگیر اختلاف دارد.",
      );
    if (
      storedSpread !== null &&
      Math.abs(storedSpread - selected.spread) > 0.001
    )
      warnings.push(
        "فاصله ارزش‌آفرینی ذخیره‌شده (Spread) با بازده سرمایه منهای هزینه سرمایه (ROIC − WACC) اختلاف دارد.",
      );
    if (profitUnit && financialUnit && !unitsCompatible)
      warnings.push(
        "نیاز به همسان‌سازی واحد مالی؛ مبالغ دیتابیس سود (Profit) با محاسبات بازده سرمایه (ROIC) ترکیب نشده‌اند.",
      );
    if ((selected.averageOtherIc ?? 0) < 0)
      warnings.push(
        "سایر سرمایه درگیر متوسط منفی شده است؛ مفروضات روزهای وصول مطالبات (DSO)، روزهای نگهداری موجودی (DIO) و تعریف اجزای سرمایه نیازمند بازبینی است.",
      );
    const profitTotal = actualProfitRows.find((record) => record.isTotal);
    if (
      profitTotal &&
      Math.abs(profitTotal.revenue - selected.revenue) >
        Math.max(1, Math.abs(selected.revenue) * 0.005)
    )
      warnings.push(
        "جمع درآمد دیتابیس سود (Profit) با درآمد دیتابیس مالی آتیه تطبیق کامل ندارد؛ دیتابیس آتیه منبع اصلی محاسبات باقی ماند.",
      );
  }
  if (budgetRows.some((row) => row.yearLabelSuspect))
    warnings.push(
      "احتمال خطای برچسب سال در ردیف جمع بودجه؛ خروجی ۱۴۰۵ فقط با برچسب برآوردی نمایش داده می‌شود.",
    );
  if (profit) {
    const financialKeys = new Set(financial.companies.map(profitCompanyKey)),
      unmatched = profit.companies.filter(
        (name) => !financialKeys.has(profitCompanyKey(name)),
      );
    if (unmatched.length)
      warnings.push(
        `${unmatched.length.toLocaleString("fa-IR")} نام شرکت از دیتابیس سود (Profit) بدون تطبیق دقیق در دیتابیس مالی باقی مانده است.`,
      );
  }
  return {
    company,
    years,
    actuals,
    selected,
    previous,
    budget,
    actualDecomposition: decomposeValueChange(previous, selected),
    budgetDecomposition: decomposeValueChange(selected, budget),
    bridge: selected ? bridge(financial, company, selected.year) : [],
    capital: selected
      ? capitalComposition(financial, company, selected.year)
      : [],
    products: productInsights(actualProfitRows),
    budgetProducts: productInsights(budgetRows),
    scenarios: selected ? buildStandardScenarios(selected) : [],
    warnings: [...new Set(warnings)],
    profitMatched,
    profitUnit,
    financialUnit,
    budgetAssumptions: budget ? { cash: assumptions.cash ?? Number.NaN } : null,
  };
}

export function runValueScenario(
  snapshot: ValueSnapshot,
  marginDeltaPp: number,
  dsoReduction: number,
  dioReduction: number,
  otherIcReductionPercent: number,
) {
  return scenario(
    snapshot,
    "custom",
    "سناریوی کاربر",
    "ترکیبی",
    marginDeltaPp / 100,
    dsoReduction,
    dioReduction,
    otherIcReductionPercent / 100,
  );
}
export function runProductMarginScenario(
  snapshot: ValueSnapshot,
  product: ProductInsight,
  marginDeltaPp: number,
): ProductSensitivityResult {
  const feasible =
    Number.isFinite(marginDeltaPp) &&
    product.revenue > 0 &&
    Number.isFinite(product.revenue);
  const safeDelta = feasible ? marginDeltaPp / 100 : 0;
  const addedGrossProfit = product.revenue * safeDelta;
  const addedNopat = addedGrossProfit * (1 - snapshot.taxRate);
  const roic = (snapshot.nopat + addedNopat) / snapshot.averageIc;
  return {
    product: product.product,
    marginDeltaPp,
    addedGrossProfit,
    addedNopat,
    roic,
    spread: roic - snapshot.wacc,
    spreadDelta: roic - snapshot.roic,
    feasible,
    message: feasible
      ? "اثر برآوردی با فرض ثابت بودن سایر هزینه‌های عملیاتی"
      : "داده کافی برای تحلیل حساسیت این محصول وجود ندارد.",
  };
}
export function solveValueTarget(
  snapshot: ValueSnapshot,
  targetSpread: number,
): TargetSolution {
  const targetRoic = snapshot.wacc + targetSpread;
  const empty = (message: string): SolverDriver => ({
    theoretical: null,
    feasible: false,
    current: null,
    target: null,
    message,
  });
  if (!Number.isFinite(targetRoic) || targetRoic <= 0)
    return {
      valid: false,
      message: "هدف انتخاب‌شده به بازده هدف معتبر و مثبت منجر نمی‌شود.",
      targetRoic,
      requiredNopat: null,
      nopatGap: null,
      nopatGrowth: null,
      marginPp: null,
      requiredAverageIc: null,
      icReduction: null,
      icReductionPercent: null,
      capitalFeasible: false,
      dso: empty("قابل محاسبه نیست"),
      dio: empty("قابل محاسبه نیست"),
    };
  const nopatGap = Math.max(
      0,
      targetRoic * snapshot.averageIc - snapshot.nopat,
    ),
    requiredNopat = snapshot.nopat + nopatGap;
  const requiredEbit = nopatGap / Math.max(0.01, 1 - snapshot.taxRate),
    marginPp =
      snapshot.revenue > 0 ? (requiredEbit / snapshot.revenue) * 100 : null;
  const requiredAverageIc =
      snapshot.nopat > 0 ? snapshot.nopat / targetRoic : null,
    icReduction =
      requiredAverageIc === null
        ? null
        : Math.max(0, snapshot.averageIc - requiredAverageIc);
  const capitalFeasible =
      icReduction !== null && icReduction <= snapshot.averageIc + 1e-9,
    arPerDay = snapshot.revenue > 0 ? snapshot.revenue / (snapshot.periodDays ?? 365) : 0,
    invPerDay = Math.abs(snapshot.cogs) / (snapshot.periodDays ?? 365);
  const dsoTheory =
      icReduction === null || arPerDay <= 0 ? null : icReduction / arPerDay,
    dioTheory =
      icReduction === null || invPerDay <= 0 ? null : icReduction / invPerDay;
  const dsoFeasible =
      dsoTheory !== null &&
      snapshot.dso !== null &&
      dsoTheory <= snapshot.dso + 1e-9,
    dioFeasible =
      dioTheory !== null &&
      snapshot.dio !== null &&
      dioTheory <= snapshot.dio + 1e-9;
  return {
    valid: true,
    message:
      nopatGap <= 1e-9
        ? "هدف انتخاب‌شده هم‌اکنون محقق شده است."
        : "مقادیر، تغییر لازم در صورت ثابت‌بودن سایر عوامل را نشان می‌دهند.",
    targetRoic,
    requiredNopat,
    nopatGap,
    nopatGrowth: snapshot.nopat > 0 ? nopatGap / snapshot.nopat : null,
    marginPp,
    requiredAverageIc,
    icReduction,
    icReductionPercent:
      icReduction === null || snapshot.averageIc === 0
        ? null
        : icReduction / snapshot.averageIc,
    capitalFeasible,
    dso: {
      theoretical: dsoTheory,
      feasible: dsoFeasible,
      current: snapshot.dso,
      target:
        dsoTheory === null || snapshot.dso === null
          ? null
          : snapshot.dso - dsoTheory,
      message: dsoFeasible
        ? "این اهرم به‌تنهایی از نظر ریاضی کافی است."
        : "این اهرم به‌تنهایی برای بستن شکاف ارزش‌آفرینی کافی نیست.",
    },
    dio: {
      theoretical: dioTheory,
      feasible: dioFeasible,
      current: snapshot.dio,
      target:
        dioTheory === null || snapshot.dio === null
          ? null
          : snapshot.dio - dioTheory,
      message: dioFeasible
        ? "این اهرم به‌تنهایی از نظر ریاضی کافی است."
        : "این اهرم به‌تنهایی برای بستن شکاف ارزش‌آفرینی کافی نیست.",
    },
  };
}
