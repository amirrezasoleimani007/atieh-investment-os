import type { FinancialModel } from "./financial-engine";
import { canonicalCompanyKey, type HoldingKey } from "./company-resolver";

export const SCORING_VERSION = "FY1404-FROZEN-COMPANY-v1";
export const HIGHER_IS_BETTER_CODES = new Set(["144", "150", "152", "175", "176"]);
export type ScenarioScoreSource = "frozen-linear" | "frozen-piecewise" | "carry-forward";

export interface ScenarioScoreResult {
  code: string; rawValue: number; score: number | null; sampleSize: number;
  method: ScenarioScoreSource; scoreSource: ScenarioScoreSource;
  scoreConfidence: "high" | "medium" | "limited"; calibrationYears: number[];
  scoringVersion: string; maxCalibrationError: number | null;
  holding: HoldingKey; nature: string;
}
interface Point { raw: number; score: number; year: number }
const clamp = (value: number) => Math.max(0, Math.min(10, value));

function companyPoints(model: FinancialModel, company: string, code: string,throughYear=1404) {
  const key = canonicalCompanyKey(company);
  return model.validRecords.filter((row) => row.year <= throughYear && row.code === code && canonicalCompanyKey(row.company) === key && row.value !== null && Number.isFinite(row.value) && row.score !== null && Number.isFinite(row.score) && row.score >= 0 && row.score <= 10)
    .map((row): Point => ({ raw: row.value!, score: row.score!, year: row.year })).sort((a, b) => a.raw - b.raw || a.year - b.year);
}
function regression(points: Point[]) {
  const interior = points.filter((p) => p.score > 0.000001 && p.score < 9.999999);
  const fit = interior.length >= 2 ? interior : points;
  const meanX = fit.reduce((s, p) => s + p.raw, 0) / fit.length, meanY = fit.reduce((s, p) => s + p.score, 0) / fit.length;
  const denom = fit.reduce((s, p) => s + (p.raw - meanX) ** 2, 0);
  if (denom <= Number.EPSILON) return null;
  const b = fit.reduce((s, p) => s + (p.raw - meanX) * (p.score - meanY), 0) / denom;
  if (!(b > 0)) return null;
  const a = meanY - b * meanX;
  return { a, b, maxError: Math.max(...fit.map((p) => Math.abs(clamp(a + b * p.raw) - p.score))) };
}
function monotonicPoints(points: Point[]) {
  const grouped = new Map<number, Point[]>();
  points.forEach((p) => grouped.set(p.raw, [...(grouped.get(p.raw) ?? []), p]));
  const result = [...grouped.entries()].map(([raw, rows]) => ({ raw, score: rows.reduce((s, p) => s + p.score, 0) / rows.length })).sort((a, b) => a.raw - b.raw);
  for (let i = 1; i < result.length; i += 1) result[i].score = Math.max(result[i - 1].score, result[i].score);
  return result;
}
function piecewise(points: ReturnType<typeof monotonicPoints>, raw: number) {
  const segment = raw <= points[0].raw ? [points[0], points[1]] : raw >= points.at(-1)!.raw ? [points.at(-2)!, points.at(-1)!] : points.slice(0, -1).map((p, i) => [p, points[i + 1]]).find(([, b]) => raw <= b.raw)!;
  const [a, b] = segment;
  return clamp(a.score + ((raw - a.raw) / Math.max(Number.EPSILON, b.raw - a.raw)) * (b.score - a.score));
}
function base(model: FinancialModel, company: string, holding: HoldingKey, code: string, rawValue: number, pairs: Point[]) {
  const resolved = model.companies.find((item) => canonicalCompanyKey(item) === canonicalCompanyKey(company)) ?? company;
  return { code, rawValue, sampleSize: pairs.length, calibrationYears: [...new Set(pairs.map((p) => p.year))].sort((a, b) => a - b), scoringVersion: SCORING_VERSION, holding, nature: model.natureByCompany?.get(resolved) ?? "" } as const;
}
export function calibrateScenarioScore(model: FinancialModel, company: string, holding: HoldingKey, code: string, rawValue: number,throughYear=1404): ScenarioScoreResult {
  const pairs = companyPoints(model, company, code,throughYear), meta = {...base(model, company, holding, code, rawValue, pairs),scoringVersion:`FY${throughYear}-FROZEN-COMPANY-v1`}, distinct = monotonicPoints(pairs);
  if (!HIGHER_IS_BETTER_CODES.has(code) || distinct.length < 2) {
    const last = [...pairs].sort((a, b) => b.year - a.year)[0];
    return { ...meta, score: last?.score ?? null, method: "carry-forward", scoreSource: "carry-forward", scoreConfidence: "limited", maxCalibrationError: null };
  }
  const linear = regression(pairs);
  if (linear && linear.maxError <= .1) return { ...meta, score: clamp(linear.a + linear.b * rawValue), method: "frozen-linear", scoreSource: "frozen-linear", scoreConfidence: "high", maxCalibrationError: linear.maxError };
  return { ...meta, score: piecewise(distinct, rawValue), method: "frozen-piecewise", scoreSource: "frozen-piecewise", scoreConfidence: "medium", maxCalibrationError: linear?.maxError ?? null };
}
export function carryForwardScenarioScore(model: FinancialModel, company: string, holding: HoldingKey, code: string, rawValue: number,throughYear=1404): ScenarioScoreResult {
  const pairs = companyPoints(model, company, code,throughYear), last = [...pairs].sort((a, b) => b.year - a.year)[0];
  return { ...base(model, company, holding, code, rawValue, pairs),scoringVersion:`FY${throughYear}-FROZEN-COMPANY-v1`, score: last?.score ?? null, method: "carry-forward", scoreSource: "carry-forward", scoreConfidence: "limited", maxCalibrationError: null };
}
