export type PolicyBand = "weak" | "medium" | "good";

export interface PolicyBaseState {
  code: string;
  matrix: number;
  x_band: PolicyBand;
  y_band: PolicyBand;
  x_band_fa: string;
  y_band_fa: string;
  title: string;
  status_sentence: string;
  micro_policy_title: string;
  micro_policy: string;
  priority_actions: string[];
  avoid_or_guardrail: string;
  severity: number;
  domain: string;
  source_codes: string[];
}

export interface PolicyFamily {
  title: string;
  posture: string;
  intro: string;
}

export interface TrendModifier {
  code: "T1" | "T2" | "T3" | "T4" | "T5";
  trend: string;
  urgency_effect: string;
  append_text: string;
}

type RuntimeCombination = [
  familyCode: string,
  severity: string,
  traceIndex: number,
  actionIndex: number,
  guardIndex: number,
  policyIndex: number,
  diagnosisIndex: number,
];

export interface PolicyRulebookRuntime {
  meta: {
    name: string;
    version: string;
    language: string;
    matrices: number;
    base_states: number;
    combinations: number;
    policy_families: number;
    score_boundaries: Record<string, string>;
    policy_precedence: string[];
    implementation_note: string;
  };
  state_orders: string[][];
  base_states: PolicyBaseState[];
  policy_families: Record<string, PolicyFamily>;
  trend_modifiers: TrendModifier[];
  traces: string[];
  guards: string[];
  actions: string[][];
  policies: string[];
  diagnoses: string[];
  combinations: RuntimeCombination[];
}

export interface PolicyMatrixInput {
  matrix: 1 | 2 | 3 | 4;
  xScore: number | null;
  yScore: number | null;
}

export interface ResolvedMatrixPolicy extends PolicyBaseState {
  xScore: number;
  yScore: number;
}

export interface PolicyResolution {
  combinationId: string;
  matrixStateCodes: string[];
  matrixStates: ResolvedMatrixPolicy[];
  familyCode: string;
  family: PolicyFamily;
  severity: string;
  ruleTrace: string;
  priorityActions: string[];
  guardrail: string;
  comprehensivePolicy: string;
  comprehensiveDiagnosis: string;
}

const BAND_CODE: Record<PolicyBand, string> = { weak: "W", medium: "M", good: "G" };

export const POLICY_BOUNDARY_WARNING_DISTANCE = 0.15;
const POLICY_BOUNDARIES = [3.33, 6.66] as const;

export function scoreToPolicyBand(score: number | null): PolicyBand | null {
  if (score === null || !Number.isFinite(score)) return null;
  if (score < 3.33) return "weak";
  if (score < 6.66) return "medium";
  return "good";
}

export function policyBoundaryDistance(score: number | null) {
  if (score === null || !Number.isFinite(score)) return null;
  return Math.min(...POLICY_BOUNDARIES.map((boundary) => Math.abs(score - boundary)));
}

export function isNearPolicyBoundary(score: number | null, tolerance = POLICY_BOUNDARY_WARNING_DISTANCE) {
  const distance = policyBoundaryDistance(score);
  return distance !== null && distance <= tolerance;
}

export function stateCodeForMatrix(matrix: number, xScore: number | null, yScore: number | null) {
  const xBand = scoreToPolicyBand(xScore);
  const yBand = scoreToPolicyBand(yScore);
  return xBand && yBand ? `M${matrix}-${BAND_CODE[xBand]}${BAND_CODE[yBand]}` : null;
}

export function resolveFinancialWatchPolicy(
  rulebook: PolicyRulebookRuntime,
  inputs: PolicyMatrixInput[],
): PolicyResolution | null {
  if (inputs.length !== 4) return null;
  const ordered = [...inputs].sort((a, b) => a.matrix - b.matrix);
  const codes = ordered.map((input) => stateCodeForMatrix(input.matrix, input.xScore, input.yScore));
  if (codes.some((code) => code === null)) return null;

  const positions = codes.map((code, index) => rulebook.state_orders[index]?.indexOf(code as string) ?? -1);
  if (positions.some((position) => position < 0)) return null;
  const combinationIndex = positions.reduce((offset, position) => offset * 9 + position, 0);
  const combination = rulebook.combinations[combinationIndex];
  if (!combination) return null;

  const [familyCode, severity, traceIndex, actionIndex, guardIndex, policyIndex, diagnosisIndex] = combination;
  const family = rulebook.policy_families[familyCode];
  const stateMap = new Map(rulebook.base_states.map((state) => [state.code, state]));
  const matrixStates = ordered.map((input, index) => {
    const state = stateMap.get(codes[index] as string);
    if (!state || input.xScore === null || input.yScore === null) return null;
    return { ...state, xScore: input.xScore, yScore: input.yScore };
  });
  if (!family || matrixStates.some((state) => state === null)) return null;

  return {
    combinationId: `C${String(combinationIndex + 1).padStart(4, "0")}`,
    matrixStateCodes: codes as string[],
    matrixStates: matrixStates as ResolvedMatrixPolicy[],
    familyCode,
    family,
    severity,
    ruleTrace: rulebook.traces[traceIndex],
    priorityActions: rulebook.actions[actionIndex],
    guardrail: rulebook.guards[guardIndex],
    comprehensivePolicy: rulebook.policies[policyIndex],
    comprehensiveDiagnosis: rulebook.diagnoses[diagnosisIndex],
  };
}

export function resolveTrendModifier(
  rulebook: PolicyRulebookRuntime,
  currentScores: Array<number | null>,
  previousScores: Array<number | null> | null,
  meaningfulChange = 0.25,
) {
  const byCode = new Map(rulebook.trend_modifiers.map((modifier) => [modifier.code, modifier]));
  if (!previousScores || currentScores.some((score) => score === null) || previousScores.some((score) => score === null)) {
    return { modifier: byCode.get("T4") ?? null, delta: null, criticalAxisDrops: [] as number[] };
  }

  const current = currentScores.reduce<number>((sum, score) => sum + (score ?? 0), 0) / currentScores.length;
  const previous = previousScores.reduce<number>((sum, score) => sum + (score ?? 0), 0) / previousScores.length;
  const delta = current - previous;

  // Axis order is defined by CHART_DEFINITIONS: indices 4 and 5 are liquidity strength
  // and financial structure. A meaningful decline in either blocks a positive trend label,
  // even when gains elsewhere lift the eight-axis average.
  const criticalAxisIndices = [4, 5];
  const criticalAxisDrops = criticalAxisIndices.filter((index) => {
    const currentScore = currentScores[index];
    const previousScore = previousScores[index];
    return currentScore !== null && previousScore !== null && currentScore - previousScore <= -meaningfulChange;
  });

  let code: TrendModifier["code"];
  if (delta <= -meaningfulChange) {
    code = "T3";
  } else if (criticalAxisDrops.length > 0) {
    code = "T5";
  } else if (delta >= meaningfulChange) {
    code = "T1";
  } else {
    code = "T2";
  }

  return { modifier: byCode.get(code) ?? null, delta, criticalAxisDrops };
}
