import type { FinancialModel } from "./financial-engine";
import type { ProfitModel } from "./profit-engine";
import type { ProductionModel } from "./investment-engine";
import type { HoldingKey } from "./company-resolver";
import { buildPlanningScenarioSnapshot } from "./planning-scenario-engine";
import { buildValueCreationAnalysis, type ValueSnapshot } from "./value-creation-engine";

export interface PortfolioPulseCompany {
  company: string;
  period: "actual" | "budget";
  year: 1403 | 1404 | 1405;
  investedCapital: number;
  beginningInvestedCapital: number | null;
  endingInvestedCapital: number | null;
  nopat: number;
  operatingProfit: number | null;
  taxRate: number;
  netProfit: number | null;
  roic: number;
  wacc: number;
  spread: number;
  economicProfit: number;
}

export interface PortfolioPulsePeriod {
  companies: PortfolioPulseCompany[];
  companyCount: number;
  investedCapital: number;
  nopat: number;
  netProfit: number | null;
  netProfitCompanyCount: number;
  profitableCount: number;
  lossMakingCount: number;
  roic: number;
  wacc: number;
  spread: number;
  economicProfit: number;
  valueCreatingCapital: number;
  valueDestroyingCapital: number;
  valueCreatingShare: number;
}

export interface PortfolioPulse {
  holding: HoldingKey;
  actual: PortfolioPulsePeriod | null;
  budget: PortfolioPulsePeriod | null;
  comparableActual: PortfolioPulsePeriod | null;
  comparableBudget: PortfolioPulsePeriod | null;
  universeCount: number;
  comparableCount: number;
  budgetCoverage: number;
  periods: Partial<Record<1403 | 1404 | 1405, PortfolioPulsePeriod>>;
}

export function decomposeCompanyRoicChange(previous: PortfolioPulseCompany, current: PortfolioPulseCompany) {
  if (!(previous.investedCapital > 0) || !(current.investedCapital > 0)) return null;
  const nopatEffect = (current.nopat - previous.nopat) / previous.investedCapital;
  const capitalEffect = current.nopat * (1 / current.investedCapital - 1 / previous.investedCapital);
  return { nopatEffect, capitalEffect, total: nopatEffect + capitalEffect, controlDifference: nopatEffect + capitalEffect - (current.roic - previous.roic) };
}

export function aggregatePortfolioRows(companies: PortfolioPulseCompany[]): PortfolioPulsePeriod | null {
  if (!companies.length) return null;
  const investedCapital = companies.reduce((sum, row) => sum + row.investedCapital, 0);
  if (!(investedCapital > 0)) return null;
  const nopat = companies.reduce((sum, row) => sum + row.nopat, 0);
  const netProfitRows = companies.filter((row) => row.netProfit !== null && Number.isFinite(row.netProfit));
  const netProfit = netProfitRows.length ? netProfitRows.reduce((sum, row) => sum + row.netProfit!, 0) : null;
  const capitalCharge = companies.reduce((sum, row) => sum + row.investedCapital * row.wacc, 0);
  const valueCreatingCapital = companies.filter((row) => row.spread >= 0).reduce((sum, row) => sum + row.investedCapital, 0);
  const valueDestroyingCapital = investedCapital - valueCreatingCapital;
  const roic = nopat / investedCapital;
  const wacc = capitalCharge / investedCapital;
  return {
    companies: [...companies].sort((a, b) => b.economicProfit - a.economicProfit),
    companyCount: companies.length,
    investedCapital,
    nopat,
    netProfit,
    netProfitCompanyCount: netProfitRows.length,
    profitableCount: netProfitRows.filter((row) => row.netProfit! >= 0).length,
    lossMakingCount: netProfitRows.filter((row) => row.netProfit! < 0).length,
    roic,
    wacc,
    spread: roic - wacc,
    economicProfit: nopat - capitalCharge,
    valueCreatingCapital,
    valueDestroyingCapital,
    valueCreatingShare: valueCreatingCapital / investedCapital,
  };
}

function actualRow(snapshot: ValueSnapshot): PortfolioPulseCompany | null {
  if (!(snapshot.averageIc > 0) || ![snapshot.nopat, snapshot.roic, snapshot.wacc, snapshot.spread].every(Number.isFinite)) return null;
  return {
    company: snapshot.company, period: "actual", year: snapshot.year as 1403 | 1404, investedCapital: snapshot.averageIc,
    beginningInvestedCapital: snapshot.beginningIc, endingInvestedCapital: snapshot.endIc,
    nopat: snapshot.nopat, operatingProfit: snapshot.operatingProfit, taxRate: snapshot.taxRate, netProfit: snapshot.netProfit, roic: snapshot.roic, wacc: snapshot.wacc, spread: snapshot.spread,
    economicProfit: snapshot.nopat - snapshot.averageIc * snapshot.wacc,
  };
}

export function buildPortfolioPulse(
  financial: FinancialModel,
  profit: ProfitModel | null,
  production: ProductionModel | null,
  holding: HoldingKey,
): PortfolioPulse {
  const actualRowsByYear = ([1403, 1404] as const).reduce((map, year) => {
    map[year] = financial.companies.flatMap((company) => {
      const analysis = buildValueCreationAnalysis(financial, profit, company, year);
      return analysis.selected?.year === year ? [actualRow(analysis.selected)].filter((row): row is PortfolioPulseCompany => row !== null) : [];
    });
    return map;
  }, {} as Record<1403 | 1404, PortfolioPulseCompany[]>);
  const actualRows = actualRowsByYear[1404];
  const budgetRows = financial.companies.flatMap((company) => {
    const s = buildPlanningScenarioSnapshot(financial, profit, production, holding, company);
    return s && s.assetSchedule.averageInvestedCapital > 0 ? [{
      company: s.company, period: "budget" as const, year: 1405 as const, investedCapital: s.assetSchedule.averageInvestedCapital,
      beginningInvestedCapital: null, endingInvestedCapital: null,
      nopat: s.nopat, operatingProfit: s.operatingProfit, taxRate: s.taxRate, netProfit: s.netProfit, roic: s.roic, wacc: s.wacc, spread: s.spread,
      economicProfit: s.nopat - s.assetSchedule.averageInvestedCapital * s.wacc,
    }] : [];
  });
  const actualByCompany = new Map(actualRows.map((row) => [row.company, row]));
  const budgetByCompany = new Map(budgetRows.map((row) => [row.company, row]));
  const common = [...actualByCompany.keys()].filter((company) => budgetByCompany.has(company));
  return {
    holding,
    actual: aggregatePortfolioRows(actualRows),
    budget: aggregatePortfolioRows(budgetRows),
    comparableActual: aggregatePortfolioRows(common.map((company) => actualByCompany.get(company)!)),
    comparableBudget: aggregatePortfolioRows(common.map((company) => budgetByCompany.get(company)!)),
    universeCount: financial.companies.length,
    comparableCount: common.length,
    budgetCoverage: actualRows.length ? common.length / actualRows.length : 0,
    periods: {
      1403: aggregatePortfolioRows(actualRowsByYear[1403]) ?? undefined,
      1404: aggregatePortfolioRows(actualRowsByYear[1404]) ?? undefined,
      1405: aggregatePortfolioRows(budgetRows) ?? undefined,
    },
  };
}
