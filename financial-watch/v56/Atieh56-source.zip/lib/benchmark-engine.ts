import * as XLSX from "xlsx";
import {monetaryFactor} from './data-reliability';
import {toEnglishDigits} from './financial-engine';

export const BENCHMARK_METRICS = [
  "revenueGrowth",
  "grossProfitGrowth",
  "operatingProfitGrowth",
  "netProfitGrowth",
  "cfoGrowth",
  "operatingMarginDelta",
  "cfoMarginDelta",
  "cfoToNi",
] as const;

export type BenchmarkMetricKey = (typeof BENCHMARK_METRICS)[number];
export type BenchmarkPosition = "atieh" | "competitor";

export interface BenchmarkMetricDefinition {
  key: BenchmarkMetricKey;
  label: string;
  shortLabel: string;
  unit: "%" | "pp" | "x";
  description: string;
  sourceTitle: string;
  kind: "growth" | "margin-delta" | "ratio";
}

export const BENCHMARK_METRIC_DEFINITIONS: Record<BenchmarkMetricKey, BenchmarkMetricDefinition> = {
  revenueGrowth: {
    key: "revenueGrowth",
    label: "رشد درآمد عملیاتی",
    shortLabel: "رشد درآمد",
    unit: "%",
    description: "درصد تغییر درآمد عملیاتی ۱۴۰۴ نسبت به ۱۴۰۳",
    sourceTitle: "درآمدهای عملیاتی",
    kind: "growth",
  },
  grossProfitGrowth: {
    key: "grossProfitGrowth",
    label: "رشد سود ناخالص",
    shortLabel: "سود ناخالص",
    unit: "%",
    description: "درصد تغییر سود ناخالص ۱۴۰۴ نسبت به ۱۴۰۳",
    sourceTitle: "سود (زیان) ناخالص",
    kind: "growth",
  },
  operatingProfitGrowth: {
    key: "operatingProfitGrowth",
    label: "رشد سود عملیاتی",
    shortLabel: "سود عملیاتی",
    unit: "%",
    description: "درصد تغییر سود عملیاتی ۱۴۰۴ نسبت به ۱۴۰۳",
    sourceTitle: "سود (زیان) عملیاتی",
    kind: "growth",
  },
  netProfitGrowth: {
    key: "netProfitGrowth",
    label: "رشد سود خالص",
    shortLabel: "سود خالص",
    unit: "%",
    description: "درصد تغییر سود خالص ۱۴۰۴ نسبت به ۱۴۰۳",
    sourceTitle: "سود (زیان) خالص",
    kind: "growth",
  },
  cfoGrowth: {
    key: "cfoGrowth",
    label: "رشد جریان نقد عملیاتی",
    shortLabel: "رشد CFO",
    unit: "%",
    description: "درصد تغییر جریان نقد عملیاتی ۱۴۰۴ نسبت به ۱۴۰۳",
    sourceTitle: "جریان خالص نقد حاصل از فعالیت های عملیاتی",
    kind: "growth",
  },
  operatingMarginDelta: {
    key: "operatingMarginDelta",
    label: "تغییر حاشیه سود عملیاتی",
    shortLabel: "حاشیه عملیاتی",
    unit: "pp",
    description: "اختلاف حاشیه سود عملیاتی ۱۴۰۴ و ۱۴۰۳ به واحد درصد",
    sourceTitle: "حاشیه سود عملیاتی",
    kind: "margin-delta",
  },
  cfoMarginDelta: {
    key: "cfoMarginDelta",
    label: "تغییر حاشیه جریان نقد عملیاتی",
    shortLabel: "حاشیه CFO",
    unit: "pp",
    description: "اختلاف CFO Margin سال ۱۴۰۴ و ۱۴۰۳ به واحد درصد",
    sourceTitle: "CFO Margin",
    kind: "margin-delta",
  },
  cfoToNi: {
    key: "cfoToNi",
    label: "کیفیت سود CFO/NI",
    shortLabel: "CFO/NI",
    unit: "x",
    description: "نسبت جریان نقد عملیاتی به سود خالص در سال ۱۴۰۴؛ بدون محاسبه رشد",
    sourceTitle: "CFO/NI",
    kind: "ratio",
  },
};

export interface BenchmarkValue {
  value: number | null;
  sortValue: number | null;
  label: string;
  status: "numeric" | "turnaround" | "deterioration" | "unavailable";
  previous: number | null;
  current: number | null;
  previousUnit: string;
  currentUnit: string;
}

export interface BenchmarkCompany {
  name: string;
  position: BenchmarkPosition;
  peerGroup: string;
  metrics: Record<BenchmarkMetricKey, BenchmarkValue>;
}

export interface BenchmarkModel {
  sourceRows?:Record<string,unknown>[];
  previousYear?:number;currentYear?:number;
  fileName: string;
  importedAt: Date;
  companies: BenchmarkCompany[];
  atiehCompanies: BenchmarkCompany[];
  competitors: BenchmarkCompany[];
  natures: string[];
  years: number[];
  warnings: string[];
  summary: {
    rows: number;
    companies: number;
    atiehCompanies: number;
    competitors: number;
    validMetrics: number;
    completeness: number;
  };
}

function clean(value: unknown) {
  return String(value ?? "")
    .replace(/[يى]/g, "ی")
    .replace(/ك/g, "ک")
    .replace(/[\u200c\u200f\u202a-\u202e]/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function numeric(value: unknown): number | null {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  const normalized = clean(value).replace(/,/g, "").replace(/[٪%]/g, "");
  if (!normalized) return null;
  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : null;
}

function formatMetric(value: number, unit: BenchmarkMetricDefinition["unit"]) {
  if (unit === "x") return `${value.toLocaleString("fa-IR", { maximumFractionDigits: 2 })}x`;
  if (unit === "pp") return `${value > 0 ? "+" : ""}${value.toLocaleString("fa-IR", { maximumFractionDigits: 1 })} واحد درصد`;
  return `${value > 0 ? "+" : ""}${value.toLocaleString("fa-IR", { maximumFractionDigits: 1 })}٪`;
}

function growth(previous: number | null, current: number | null, previousUnit = "", currentUnit = "", unit: "%" = "%"): BenchmarkValue {
  if (previous === null || current === null) {
    return { value: null, sortValue: null, label: "داده ناکافی", status: "unavailable", previous, current, previousUnit, currentUnit };
  }
  if (previous === 0) {
    return { value: null, sortValue: null, label: "N/A · مبنای صفر", status: "unavailable", previous, current, previousUnit, currentUnit };
  }
  if (previous < 0 && current >= 0) {
    return { value: null, sortValue: Number.POSITIVE_INFINITY, label: "خروج از زیان", status: "turnaround", previous, current, previousUnit, currentUnit };
  }
  if (previous >= 0 && current < 0) {
    return { value: null, sortValue: Number.NEGATIVE_INFINITY, label: "ورود به زیان", status: "deterioration", previous, current, previousUnit, currentUnit };
  }
  const value = ((current - previous) / Math.abs(previous)) * 100;
  return { value, sortValue: value, label: formatMetric(value, unit), status: "numeric", previous, current, previousUnit, currentUnit };
}

function marginDelta(previous: number | null, current: number | null, previousUnit = "%", currentUnit = "%"): BenchmarkValue {
  if (previous === null || current === null) {
    return { value: null, sortValue: null, label: "داده ناکافی", status: "unavailable", previous, current, previousUnit, currentUnit };
  }
  const value = (current - previous) * 100;
  return { value, sortValue: value, label: formatMetric(value, "pp"), status: "numeric", previous, current, previousUnit, currentUnit };
}

function ratio(current: number | null, currentUnit = "x"): BenchmarkValue {
  if (current === null || !Number.isFinite(current)) {
    return { value: null, sortValue: null, label: "داده ناکافی", status: "unavailable", previous: null, current, previousUnit: "", currentUnit };
  }
  return { value: current, sortValue: current, label: formatMetric(current, "x"), status: "numeric", previous: null, current, previousUnit: "", currentUnit };
}

export function peersFor(model: BenchmarkModel, company: BenchmarkCompany, allCompetitors = false) {
  if (allCompetitors) return model.competitors;
  return model.competitors.filter((candidate) => candidate.peerGroup === company.peerGroup);
}

export function percentileRank(rows: BenchmarkCompany[], metric: BenchmarkMetricKey, companyName: string) {
  const ranked = rows
    .filter((row) => row.metrics[metric].sortValue !== null)
    .sort((a, b) => (a.metrics[metric].sortValue as number) - (b.metrics[metric].sortValue as number));
  const index = ranked.findIndex((row) => row.name === companyName);
  if (index < 0) return null;
  return ranked.length <= 1 ? 100 : (index / (ranked.length - 1)) * 100;
}

export function medianMetric(rows: BenchmarkCompany[], metric: BenchmarkMetricKey): number | null {
  const values = rows
    .map((row) => row.metrics[metric].value)
    .filter((value): value is number => value !== null && Number.isFinite(value))
    .sort((a, b) => a - b);
  if (!values.length) return null;
  const middle = Math.floor(values.length / 2);
  return values.length % 2 ? values[middle] : (values[middle - 1] + values[middle]) / 2;
}

export function benchmarkMetricLabel(value: number | null, key: BenchmarkMetricKey) {
  if (value === null) return "—";
  return formatMetric(value, BENCHMARK_METRIC_DEFINITIONS[key].unit);
}

export async function parseBenchmarkWorkbook(file: File): Promise<BenchmarkModel> {
  const workbook = XLSX.read(await file.arrayBuffer(), { type: "array", cellDates: true });
  const required = ["جایگاه", "شرکت", "دوره مالی", "عنوان", "مبلغ", "واحد", "ماهیت"];
  let rows:Record<string,unknown>[]=[];
  for(const sheetName of workbook.SheetNames){const matrix=XLSX.utils.sheet_to_json<unknown[]>(workbook.Sheets[sheetName],{header:1,defval:null});const start=matrix.slice(0,30).findIndex(row=>required.every(key=>row.some(cell=>clean(cell)===clean(key))));if(start>=0){rows=XLSX.utils.sheet_to_json<Record<string,unknown>>(workbook.Sheets[sheetName],{range:start,defval:null});break;}}
  const headers = rows.length ? Object.keys(rows[0]).map(clean) : [];
  const missing = required.filter((column) => !headers.includes(clean(column)));
  if (missing.length) throw new Error(`ستون‌های الزامی فایل مقایسه موجود نیست: ${missing.join("، ")}`);

  return buildBenchmarkRows(rows,file.name);
}
export function buildBenchmarkRows(rows:Record<string,unknown>[],fileName:string,selectedYear?:number):BenchmarkModel {

  type SourceCell = { value: number | null; unit: string };
  const valueIndex = new Map<string, Map<number, Map<string, SourceCell>>>();
  const positionByCompany = new Map<string, BenchmarkPosition>();
  const natureByCompany = new Map<string, string>();
  const warnings: string[] = [];
  const years = new Set<number>();
  let duplicates = 0;

  for (const row of rows) {
    const name = clean(row["شرکت"]);
    const year = Number(toEnglishDigits(row["دوره مالی"]));
    const title = clean(row["عنوان"]);
    const nature = clean(row["ماهیت"]);
    if (!name || !Number.isInteger(year) || !title) continue;
    years.add(year);
    const position = clean(row["جایگاه"]).includes("آتیه") ? "atieh" : "competitor";
    positionByCompany.set(name, position);
    const registeredNature = natureByCompany.get(name);
    if (registeredNature && nature && registeredNature !== nature) {
      warnings.push(`برای شرکت «${name}» بیش از یک ماهیت ثبت شده است؛ آخرین مقدار استفاده شد.`);
    }
    if (nature) natureByCompany.set(name, nature);
    const byYear = valueIndex.get(name) ?? new Map<number, Map<string, SourceCell>>();
    const byTitle = byYear.get(year) ?? new Map<string, SourceCell>();
    if (byTitle.has(title)) duplicates += 1;
    const factor=monetaryFactor(row['واحد']),amount=numeric(row['مبلغ']);
    byTitle.set(title, { value: amount===null?null:amount*(factor??1), unit: factor===null?clean(row['واحد']):'میلیون ریال' });
    byYear.set(year, byTitle);
    valueIndex.set(name, byYear);
  }

  const currentYear=selectedYear??Math.max(...years),previousYear=currentYear-1;
  if (!years.has(previousYear) || !years.has(currentYear)) warnings.push(`برای مقایسه، داده هر دو سال ${previousYear} و ${currentYear} لازم است؛ سال دیگری جایگزین نمی‌شود.`);
  if (duplicates) warnings.push(`${duplicates.toLocaleString("fa-IR")} رکورد تکراری شناسایی شد؛ آخرین مقدار استفاده شده است.`);
  const missingNatureCompanies = [...valueIndex.keys()].filter((name) => !natureByCompany.get(name));
  if (missingNatureCompanies.length) warnings.push(`ماهیت ${missingNatureCompanies.length.toLocaleString("fa-IR")} شرکت تکمیل نشده و در طبقه «ماهیت نامشخص» قرار گرفت.`);

  const metricCell = (company: string, year: number, title: string): SourceCell => {
    const exact = valueIndex.get(company)?.get(year)?.get(clean(title));
    if (exact !== undefined) return exact;
    const entries = [...(valueIndex.get(company)?.get(year)?.entries() ?? [])];
    const wanted = clean(title);
    return entries.find(([candidate]) => clean(candidate) === wanted)?.[1] ?? { value: null, unit: "" };
  };

  const companies: BenchmarkCompany[] = [...valueIndex.keys()].map((name) => {
    const metrics = {} as Record<BenchmarkMetricKey, BenchmarkValue>;
    for (const key of BENCHMARK_METRICS) {
      const definition = BENCHMARK_METRIC_DEFINITIONS[key];
      const previousCell = metricCell(name, previousYear, definition.sourceTitle);
      const currentCell = metricCell(name, currentYear, definition.sourceTitle);
      const previous = previousCell.value;
      const current = currentCell.value;
      metrics[key] = definition.kind === "growth"
        ? growth(previous, current, previousCell.unit, currentCell.unit)
        : definition.kind === "margin-delta"
          ? marginDelta(previous, current, previousCell.unit, currentCell.unit)
          : ratio(current, currentCell.unit);
    }
    return {
      name,
      position: positionByCompany.get(name) ?? "competitor",
      peerGroup: natureByCompany.get(name) ?? "ماهیت نامشخص",
      metrics,
    };
  });

  const validMetrics = companies.reduce(
    (sum, company) => sum + BENCHMARK_METRICS.filter((key) => company.metrics[key].sortValue !== null).length,
    0,
  );
  const possibleMetrics = companies.length * BENCHMARK_METRICS.length;
  const atiehCompanies = companies.filter((company) => company.position === "atieh");
  const competitors = companies.filter((company) => company.position === "competitor");
  const natures = [...new Set(companies.map((company) => company.peerGroup))].sort((a, b) => a.localeCompare(b, "fa"));
  if (!atiehCompanies.length) throw new Error("هیچ شرکتی با جایگاه «آتیه» در فایل شناسایی نشد.");
  if (!competitors.length) throw new Error("هیچ شرکت رقیبی در فایل شناسایی نشد.");

  return {
    fileName,
    sourceRows:rows,previousYear,currentYear,
    importedAt: new Date(),
    companies,
    atiehCompanies,
    competitors,
    natures,
    years: [...years].sort((a, b) => a - b),
    warnings,
    summary: {
      rows: rows.length,
      companies: companies.length,
      atiehCompanies: atiehCompanies.length,
      competitors: competitors.length,
      validMetrics,
      completeness: possibleMetrics ? validMetrics / possibleMetrics : 0,
    },
  };
}
