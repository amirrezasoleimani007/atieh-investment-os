import { BENCHMARK_METRIC_DEFINITIONS, type BenchmarkMetricKey } from "./benchmark-engine";

const faNumber = (value: number, maximumFractionDigits = 1) => value.toLocaleString("fa-IR", {
  maximumFractionDigits,
  minimumFractionDigits: 0,
  useGrouping: true,
});

function cleanUnit(unit: string) {
  return unit
    .replace(/[يى]/g, "ی")
    .replace(/ك/g, "ک")
    .replace(/ميليون/g, "میلیون")
    .replace(/ميليارد/g, "میلیارد")
    .replace(/\s+/g, " ")
    .trim();
}

function monetaryScale(value: number, rawUnit: string) {
  const unit = cleanUnit(rawUnit);
  if (/میلیون.*ریال/.test(unit)) return { value, unit: "میلیون ریال" };
  if (/میلیارد.*ریال/.test(unit)) return { value: value * 1_000, unit: "میلیون ریال" };
  if (/هزار.*ریال/.test(unit)) return { value: value / 1_000, unit: "میلیون ریال" };
  if (/ریال/.test(unit)) return { value: value / 1_000_000, unit: "میلیون ریال" };
  return { value, unit: unit || "عدد ثبت‌شده" };
}

export function formatComputedBenchmark(value: number | null, metric: BenchmarkMetricKey) {
  if (value === null || !Number.isFinite(value)) return "—";
  const unit = BENCHMARK_METRIC_DEFINITIONS[metric].unit;
  const sign = value > 0 ? "+" : "";
  if (unit === "pp") return `${sign}${faNumber(value)} واحد درصد`;
  if (unit === "x") return `${faNumber(value, 2)}x`;
  return `${sign}${faNumber(value)}٪`;
}

export function formatRawBenchmark(value: number | null, metric: BenchmarkMetricKey, rawUnit = "", includeUnit = true) {
  if (value === null || !Number.isFinite(value)) return "—";
  const definition = BENCHMARK_METRIC_DEFINITIONS[metric];
  if (definition.kind === "margin-delta") return `${faNumber(value * 100)}٪`;
  if (definition.kind === "ratio") return `${faNumber(value, 2)}x`;
  const scaled = monetaryScale(value, rawUnit);
  return `${faNumber(scaled.value, 0)}${includeUnit ? ` ${scaled.unit}` : ""}`;
}

export function rawBenchmarkUnit(metric: BenchmarkMetricKey, rawUnit = "") {
  const definition = BENCHMARK_METRIC_DEFINITIONS[metric];
  if (definition.kind === "margin-delta") return "درصد";
  if (definition.kind === "ratio") return "برابر";
  return /ریال/.test(cleanUnit(rawUnit)) ? "میلیون ریال" : cleanUnit(rawUnit) || "واحد ثبت‌شده در فایل";
}
