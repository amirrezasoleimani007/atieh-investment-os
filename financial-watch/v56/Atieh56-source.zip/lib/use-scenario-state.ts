'use client';
import {useEffect,useState,type SetStateAction} from 'react';
export function useScenarioState<T>(key:string,initial:T,valid:(value:unknown)=>value is T){
 const read=()=>{try{const v=JSON.parse(localStorage.getItem('atieh-scenario-v49:'+key)??'null');return valid(v)?v:initial;}catch{return initial;}};
 const [state,setState]=useState<{key:string;value:T}>(()=>({key,value:read()}));
 const value=state.key===key?state.value:read();
 useEffect(()=>{if(state.key!==key)setState({key,value:read()});},[key]);
 const set=(next:SetStateAction<T>)=>{setState(current=>{const base=current.key===key?current.value:read();const v=typeof next==='function'?(next as (v:T)=>T)(base):next;if(!valid(v))return current;try{localStorage.setItem('atieh-scenario-v49:'+key,JSON.stringify(v));}catch{/* A blocked storage write does not prevent local use. */}return {key,value:v};});};
 return [value,set] as const;
}
export const finiteNumber=(v:unknown):v is number=>typeof v==='number'&&Number.isFinite(v);
export const stringValue=(v:unknown):v is string=>typeof v==='string';
export const marginMap=(v:unknown):v is Record<string,number>=>!!v&&typeof v==='object'&&!Array.isArray(v)&&Object.values(v).every(x=>finiteNumber(x)&&x>=-100&&x<=100);
