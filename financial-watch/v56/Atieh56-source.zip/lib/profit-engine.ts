import * as XLSX from "xlsx";
import {monetaryFactor} from './data-reliability';
import { normalizeText, parseNumeric, type FinancialModel, type FinancialRecord } from "@/lib/financial-engine";
import { canonicalCompanyKey, canonicalHolding, type HoldingKey } from "@/lib/company-resolver";

export interface ProfitIssue {
  row: number;
  severity: "warning" | "error";
  type: "missing-column" | "invalid-row" | "gross-profit-mismatch" | "total-mismatch" | "year-label" | "name-unmatched" | "unit-mismatch";
  message: string;
  company?: string;
}

export interface ProfitRecord {
  sourceRow: number;
  company: string;
  companyKey: string;
  group?: string;
  holding?: HoldingKey | null;
  rawYear: string;
  year: number;
  isBudget: boolean;
  yearLabelSuspect: boolean;
  unit: string;
  product: string;
  isTotal: boolean;
  revenue: number;
  rawCogs: number;
  normalizedCogs: number;
  reportedGrossProfit: number;
  calculatedGrossProfit: number;
  calculatedGrossMargin: number | null;
  budgetOperatingProfit: number | null;
  budgetNetProfit: number | null;
  grossProfitDifference: number;
}

export interface ProfitModel {
  fileName: string;
  importedAt: string;
  records: ProfitRecord[];
  companies: string[];
  issues: ProfitIssue[];
  summary: {
    rows: number;
    validRows: number;
    companies: number;
    actualYears: number[];
    budgetCompanies: number;
    warnings: number;
  };
}

const REQUIRED = [
  "شرکت",
  "سال",
  "واحد",
  "محصول",
  "درآمد عملیاتی",
  "بهای تمام شده درآمد عملیاتی",
  "سود ناخالص",
] as const;

export function profitCompanyKey(value: unknown) {
  return canonicalCompanyKey(value).toLocaleLowerCase("fa");
}

function normalizedHeader(value: unknown) {
  return normalizeText(value).replace(/[‌\s]+/g, " ").trim();
}

function findHeader(headers: string[], target: string) {
  const wanted = normalizedHeader(target);
  return headers.find((header) => normalizedHeader(header) === wanted) ?? "";
}

function readRows(data: ArrayBuffer) {
  const workbook = XLSX.read(data, { type: "array", cellDates: false, raw: true });
  for (const name of workbook.SheetNames) {
    const matrix=XLSX.utils.sheet_to_json<unknown[]>(workbook.Sheets[name],{header:1,defval:null,raw:true});
    const header=matrix.slice(0,30).findIndex(row=>REQUIRED.every(key=>row.some(cell=>normalizedHeader(cell)===normalizedHeader(key))));
    if(header>=0)return XLSX.utils.sheet_to_json<Record<string,unknown>>(workbook.Sheets[name],{range:header,defval:null,raw:true});
  }
  return [];
}

export function parseProfitWorkbook(data: ArrayBuffer, fileName: string): ProfitModel {
  const rows = readRows(data);
  if (!rows.length) throw new Error("فایل Profit فاقد ردیف داده قابل پردازش است.");
  const headers = Object.keys(rows[0] ?? {});
  const headerMap = new Map(REQUIRED.map((item) => [item, findHeader(headers, item)]));
  const missing = REQUIRED.filter((item) => !headerMap.get(item));
  if (missing.length) throw new Error(`ستون‌های الزامی Profit پیدا نشد: ${missing.join("، ")}`);

  const budgetOpHeader = headers.find(h=>/سود عملیاتی بودجه/.test(normalizedHeader(h)))??'';
  const budgetNetHeader = headers.find(h=>/سود خالص بودجه/.test(normalizedHeader(h)))??'';
  const groupHeader = findHeader(headers, "گروه");
  const issues: ProfitIssue[] = [];
  const records: ProfitRecord[] = [];

  rows.forEach((row, index) => {
    const sourceRow = index + 2;
    const company = normalizeText(row[headerMap.get("شرکت")!]);
    const product = normalizeText(row[headerMap.get("محصول")!]);
    const rawUnit=normalizeText(row[headerMap.get('واحد')!]);
    const factor=monetaryFactor(rawUnit);
    const unit=factor===null?rawUnit:'میلیون ریال';
    const money=(v:unknown)=>{const n=parseNumeric(v);return n===null?null:n*(factor??1);};
    const group = groupHeader ? normalizeText(row[groupHeader]) : "";
    const rawYear = normalizeText(row[headerMap.get("سال")!]);
    const budgetOperatingProfit = budgetOpHeader ? money(row[budgetOpHeader]) : null;
    const budgetNetProfit = budgetNetHeader ? money(row[budgetNetHeader]) : null;
    const declaredBudget = /بودجه|budget/i.test(rawYear);
    const budgetByTotals = budgetOperatingProfit !== null || budgetNetProfit !== null;
    const isBudget = declaredBudget || budgetByTotals;
    const yearLabelSuspect = budgetByTotals && !declaredBudget;
    const yearMatch = normalizeText(rawYear).match(/(13|14|15)\d{2}/);
    const headerYear=normalizeText(budgetOpHeader||budgetNetHeader).match(/(13|14|15)\d{2}/)?.[0];
    const year=Number(isBudget?(headerYear??yearMatch?.[0]):yearMatch?.[0]);
    const revenue = money(row[headerMap.get("درآمد عملیاتی")!]);
    const rawCogs = money(row[headerMap.get("بهای تمام شده درآمد عملیاتی")!]);
    const reportedGrossProfit = money(row[headerMap.get("سود ناخالص")!]);
    if (!company || !product || !unit || !Number.isFinite(year) || revenue === null || rawCogs === null || reportedGrossProfit === null) {
      issues.push({ row: sourceRow, severity: "error", type: "invalid-row", company, message: "ردیف به علت کسری نام شرکت، محصول، واحد، سال یا مبلغ قابل استفاده نیست." });
      return;
    }
    const normalizedCogs = Math.abs(rawCogs);
    const calculatedGrossProfit = revenue - normalizedCogs;
    const grossProfitDifference = reportedGrossProfit - calculatedGrossProfit;
    const tolerance = Math.max(1, Math.abs(revenue) * 0.001);
    if (Math.abs(grossProfitDifference) > tolerance) {
      issues.push({ row: sourceRow, severity: "warning", type: "gross-profit-mismatch", company, message: `سود ناخالص ثبت‌شده با درآمد منهای قدرمطلق بهای تمام‌شده ${Math.round(Math.abs(grossProfitDifference)).toLocaleString("fa-IR")} واحد اختلاف دارد.` });
    }
    if (yearLabelSuspect) {
      issues.push({ row: sourceRow, severity: "warning", type: "year-label", company, message: "احتمال خطای برچسب سال در ردیف جمع بودجه؛ سال بودجه از عنوان ستون بودجه استخراج شد؛ برچسب ردیف نیازمند کنترل است." });
    }
    records.push({
      sourceRow,
      company,
      companyKey: profitCompanyKey(company),
      group,
      holding: canonicalHolding(group),
      rawYear,
      year,
      isBudget,
      yearLabelSuspect,
      unit,
      product,
      isTotal: profitCompanyKey(product) === "جمع",
      revenue,
      rawCogs,
      normalizedCogs,
      reportedGrossProfit,
      calculatedGrossProfit,
      calculatedGrossMargin: revenue === 0 ? null : calculatedGrossProfit / revenue,
      budgetOperatingProfit,
      budgetNetProfit,
      grossProfitDifference,
    });
  });

  const groups = new Map<string, ProfitRecord[]>();
  for (const record of records) {
    const key = `${record.companyKey}|${record.year}|${record.isBudget ? "B" : "A"}|${profitCompanyKey(record.unit)}`;
    groups.set(key, [...(groups.get(key) ?? []), record]);
  }
  for (const group of groups.values()) {
    const total = group.find((item) => item.isTotal);
    const details = group.filter((item) => !item.isTotal);
    if (!total || !details.length) continue;
    const detailRevenue = details.reduce((sum, item) => sum + item.revenue, 0);
    const detailGp = details.reduce((sum, item) => sum + item.calculatedGrossProfit, 0);
    const delta = Math.max(Math.abs(total.revenue - detailRevenue), Math.abs(total.calculatedGrossProfit - detailGp));
    if (delta > Math.max(1, Math.abs(total.revenue) * 0.001)) {
      issues.push({ row: total.sourceRow, severity: "warning", type: "total-mismatch", company: total.company, message: "ردیف جمع با مجموع ردیف‌های محصول تطبیق کامل ندارد و در کنترل کیفیت علامت‌گذاری شد." });
    }
  }

  const companies = [...new Set(records.map((item) => item.company))].sort((a, b) => a.localeCompare(b, "fa"));
  return {
    fileName,
    importedAt: new Date().toISOString(),
    records,
    companies,
    issues,
    summary: {
      rows: rows.length,
      validRows: records.length,
      companies: companies.length,
      actualYears: [...new Set(records.filter((item) => !item.isBudget).map((item) => item.year))].sort(),
      budgetCompanies: new Set(records.filter((item) => item.isBudget).map((item) => item.companyKey)).size,
      warnings: issues.length,
    },
  };
}

export function financialRecordByCode(model: FinancialModel, company: string, year: number, code: string): FinancialRecord | undefined {
  const resolved = model.companies.find((item) => profitCompanyKey(item) === profitCompanyKey(company));
  return resolved ? model.codeIndex.get(resolved)?.get(year)?.get(code) : undefined;
}

export function profitRecordsForCompany(model: ProfitModel | null, company: string, holding?: HoldingKey) {
  if (!model) return [];
  const key = profitCompanyKey(company);
  return model.records.filter((record) => record.companyKey === key && (!holding || !record.holding || record.holding === holding));
}
