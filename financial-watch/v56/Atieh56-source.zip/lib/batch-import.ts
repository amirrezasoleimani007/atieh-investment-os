import {parseFinancialWorkbook} from './workbook-parser';
import {parseMarketWorkbook} from './market-engine';
import {parseBenchmarkWorkbook} from './benchmark-engine';
import {parseProductionWorkbook} from './investment-engine';
import {parseProfitWorkbook} from './profit-engine';
import {parseAssetWorkbook,parseMetilActivityWorkbook,parseEquipmentWorkbook} from './investment-data-engine';
import {canonicalCompanyKey} from './company-resolver';
export const IMPORT_LABELS={atieh:'مالی آتیه',metil:'مالی متیل',market:'ارزیابی بازار',benchmark:'پایش تطبیقی',product:'تولید و بهره‌برداری',profit:'سود و بودجه محصولات',asset:'دارایی‌ها',activity:'فعالیت متیل',equipment:'تجهیزات متیل'} as const;
export type ImportTarget=keyof typeof IMPORT_LABELS;
export interface ImportCandidate {file:File;bytes:ArrayBuffer;targets:ImportTarget[];target:ImportTarget|'';error:string;replace:boolean}
export async function parseImport(file:File,bytes:ArrayBuffer,target:ImportTarget):Promise<any>{
  if(target==='atieh'||target==='metil'){
    const m=parseFinancialWorkbook(bytes,file.name);if(m.missingColumns.length||!m.validRecords.length)throw Error('ستون‌ها یا رکوردهای مالی کامل نیست.');return m;
  }
  let result:any;
  switch(target){case 'market':result=parseMarketWorkbook(bytes,file.name);break;case 'benchmark':result=await parseBenchmarkWorkbook(new File([bytes],file.name));break;case 'product':result=parseProductionWorkbook(bytes,file.name);break;case 'profit':result=parseProfitWorkbook(bytes,file.name);break;case 'asset':result=parseAssetWorkbook(bytes,file.name);break;case 'activity':result=parseMetilActivityWorkbook(bytes,file.name);break;case 'equipment':result=parseEquipmentWorkbook(bytes,file.name);break;}
  const rows=result.records??result.companies;if(!Array.isArray(rows)||!rows.length)throw Error('فایل فاقد داده معتبر است.');return result;
}
export async function inspectImport(file:File):Promise<ImportCandidate>{
  const bytes=await file.arrayBuffer();const targets:ImportTarget[]=[];
  if(!/\.(xlsx|xls|csv)$/i.test(file.name))return {file,bytes,targets,target:'',replace:false,error:'فرمت فایل پشتیبانی نمی‌شود.'};
  const parsers:ImportTarget[]=['atieh','market','benchmark','product','profit','asset','activity','equipment'];
  for(const kind of parsers){try{const m=await parseImport(file,bytes,kind);
    if(kind==='atieh'){
      const keys=m.companies.map(canonicalCompanyKey);const atieh=keys.includes(canonicalCompanyKey('آتیه فولاد نقش جهان')),metil=keys.includes(canonicalCompanyKey('فولاد متیل'));
      if(atieh)targets.push('atieh');else if(metil)targets.push('metil');else targets.push('atieh','metil');
    }else targets.push(kind);
  }catch{/* Candidate detection never mutates active data. */}}
  return {file,bytes,targets,target:targets.length===1?targets[0]:'',replace:false,error:targets.length?'':'ساختار فایل شناخته نشد؛ نوع فایل را انتخاب کنید تا خطای دقیق نشان داده شود.'};
}
