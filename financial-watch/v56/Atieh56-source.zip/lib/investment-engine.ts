import * as XLSX from "xlsx";
import {
  normalizeText,
  type FinancialModel,
  type FinancialRecord,
} from "./financial-engine";
import { canonicalCompanyKey } from "./investment-data-engine";
import type { ProfitModel } from "./profit-engine";
import {
  buildPlanningScenarioSnapshot,
  buildScenarioAssetComposition,
} from "./planning-scenario-engine";
import { calculateCompanyUtilization } from "./utilization-engine";

export const INVESTMENT_COMPONENTS = [
  {
    code: "176",
    key: "spread",
    label: "اسپرد ارزش‌آفرینی",
    shortLabel: "اسپرد",
    defaultWeight: 0.4,
  },
  {
    code: "150",
    key: "roic",
    label: "بازده سرمایه‌گذاری ROIC",
    shortLabel: "ROIC",
    defaultWeight: 0.25,
  },
  {
    code: "175",
    key: "fcfMargin",
    label: "حاشیه جریان نقد آزاد",
    shortLabel: "FCF Margin",
    defaultWeight: 0.2,
  },
  {
    code: "144",
    key: "revenueGrowth",
    label: "رشد درآمد",
    shortLabel: "رشد درآمد",
    defaultWeight: 0.15,
  },
] as const;

export type InvestmentComponentKey =
  (typeof INVESTMENT_COMPONENTS)[number]["key"];
export type InvestmentWeights = Record<InvestmentComponentKey, number>;

export const DEFAULT_INVESTMENT_WEIGHTS: InvestmentWeights = {
  spread: 0.4,
  roic: 0.25,
  fcfMargin: 0.2,
  revenueGrowth: 0.15,
};

export const WORKING_CAPITAL_DRIVERS = [
  { code: "165", key: "dio", label: "روزهای نگهداری موجودی (DIO)" },
  { code: "166", key: "dso", label: "روزهای وصول مطالبات (DSO)" },
  { code: "167", key: "dpo", label: "روزهای پرداخت بدهی (DPO)" },
  { code: "168", key: "ccc", label: "چرخه تبدیل نقد (CCC)" },
] as const;

export const ASSET_COMPONENTS = [
  { key: "receivables", label: "مطالبات", codes: ["129"], color: "#0f8a78" },
  { key: "inventory", label: "موجودی", codes: ["128"], color: "#2563eb" },
  { key: "cash", label: "نقد", codes: ["130"], color: "#d69a1e" },
  {
    key: "investments",
    label: "سرمایه‌گذاری‌ها",
    codes: ["132", "127"],
    color: "#8b5cf6",
  },
  {
    key: "fixed",
    label: "دارایی ثابت و نامشهود",
    codes: ["125", "126"],
    color: "#dd6b4d",
  },
] as const;

export interface ProductionRecord {
  sourceRow: number;
  company: string;
  equipment: string;
  year: number;
  capacity: number | null;
  production: number | null;
  utilization: number | null;
  grossMargin: number | null;
  salesRevenue: number | null;
}

export interface ProductionIssue {
  severity: "warning" | "error";
  message: string;
  row?: number;
}

export interface ProductionModel {
  fileName: string;
  importedAt: string;
  records: ProductionRecord[];
  companies: string[];
  years: number[];
  issues: ProductionIssue[];
  summary: {
    totalRows: number;
    validRows: number;
    companies: number;
    years: number;
    productionLines: number;
    warnings: number;
  };
}

export interface InvestmentComponentResult {
  code: string;
  key: InvestmentComponentKey;
  label: string;
  rawValue: number | null;
  unit: string;
  score: number | null;
  configuredWeight: number;
  effectiveWeight: number;
  contribution: number;
  sourceYear: number;
  scoreSource?: string;
  calibrationYears?: number[];
}

export interface WorkingCapitalDriverResult {
  code: string;
  key: "dio" | "dso" | "dpo" | "ccc";
  label: string;
  rawValue: number | null;
  unit: string;
}

export interface AssetCompositionResult {
  key: "receivables" | "inventory" | "cash" | "investments" | "fixed" | "other";
  label: string;
  amount: number | null;
  share: number | null;
  color: string;
  complete: boolean;
  codes: string[];
}

export interface AssetProductivityResult {
  rawTurnover: number | null;
  storedTurnover: number | null;
  turnoverScore: number;
  revenue: number | null;
  totalAssetsBeginning: number | null;
  totalAssetsEnding: number | null;
  averageTotalAssets: number | null;
  assetComposition: AssetCompositionResult[];
  workingCapitalDrivers: WorkingCapitalDriverResult[];
  dataCoverage: number;
  reconciliationDifference: number | null;
  reconciliationOk: boolean | null;
}

export interface ProductGroupResult {
  label: string;
  capacity: number;
  production: number;
  utilization: number | null;
  revenue: number | null;
  weight: number;
}

export interface InvestmentPoint {
  id: string;
  company: string;
  year: number;
  x: number;
  y: number;
  isForecast: boolean;
  pointType: "actual" | "budget" | "optimized";
  capitalSourceYear: number;
  capitalCoverage: number;
  components: InvestmentComponentResult[];
  assetProductivity: AssetProductivityResult | null;
  verticalMetric: "utilization" | "asset-productivity";
  verticalLabel: string;
  verticalMethod: string;
  productionRows: ProductionRecord[];
  productGroups: ProductGroupResult[];
  warnings: string[];
}

const HEADER_ALIASES = {
  company: ["شرکت", "نام شرکت"],
  equipment: ["تجهیز", "تجهیزات", "خط تولید", "ماشین آلات"],
  year: ["سال", "دوره"],
  capacity: ["ظرفیت", "ظرفیت اسمی", "ظرفیت تولید"],
  production: ["تولید", "مقدار تولید", "تولید واقعی"],
  utilization: ["نرخ بهره برداری", "ضریب بهره برداری", "بهره برداری"],
  grossMargin: ["حاشیه سود ناخالص"],
  salesRevenue: ["درآمد فروش", "فروش", "درآمد محصول", "مبلغ فروش"],
} as const;

function asNumber(value: unknown): number | null {
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  if (value === null || value === undefined || value === "") return null;
  const normalized = String(value)
    .replace(/[٬,،\s]/g, "")
    .replace(/[−–—]/g, "-")
    .replace(/[۰-۹]/g, (digit) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(digit)));
  const parsed = Number(normalized);
  return Number.isFinite(parsed) ? parsed : null;
}

function findHeader(headers: string[], aliases: readonly string[]): number {
  return headers.findIndex((header) =>
    aliases.some((alias) => header === normalizeText(alias)),
  );
}

function selectProductionSheet(workbook: XLSX.WorkBook) {
  const candidates = workbook.SheetNames.flatMap((sheetName, sheetIndex) => {
    const sheet = workbook.Sheets[sheetName];
    if (!sheet) return [];
    const rows = XLSX.utils.sheet_to_json<unknown[]>(sheet, {
      header: 1,
      raw: true,
      defval: null,
    });
    return rows.slice(0, 20).map((row, headerRow) => {
      const headers = row.map((value) => normalizeText(value));
      const requiredHits = [
        HEADER_ALIASES.company,
        HEADER_ALIASES.year,
        HEADER_ALIASES.capacity,
        HEADER_ALIASES.utilization,
      ].filter((aliases) => findHeader(headers, aliases) >= 0).length;
      return {
        sheet,
        sheetName,
        sheetIndex,
        headerRow,
        headers,
        requiredHits,
        rowCount: rows.length,
      };
    });
  });
  const selected = candidates.sort(
    (a, b) =>
      b.requiredHits - a.requiredHits ||
      b.rowCount - a.rowCount ||
      a.sheetIndex - b.sheetIndex ||
      a.headerRow - b.headerRow,
  )[0];
  if (!selected || selected.requiredHits < 3) {
    throw new Error(
      "شیت تولید با ستون‌های شرکت، سال، ظرفیت و ضریب بهره‌برداری پیدا نشد.",
    );
  }
  return selected;
}

export function parseProductionWorkbook(
  data: ArrayBuffer,
  fileName: string,
): ProductionModel {
  const workbook = XLSX.read(data, {
    type: "array",
    cellDates: false,
    cellFormula: false,
    raw: true,
  });
  if (!workbook.SheetNames.length)
    throw new Error("فایل تولید فاقد شیت قابل خواندن است.");
  const selected = selectProductionSheet(workbook);
  const rows = XLSX.utils.sheet_to_json<unknown[]>(selected.sheet, {
    header: 1,
    range: selected.headerRow + 1,
    raw: true,
    defval: null,
    blankrows: false,
  });
  const indices = {
    company: findHeader(selected.headers, HEADER_ALIASES.company),
    equipment: findHeader(selected.headers, HEADER_ALIASES.equipment),
    year: findHeader(selected.headers, HEADER_ALIASES.year),
    capacity: findHeader(selected.headers, HEADER_ALIASES.capacity),
    production: findHeader(selected.headers, HEADER_ALIASES.production),
    utilization: findHeader(selected.headers, HEADER_ALIASES.utilization),
    grossMargin: findHeader(selected.headers, HEADER_ALIASES.grossMargin),
    salesRevenue: findHeader(selected.headers, HEADER_ALIASES.salesRevenue),
  };
  const issues: ProductionIssue[] = [];
  const records = rows.flatMap((row, index): ProductionRecord[] => {
    const sourceRow = selected.headerRow + index + 2;
    const company =
      indices.company >= 0 ? String(row[indices.company] ?? "").trim() : "";
    const year = indices.year >= 0 ? asNumber(row[indices.year]) : null;
    if (!company || year === null) {
      issues.push({
        severity: "error",
        message: "نام شرکت یا سال معتبر نیست.",
        row: sourceRow,
      });
      return [];
    }
    const capacity =
      indices.capacity >= 0 ? asNumber(row[indices.capacity]) : null;
    let production =
      indices.production >= 0 ? asNumber(row[indices.production]) : null;
    const utilization =
      indices.utilization >= 0 ? asNumber(row[indices.utilization]) : null;
    if (production === null && capacity !== null && utilization !== null)
      production = capacity * utilization;
    if (capacity !== null && capacity < 0)
      issues.push({
        severity: "warning",
        message: "ظرفیت منفی ثبت شده است.",
        row: sourceRow,
      });
    return [
      {
        sourceRow,
        company,
        equipment:
          indices.equipment >= 0
            ? String(row[indices.equipment] ?? "").trim()
            : "",
        year: Math.trunc(year),
        capacity,
        production,
        utilization:
          utilization ??
          (capacity && production !== null ? production / capacity : null),
        grossMargin:
          indices.grossMargin >= 0 ? asNumber(row[indices.grossMargin]) : null,
        salesRevenue:
          indices.salesRevenue >= 0
            ? asNumber(row[indices.salesRevenue])
            : null,
      },
    ];
  });

  const duplicateKeys = new Map<string, number[]>();
  for (const record of records) {
    const key = [
      normalizeText(record.company),
      normalizeText(record.equipment),
      record.year,
    ].join("|");
    duplicateKeys.set(key, [
      ...(duplicateKeys.get(key) ?? []),
      record.sourceRow,
    ]);
  }
  for (const rowsForKey of duplicateKeys.values()) {
    if (rowsForKey.length > 1)
      issues.push({
        severity: "warning",
        message: `تجهیز مشابه در یک سال چند بار ثبت شده است (ردیف‌های ${rowsForKey.join("، ")})؛ ردیف‌های مستقل به‌عنوان خطوط مستقل کنترل می‌شوند.`,
      });
  }
  const companies = [...new Set(records.map((record) => record.company))].sort(
    (a, b) => a.localeCompare(b, "fa"),
  );
  const years = [...new Set(records.map((record) => record.year))].sort(
    (a, b) => a - b,
  );
  return {
    fileName,
    importedAt: new Date().toISOString(),
    records,
    companies,
    years,
    issues,
    summary: {
      totalRows: rows.length,
      validRows: records.length,
      companies: companies.length,
      years: years.length,
      productionLines: records.filter((record) => (record.capacity ?? 0) > 0)
        .length,
      warnings: issues.length,
    },
  };
}

function findFinancialRecord(
  model: FinancialModel,
  company: string,
  year: number,
  code: string,
): FinancialRecord | undefined {
  return model.codeIndex.get(company)?.get(year)?.get(code);
}

function validValue(record: FinancialRecord | undefined) {
  return record?.value !== null &&
    record?.value !== undefined &&
    Number.isFinite(record.value)
    ? record.value
    : null;
}

function averageCode(
  model: FinancialModel,
  company: string,
  year: number,
  code: string,
) {
  const beginning = validValue(
    findFinancialRecord(model, company, year - 1, code),
  );
  const ending = validValue(findFinancialRecord(model, company, year, code));
  return beginning === null || ending === null
    ? null
    : (beginning + ending) / 2;
}

export function buildAssetProductivity(
  model: FinancialModel,
  company: string,
  year: number,
): { result: AssetProductivityResult | null; warnings: string[] } {
  const warnings: string[] = [];
  const turnoverRecord = findFinancialRecord(model, company, year, "152");
  const turnoverScore =
    turnoverRecord?.score !== null &&
    turnoverRecord?.score !== undefined &&
    turnoverRecord.score >= 0 &&
    turnoverRecord.score <= 10
      ? turnoverRecord.score
      : null;
  if (turnoverScore === null)
    return {
      result: null,
      warnings: [
        "امتیاز معتبر گردش دارایی‌ها (کد ۱۵۲) موجود نیست؛ نقطه ساخته نشد.",
      ],
    };

  const revenue = validValue(findFinancialRecord(model, company, year, "111"));
  const totalAssetsBeginning = validValue(
    findFinancialRecord(model, company, year - 1, "134"),
  );
  const totalAssetsEnding = validValue(
    findFinancialRecord(model, company, year, "134"),
  );
  const averageTotalAssets =
    totalAssetsBeginning === null || totalAssetsEnding === null
      ? null
      : (totalAssetsBeginning + totalAssetsEnding) / 2;
  const rawTurnover =
    revenue !== null && averageTotalAssets !== null && averageTotalAssets !== 0
      ? revenue / averageTotalAssets
      : null;
  const storedTurnover = validValue(turnoverRecord);
  if (averageTotalAssets === null)
    warnings.push(
      "کل دارایی ابتدا یا انتهای دوره موجود نیست؛ متوسط کل دارایی و ترکیب آن قابل محاسبه نیست.",
    );
  if (rawTurnover !== null && storedTurnover !== null) {
    const turnoverTolerance = Math.max(0.02, Math.abs(storedTurnover) * 0.01);
    if (Math.abs(rawTurnover - storedTurnover) > turnoverTolerance)
      warnings.push(
        "مقدار ذخیره‌شده گردش دارایی با درآمد ÷ متوسط کل دارایی سازگار نیست.",
      );
  }

  const known = ASSET_COMPONENTS.map((definition) => {
    const averages = definition.codes.map((code) =>
      averageCode(model, company, year, code),
    );
    const complete = averages.every((value) => value !== null);
    return {
      key: definition.key,
      label: definition.label,
      amount: complete
        ? averages.reduce<number>((sum, value) => sum + (value ?? 0), 0)
        : null,
      share: null,
      color: definition.color,
      complete,
      codes: [...definition.codes],
    } satisfies AssetCompositionResult;
  });
  const completeKnownSum = known.reduce(
    (sum, item) => sum + (item.amount ?? 0),
    0,
  );
  const otherAmount =
    averageTotalAssets === null ? null : averageTotalAssets - completeKnownSum;
  const tolerance =
    averageTotalAssets === null
      ? 0
      : Math.max(1, Math.abs(averageTotalAssets) * 0.000001);
  if (known.some((item) => !item.complete))
    warnings.push(
      "تفکیک بعضی اقلام دارایی کامل نیست؛ مبلغ تفکیک‌نشده در «سایر دارایی‌ها» باقی مانده است.",
    );
  if (otherAmount !== null && otherAmount < -tolerance)
    warnings.push(
      "جمع اجزای شناخته‌شده از متوسط کل دارایی بیشتر است؛ «سایر دارایی‌ها» منفی و کیفیت داده نیازمند بررسی است.",
    );
  const other: AssetCompositionResult = {
    key: "other",
    label: "سایر دارایی‌ها",
    amount: otherAmount,
    share:
      averageTotalAssets && otherAmount !== null
        ? otherAmount / averageTotalAssets
        : null,
    color: "#64748b",
    complete: known.every((item) => item.complete),
    codes: [],
  };
  const assetComposition = [...known, other].map((item) => ({
    ...item,
    share:
      averageTotalAssets && item.amount !== null
        ? item.amount / averageTotalAssets
        : null,
  }));
  const compositionSum = assetComposition.reduce(
    (sum, item) => sum + (item.amount ?? 0),
    0,
  );
  const reconciliationDifference =
    averageTotalAssets === null ? null : compositionSum - averageTotalAssets;
  const reconciliationOk =
    reconciliationDifference === null
      ? null
      : Math.abs(reconciliationDifference) <= tolerance;
  if (reconciliationOk === false)
    warnings.push("جمع ترکیب دارایی‌ها با متوسط کل دارایی Reconcile نمی‌شود.");

  const workingCapitalDrivers = WORKING_CAPITAL_DRIVERS.map((definition) => {
    const record = findFinancialRecord(model, company, year, definition.code);
    return {
      code: definition.code,
      key: definition.key,
      label: definition.label,
      rawValue: validValue(record),
      unit: "روز",
    };
  });
  return {
    result: {
      rawTurnover,
      storedTurnover,
      turnoverScore,
      revenue,
      totalAssetsBeginning,
      totalAssetsEnding,
      averageTotalAssets,
      assetComposition,
      workingCapitalDrivers,
      dataCoverage: known.filter((item) => item.complete).length / known.length,
      reconciliationDifference,
      reconciliationOk,
    },
    warnings,
  };
}

function normalizedWeights(weights: InvestmentWeights): InvestmentWeights {
  const safe = Object.fromEntries(
    Object.entries(weights).map(([key, value]) => [
      key,
      Math.max(0, Number.isFinite(value) ? value : 0),
    ]),
  ) as InvestmentWeights;
  const total = Object.values(safe).reduce((sum, value) => sum + value, 0);
  if (total <= 0) return { ...DEFAULT_INVESTMENT_WEIGHTS };
  return Object.fromEntries(
    Object.entries(safe).map(([key, value]) => [key, value / total]),
  ) as InvestmentWeights;
}

function productRevenueFromFinancial(
  model: FinancialModel,
  company: string,
  year: number,
  product: string,
) {
  const tokens = product === "بنتونیت" ? /بنتونیت/ : /کورد|وایر/;
  return (
    model.validRecords
      .filter(
        (record) =>
          record.company === company &&
          record.year === year &&
          tokens.test(record.normalizedVariable) &&
          /فروش|درآمد/.test(record.normalizedVariable),
      )
      .map((record) => record.value)
      .find((value): value is number => value !== null && value >= 0) ?? null
  );
}

function aggregateUtilization(
  model: FinancialModel,
  company: string,
  year: number,
  rows: ProductionRecord[],
) {
  const result = calculateCompanyUtilization(company, rows);
  return {
    value: result.value,
    method: result.method,
    warnings: result.warnings,
    groups: result.groups.map((group) => ({
      ...group,
      revenue: productRevenueFromFinancial(model, company, year, group.label),
    })),
  };
}

export function buildInvestmentPoints(
  financialModel: FinancialModel,
  productionModel: ProductionModel | null,
  weights: InvestmentWeights,
  holding: "atieh" | "metil" = "atieh",
  profitModel: ProfitModel | null = null,
): InvestmentPoint[] {
  const effectiveWeights = normalizedWeights(weights);
  const productionYears =
    holding === "atieh" ? (productionModel?.years ?? []) : [];
  const budgetYears=[...new Set(profitModel?.records.filter(row=>row.isBudget&&(!row.holding||row.holding===holding)).map(row=>row.year)??[])];
  const periods=[...financialModel.years.map(year=>({year,isBudget:false})),...budgetYears.map(year=>({year,isBudget:true}))].sort((a,b)=>a.year-b.year);
  const latestActualYear =
    financialModel.years.filter((year) => year <= 1404).at(-1) ??
    financialModel.years.at(-1) ??
    1404;
  const points: InvestmentPoint[] = [];
  for (const company of financialModel.companies) {
    const companyKey = canonicalCompanyKey(company);
    const isProductionCompany =
      holding === "atieh" &&
      Boolean(
        productionModel?.records.some(
          (record) =>
            canonicalCompanyKey(record.company) === companyKey &&
            (record.capacity ?? 0) > 0,
        ),
      );
    for (const {year,isBudget} of periods) {
      if (isBudget) {
        const snapshot = buildPlanningScenarioSnapshot(
          financialModel,
          profitModel,
          productionModel,
          holding,
          company,
          {budgetYear:year},
        );
        if (!snapshot || snapshot.map.x === null || snapshot.map.y === null)
          continue;
        const components = INVESTMENT_COMPONENTS.map(
          (definition): InvestmentComponentResult => {
            const rawValues: Record<string, number | null> = {
              "176": snapshot.spread,
              "150": snapshot.roic,
              "175": snapshot.fcfMargin,
              "144": snapshot.revenueGrowth,
            };
            const score = snapshot.scores[definition.code]?.score ?? null;
            const scoreMeta = snapshot.scores[definition.code];
            return {
              code: definition.code,
              key: definition.key,
              label: definition.label,
              rawValue: rawValues[definition.code],
              unit: "درصد",
              score,
              configuredWeight: weights[definition.key],
              effectiveWeight: effectiveWeights[definition.key],
              contribution:
                score === null
                  ? 0
                  : (score / 10) * effectiveWeights[definition.key],
              sourceYear: year,
              scoreSource: scoreMeta?.scoreSource,
              calibrationYears: scoreMeta?.calibrationYears,
            };
          },
        );
        const s = snapshot.assetSchedule;
        const composition = buildScenarioAssetComposition(s);
        const compositionSum = composition.reduce(
          (sum, item) => sum + item.amount,
          0,
        );
        const reconciliationDifference = compositionSum - s.averageTotalAssets;
        const assetProductivity: AssetProductivityResult = {
          rawTurnover: snapshot.assetTurnover,
          storedTurnover: null,
          turnoverScore: snapshot.scores["152"]?.score ?? 0,
          revenue: snapshot.revenue,
          totalAssetsBeginning: null,
          totalAssetsEnding: null,
          averageTotalAssets: s.averageTotalAssets,
          assetComposition: composition.map((item) => ({
            ...item,
            amount: item.amount,
            share: item.share,
            complete: true,
          })),
          workingCapitalDrivers: [
            {
              code: "165",
              key: "dio",
              label: "روزهای نگهداری موجودی (DIO)",
              rawValue: snapshot.dio,
              unit: "روز",
            },
            {
              code: "166",
              key: "dso",
              label: "روزهای وصول مطالبات (DSO)",
              rawValue: snapshot.dso,
              unit: "روز",
            },
            {
              code: "167",
              key: "dpo",
              label: "روزهای پرداخت بدهی (DPO)",
              rawValue: snapshot.dpo,
              unit: "روز",
            },
            {
              code: "168",
              key: "ccc",
              label: "چرخه تبدیل نقد (CCC)",
              rawValue: snapshot.ccc,
              unit: "روز",
            },
          ],
          dataCoverage: composition.every((item) =>
            Number.isFinite(item.amount),
          )
            ? 1
            : 0,
          reconciliationDifference,
          reconciliationOk:
            Math.abs(reconciliationDifference) <=
            Math.max(1, Math.abs(s.averageTotalAssets) * 1e-9),
        };
        points.push({
          id: `${company}-${year}-budget`,
          company,
          year,
          x: snapshot.map.x,
          y: snapshot.map.y,
          isForecast: true,
          pointType: "budget",
          capitalSourceYear: year,
          capitalCoverage: snapshot.map.coverage,
          components,
          assetProductivity,
          verticalMetric: snapshot.map.verticalMetric,
          verticalLabel:
            snapshot.map.verticalMetric === "utilization"
              ? "ضریب بهره‌برداری"
              : "بهره‌وری دارایی‌ها",
          verticalMethod:
            snapshot.map.verticalMetric === "utilization"
              ? /آتیه صنعت افق نقش جهان/.test(snapshot.company)
                ? "۳۰٪ بهره‌برداری بنتونیت + ۷۰٪ بهره‌برداری کوردوایر"
                : "تولید بودجه ۱۴۰۵ ÷ ظرفیت معتبر"
              : "امتیاز سناریویی گردش دارایی ۱۴۰۵ (کد ۱۵۲) ÷ ۱۰",
          productionRows: snapshot.productionRows,
          productGroups:
            snapshot.map.verticalMetric === "utilization"
              ? calculateCompanyUtilization(company, snapshot.productionRows).groups.map(
                  (group) => ({ ...group, revenue: null }),
                )
              : [],
          warnings: snapshot.warnings,
        });
        continue;
      }
      const capitalSourceYear = year;
      const components = INVESTMENT_COMPONENTS.map(
        (definition): InvestmentComponentResult => {
          const record = findFinancialRecord(
            financialModel,
            company,
            capitalSourceYear,
            definition.code,
          );
          const score =
            record?.score !== null &&
            record?.score !== undefined &&
            record.score >= 0 &&
            record.score <= 10
              ? record.score
              : null;
          return {
            code: definition.code,
            key: definition.key,
            label: definition.label,
            rawValue: record?.value ?? null,
            unit: record?.unit ?? "",
            score,
            configuredWeight: weights[definition.key],
            effectiveWeight: effectiveWeights[definition.key],
            contribution:
              score === null
                ? 0
                : (score / 10) * effectiveWeights[definition.key],
            sourceYear: capitalSourceYear,
          };
        },
      );
      if (components.some((component) => component.score === null)) continue;
      const x = components.reduce(
        (sum, component) => sum + component.contribution,
        0,
      );
      const productionRows = isProductionCompany
        ? (productionModel?.records.filter(
            (record) =>
              canonicalCompanyKey(record.company) === companyKey &&
              record.year === year &&
              (record.capacity ?? 0) > 0,
          ) ?? [])
        : [];
      let y: number | null = null;
      let verticalMetric: InvestmentPoint["verticalMetric"] =
        "asset-productivity";
      let verticalLabel = "بهره‌وری دارایی‌ها";
      let verticalMethod = "امتیاز نرمال‌شده گردش دارایی‌ها (کد ۱۵۲) ÷ ۱۰";
      let productGroups: ProductGroupResult[] = [];
      let warnings: string[] = [];
      let assetProductivity: AssetProductivityResult | null = null;
      if (isProductionCompany && productionRows.length) {
        const utilization = aggregateUtilization(
          financialModel,
          company,
          year,
          productionRows,
        );
        y = utilization.value;
        verticalMetric = "utilization";
        verticalLabel = "ضریب بهره‌برداری";
        verticalMethod = utilization.method;
        productGroups = utilization.groups;
        warnings = utilization.warnings;
      } else if (!isProductionCompany) {
        const productivity = buildAssetProductivity(
          financialModel,
          company,
          year,
        );
        assetProductivity = productivity.result;
        warnings.push(...productivity.warnings);
        y = assetProductivity ? assetProductivity.turnoverScore / 10 : null;
      }
      if (y === null || !Number.isFinite(y)) continue;
      points.push({
        id: `${company}-${year}`,
        company,
        year,
        x: Math.max(0, Math.min(1, x)),
        y,
        isForecast: false,
        pointType: "actual",
        capitalSourceYear,
        capitalCoverage: 1,
        components,
        assetProductivity,
        verticalMetric,
        verticalLabel,
        verticalMethod,
        productionRows,
        productGroups,
        warnings,
      });
    }
  }
  return points;
}

export function investmentWeightTotal(weights: InvestmentWeights) {
  return Object.values(weights).reduce((sum, value) => sum + value, 0);
}
