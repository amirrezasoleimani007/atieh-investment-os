import * as XLSX from "xlsx";
import { normalizeText, parseNumeric } from "./financial-engine";
export { canonicalCompanyKey } from "./company-resolver";
import { canonicalCompanyKey } from "./company-resolver";

export type InvestmentHolding = "atieh" | "metil";

export interface AssetRecord {
  sourceRow: number;
  group: string;
  company: string;
  assetClass: string;
  description: string;
  acquisitionDate: string;
  city: string;
  location: string;
  costRial: number | null;
  bookValueRial: number | null;
}

export interface AssetModel {
  fileName: string;
  importedAt: string;
  records: AssetRecord[];
  companies: string[];
  groups: string[];
  issues: string[];
  summary: {
    rows: number;
    validRows: number;
    companies: number;
    groups: number;
    costRial: number;
    bookValueRial: number;
  };
}

export interface MetilActivityRecord {
  sourceRow: number;
  nature: string;
  company: string;
  year: number;
  operation: string;
  product: string;
  variable: string;
  unit: string;
  value: number | null;
}

export interface MetilActivityModel {
  fileName: string;
  importedAt: string;
  records: MetilActivityRecord[];
  companies: string[];
  products: string[];
  issues: string[];
  summary: {
    rows: number;
    validRows: number;
    companies: number;
    products: number;
    year: number | null;
  };
}

export interface EquipmentRecord {
  sourceRow: number;
  rowNumber: number | null;
  company: string;
  equipment: string;
  operation: string;
  thicknessFromMm: number | null;
  thicknessToMm: number | null;
  widthFromMm: number | null;
  widthToMm: number | null;
  actualCapacityTon: number | null;
  nominalCapacityTon: number | null;
}

export interface EquipmentModel {
  fileName: string;
  importedAt: string;
  records: EquipmentRecord[];
  companies: string[];
  equipmentTypes: string[];
  issues: string[];
  summary: {
    rows: number;
    validRows: number;
    companies: number;
    equipmentTypes: number;
    actualCapacityTon: number;
    nominalCapacityTon: number;
    zeroCapacity: number;
  };
}

const clean = (value: unknown) => normalizeText(String(value ?? "").normalize("NFKC"));

function findHeader(headers: string[], aliases: string[]) {
  return headers.findIndex((header) => aliases.some((alias) => header === clean(alias)));
}

function selectSheet(data: ArrayBuffer, required: string[][]) {
  const workbook = XLSX.read(data, { type: "array", raw: true, cellDates: false, cellFormula: false });
  const candidates = workbook.SheetNames.flatMap((sheetName, sheetIndex) => {
    const sheet = workbook.Sheets[sheetName];
    const rows = XLSX.utils.sheet_to_json<unknown[]>(sheet, { header: 1, raw: true, defval: null, blankrows: false });
    return rows.slice(0, 20).map((row, headerRow) => {
      const headers = row.map(clean);
      const hits = required.filter((aliases) => findHeader(headers, aliases) >= 0).length;
      return { sheet, sheetName, sheetIndex, headerRow, headers, hits, rowCount: rows.length };
    });
  });
  const selected = candidates.sort((a, b) => b.hits - a.hits || b.rowCount - a.rowCount || a.sheetIndex - b.sheetIndex)[0];
  if (!selected || selected.hits < required.length) throw new Error("ساختار فایل با ستون‌های موردنیاز این بخش تطبیق ندارد.");
  return selected;
}

function normalizeAssetClass(value: unknown) {
  const label = clean(value)
    .replace(/ماشین[\s‌-]*آلات/g, "ماشین‌آلات")
    .replace(/تجهیزات\s*الکترونیکی/g, "تجهیزات الکترونیکی");
  if (/^ساختمان/.test(label)) return "ساختمان";
  if (/^زمین/.test(label)) return "زمین";
  if (/ماشین‌آلات/.test(label)) return "ماشین‌آلات و تجهیزات";
  return label || "طبقه نامشخص";
}

export function parseAssetWorkbook(data: ArrayBuffer, fileName: string): AssetModel {
  const required = [
    ["نام گروه", "گروه"],
    ["نام شرکت", "شرکت"],
    ["نوع طبقه دارایی", "نوع طبقه  دارایی", "طبقه دارایی"],
    ["شرح دارایی"],
    ["قیمت تمام شده"],
    ["ارزش دفتری"],
  ];
  const selected = selectSheet(data, required);
  const rows = XLSX.utils.sheet_to_json<unknown[]>(selected.sheet, {
    header: 1,
    range: selected.headerRow + 1,
    raw: true,
    defval: null,
    blankrows: false,
  });
  const idx = {
    group: findHeader(selected.headers, ["نام گروه", "گروه"]),
    company: findHeader(selected.headers, ["نام شرکت", "شرکت"]),
    assetClass: findHeader(selected.headers, ["نوع طبقه دارایی", "نوع طبقه  دارایی", "طبقه دارایی"]),
    description: findHeader(selected.headers, ["شرح دارایی"]),
    acquisitionDate: findHeader(selected.headers, ["تاریخ تحصیل"]),
    city: findHeader(selected.headers, ["شهر استان", "شهر/استان"]),
    location: findHeader(selected.headers, ["آدرس محل استقرار", "محل استقرار"]),
    cost: findHeader(selected.headers, ["قیمت تمام شده"]),
    book: findHeader(selected.headers, ["ارزش دفتری"]),
  };
  const issues: string[] = [];
  const records = rows.flatMap((row, index): AssetRecord[] => {
    const group = clean(row[idx.group]);
    const company = clean(row[idx.company]);
    const assetClass = normalizeAssetClass(row[idx.assetClass]);
    const description = clean(row[idx.description]);
    if (!group || !company || (!description && assetClass === "طبقه نامشخص")) return [];
    const costRial = parseNumeric(row[idx.cost]);
    const bookValueRial = parseNumeric(row[idx.book]);
    if (costRial === null || bookValueRial === null) issues.push(`ردیف ${selected.headerRow + index + 2}: مبلغ دارایی ناقص است.`);
    return [{
      sourceRow: selected.headerRow + index + 2,
      group,
      company,
      assetClass,
      description: description || "بدون شرح",
      acquisitionDate: idx.acquisitionDate >= 0 ? clean(row[idx.acquisitionDate]) : "",
      city: idx.city >= 0 ? clean(row[idx.city]) : "",
      location: idx.location >= 0 ? clean(row[idx.location]) : "",
      costRial,
      bookValueRial,
    }];
  });
  const companies = [...new Set(records.map((record) => record.company))].sort((a, b) => a.localeCompare(b, "fa"));
  const groups = [...new Set(records.map((record) => record.group))].sort((a, b) => a.localeCompare(b, "fa"));
  return {
    fileName,
    importedAt: new Date().toISOString(),
    records,
    companies,
    groups,
    issues,
    summary: {
      rows: rows.length,
      validRows: records.length,
      companies: companies.length,
      groups: groups.length,
      costRial: records.reduce((sum, record) => sum + (record.costRial ?? 0), 0),
      bookValueRial: records.reduce((sum, record) => sum + (record.bookValueRial ?? 0), 0),
    },
  };
}

export function parseMetilActivityWorkbook(data: ArrayBuffer, fileName: string): MetilActivityModel {
  const required = [["شرکت"], ["سال"], ["نوع عملیات"], ["متغیر"], ["واحد"], ["مقدار"]];
  const selected = selectSheet(data, required);
  const rows = XLSX.utils.sheet_to_json<unknown[]>(selected.sheet, {
    header: 1,
    range: selected.headerRow + 1,
    raw: true,
    defval: null,
    blankrows: false,
  });
  const idx = {
    nature: findHeader(selected.headers, ["ماهیت"]),
    company: findHeader(selected.headers, ["شرکت"]),
    year: findHeader(selected.headers, ["سال"]),
    operation: findHeader(selected.headers, ["نوع عملیات"]),
    product: findHeader(selected.headers, ["محصول"]),
    variable: findHeader(selected.headers, ["متغیر"]),
    unit: findHeader(selected.headers, ["واحد"]),
    value: findHeader(selected.headers, ["مقدار"]),
  };
  const records = rows.flatMap((row, index): MetilActivityRecord[] => {
    const company = clean(row[idx.company]);
    const year = parseNumeric(row[idx.year]);
    const operation = clean(row[idx.operation]);
    const variable = clean(row[idx.variable]);
    const unit = clean(row[idx.unit]);
    if (!company || year === null || !operation || !variable || !unit) return [];
    return [{
      sourceRow: selected.headerRow + index + 2,
      nature: idx.nature >= 0 ? clean(row[idx.nature]) : "",
      company,
      year: Math.trunc(year),
      operation,
      product: idx.product >= 0 ? clean(row[idx.product]) : "",
      variable,
      unit,
      value: parseNumeric(row[idx.value]),
    }];
  });
  const companies = [...new Set(records.map((record) => record.company))].sort((a, b) => a.localeCompare(b, "fa"));
  const products = [...new Set(records.map((record) => record.product).filter(Boolean))].sort((a, b) => a.localeCompare(b, "fa"));
  const years = [...new Set(records.map((record) => record.year))].sort((a, b) => a - b);
  const issues: string[] = [];
  if (years.length !== 1 || years[0] !== 1404) issues.push("فایل فعالیت متیل صرفاً برای تحلیل سال ۱۴۰۴ طراحی شده است.");
  return {
    fileName,
    importedAt: new Date().toISOString(),
    records,
    companies,
    products,
    issues,
    summary: {
      rows: rows.length,
      validRows: records.length,
      companies: companies.length,
      products: products.length,
      year: years.length === 1 ? years[0] : null,
    },
  };
}

export function parseEquipmentWorkbook(data: ArrayBuffer, fileName: string): EquipmentModel {
  const required = [
    ["نام شرکت", "شرکت"],
    ["نام تجهیز", "تجهیز", "تجهیزات"],
    ["ظرفیت واقعی سالانه تک شیفت تن", "ظرفیت واقعی سالانه تک‌شیفت تن", "ظرفیت واقعی سالانه تک‌شیفت (تن)", "ظرفیت واقعی"],
    ["ظرفیت اسمی سالانه تک شیفت تن", "ظرفیت اسمی سالانه تک‌شیفت تن", "ظرفیت اسمی سالانه تک‌شیفت (تن)", "ظرفیت اسمی"],
  ];
  const selected = selectSheet(data, required);
  const rows = XLSX.utils.sheet_to_json<unknown[]>(selected.sheet, { header: 1, range: selected.headerRow + 1, raw: true, defval: null, blankrows: false });
  const idx = {
    rowNumber: findHeader(selected.headers, ["ردیف", "شماره"]),
    company: findHeader(selected.headers, ["نام شرکت", "شرکت"]),
    equipment: findHeader(selected.headers, ["نام تجهیز", "تجهیز", "تجهیزات"]),
    operation: findHeader(selected.headers, ["نوع عملیات محدوده عملکرد", "نوع عملیات / محدوده عملکرد", "محدوده عملکرد", "نوع عملیات"]),
    thicknessFrom: findHeader(selected.headers, ["ضخامت از mm", "ضخامت از (mm)", "حداقل ضخامت"]),
    thicknessTo: findHeader(selected.headers, ["ضخامت تا mm", "ضخامت تا (mm)", "حداکثر ضخامت"]),
    widthFrom: findHeader(selected.headers, ["عرض از mm", "عرض از (mm)", "حداقل عرض"]),
    widthTo: findHeader(selected.headers, ["عرض تا mm", "عرض تا (mm)", "حداکثر عرض"]),
    actualCapacity: findHeader(selected.headers, ["ظرفیت واقعی سالانه تک شیفت تن", "ظرفیت واقعی سالانه تک‌شیفت تن", "ظرفیت واقعی سالانه تک‌شیفت (تن)", "ظرفیت واقعی"]),
    nominalCapacity: findHeader(selected.headers, ["ظرفیت اسمی سالانه تک شیفت تن", "ظرفیت اسمی سالانه تک‌شیفت تن", "ظرفیت اسمی سالانه تک‌شیفت (تن)", "ظرفیت اسمی"]),
  };
  const issues: string[] = [];
  const records = rows.flatMap((row, index): EquipmentRecord[] => {
    const company = clean(row[idx.company]);
    const equipment = clean(row[idx.equipment]);
    if (!company || !equipment) return [];
    const thicknessFromMm = idx.thicknessFrom >= 0 ? parseNumeric(row[idx.thicknessFrom]) : null;
    const thicknessToMm = idx.thicknessTo >= 0 ? parseNumeric(row[idx.thicknessTo]) : null;
    const widthFromMm = idx.widthFrom >= 0 ? parseNumeric(row[idx.widthFrom]) : null;
    const widthToMm = idx.widthTo >= 0 ? parseNumeric(row[idx.widthTo]) : null;
    const actualCapacityTon = parseNumeric(row[idx.actualCapacity]);
    const nominalCapacityTon = parseNumeric(row[idx.nominalCapacity]);
    const sourceRow = selected.headerRow + index + 2;
    if (actualCapacityTon === null || nominalCapacityTon === null) issues.push(`ردیف ${sourceRow}: ظرفیت واقعی یا اسمی ناقص است.`);
    if (nominalCapacityTon === 0) issues.push(`ردیف ${sourceRow}: ظرفیت اسمی صفر ثبت شده است.`);
    if (actualCapacityTon !== null && nominalCapacityTon !== null && actualCapacityTon > nominalCapacityTon) issues.push(`ردیف ${sourceRow}: ظرفیت واقعی از ظرفیت اسمی بیشتر است.`);
    if (thicknessFromMm !== null && thicknessToMm !== null && thicknessFromMm > thicknessToMm) issues.push(`ردیف ${sourceRow}: بازه ضخامت معکوس ثبت شده است.`);
    if (widthFromMm !== null && widthToMm !== null && widthFromMm > widthToMm) issues.push(`ردیف ${sourceRow}: بازه عرض معکوس ثبت شده است.`);
    const rawOperation = idx.operation >= 0 ? clean(row[idx.operation]) : "";
    return [{ sourceRow, rowNumber: idx.rowNumber >= 0 ? parseNumeric(row[idx.rowNumber]) : null, company, equipment, operation: rawOperation && rawOperation !== "**" ? rawOperation : "نامشخص", thicknessFromMm, thicknessToMm, widthFromMm, widthToMm, actualCapacityTon, nominalCapacityTon }];
  });
  const companies = [...new Set(records.map((record) => record.company))].sort((a, b) => a.localeCompare(b, "fa"));
  const equipmentTypes = [...new Set(records.map((record) => record.equipment))].sort((a, b) => a.localeCompare(b, "fa"));
  return {
    fileName,
    importedAt: new Date().toISOString(),
    records,
    companies,
    equipmentTypes,
    issues,
    summary: {
      rows: rows.length,
      validRows: records.length,
      companies: companies.length,
      equipmentTypes: equipmentTypes.length,
      actualCapacityTon: records.reduce((sum, record) => sum + (record.actualCapacityTon ?? 0), 0),
      nominalCapacityTon: records.reduce((sum, record) => sum + (record.nominalCapacityTon ?? 0), 0),
      zeroCapacity: records.filter((record) => (record.nominalCapacityTon ?? 0) === 0).length,
    },
  };
}

export function assetsForCompany(model: AssetModel | null, company: string, holding: InvestmentHolding) {
  if (!model) return [];
  const group = holding === "atieh" ? "آتیه" : "متیل";
  const companyKey = canonicalCompanyKey(company);
  if (holding === "atieh" && companyKey === canonicalCompanyKey("فولاد متیل")) {
    return model.records.filter((record) => clean(record.group) === "متیل");
  }
  return model.records.filter((record) => clean(record.group) === group && canonicalCompanyKey(record.company) === companyKey);
}

export function activityForCompany(model: MetilActivityModel | null, company: string) {
  if (!model) return [];
  const companyKey = canonicalCompanyKey(company);
  return model.records.filter((record) => canonicalCompanyKey(record.company) === companyKey && record.year === 1404);
}

export function equipmentForCompany(model: EquipmentModel | null, company: string) {
  if (!model) return [];
  const companyKey = canonicalCompanyKey(company);
  return model.records.filter((record) => canonicalCompanyKey(record.company) === companyKey);
}
