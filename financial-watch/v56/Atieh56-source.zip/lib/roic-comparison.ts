import type {FinancialModel} from './financial-engine';
import type {ProfitModel} from './profit-engine';
import type {ProductionModel} from './investment-engine';
import {financialRecordByCanonicalCode,type HoldingKey} from './company-resolver';
import {buildPlanningScenarioSnapshot} from './planning-scenario-engine';
export interface RoicRow {company:string;year:number;period:'actual'|'budget';investedCapital:number;beginningInvestedCapital:number|null;endingInvestedCapital:number|null;nopat:number;roic:number}
export function independentRoic(financial:FinancialModel,company:string,year:number):RoicRow|null{
 const v=(y:number,code:string)=>financialRecordByCanonicalCode(financial,company,y,code)?.value??null;
 const ic=(y:number)=>{const a=v(y,'134'),c=v(y,'130'),i=v(y,'132');return a===null||c===null||i===null?null:a-c-i;};
 const opening=financial.annualOpeningModel ?? financial;
 const openingValue=(code:string)=>financialRecordByCanonicalCode(opening,company,year-1,code)?.value??null;
 const a=openingValue('134'),c=openingValue('130'),i=openingValue('132');
 const beginning=a===null||c===null||i===null?null:a-c-i,ending=ic(year),nopat=v(year,'148');if(beginning===null||ending===null||nopat===null)return null;
 const average=(beginning+ending)/2;if(!(average>0)||![average,nopat].every(Number.isFinite))return null;
 return {company,year,period:'actual',investedCapital:average,beginningInvestedCapital:beginning,endingInvestedCapital:ending,nopat,roic:nopat/average};
}
export function buildRoicComparison(financial:FinancialModel,profit:ProfitModel|null,production:ProductionModel|null,holding:HoldingKey){
 const periods:Record<string,{companies:RoicRow[];year:number;period:'actual'|'budget'}>={};
 for(const year of financial.years){const companies=financial.companies.flatMap(company=>{const r=independentRoic(financial,company,year);return r?[r]:[];});if(companies.length)periods[`actual:${year}`]={companies,year,period:'actual'};}
 const budgetYears=[...new Set(profit?.records.filter(r=>r.isBudget&&(!r.holding||r.holding===holding)).map(r=>r.year)??[])];
 for(const year of budgetYears){const companies=financial.companies.flatMap(company=>{const s=buildPlanningScenarioSnapshot(financial,profit,production,holding,company,{budgetYear:year});return s?[{company,year,period:'budget' as const,investedCapital:s.assetSchedule.averageInvestedCapital,beginningInvestedCapital:null,endingInvestedCapital:null,nopat:s.nopat,roic:s.roic}]:[];});if(companies.length)periods[`budget:${year}`]={companies,year,period:'budget'};}
 return {periods};
}
