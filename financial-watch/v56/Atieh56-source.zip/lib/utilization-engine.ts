import { normalizeText } from "./financial-engine";
export interface UtilizationRow { sourceRow?: number; company: string; equipment: string; year: number; capacity: number | null; production: number | null }
export interface UtilizationGroup { label: string; capacity: number; production: number; utilization: number | null; weight: number }
function deduplicate(rows: UtilizationRow[]) {
  const map = new Map<string, UtilizationRow>(), duplicates: string[] = [];
  for (const row of rows) { const key = row.sourceRow === undefined ? `${normalizeText(row.company)}|${normalizeText(row.equipment)}|${row.year}` : `${normalizeText(row.company)}|${row.year}|row-${row.sourceRow}`; if (map.has(key)) duplicates.push(row.equipment || "خط بدون نام"); else map.set(key, row); }
  return { rows: [...map.values()], duplicates: [...new Set(duplicates)] };
}
function total(rows: UtilizationRow[]) { const usable = rows.filter((r) => (r.capacity ?? 0) > 0 && r.production !== null); const capacity = usable.reduce((s, r) => s + r.capacity!, 0), production = usable.reduce((s, r) => s + r.production!, 0); return { capacity, production, utilization: capacity > 0 ? production / capacity : null }; }
export function calculateCompanyUtilization(company: string, rows: UtilizationRow[]) {
  const unique = deduplicate(rows), warnings = unique.duplicates.length ? [`ردیف تکراری تجهیز در محاسبه دوباره‌شماری نشد: ${unique.duplicates.join("، ")}`] : [];
  if (/آتیه صنعت افق نقش جهان/.test(normalizeText(company))) {
    const definitions = [{ label: "بنتونیت", pattern: /بنتونیت/, weight: .3 }, { label: "کوردوایر", pattern: /کورد|وایر/, weight: .7 }];
    const groups: UtilizationGroup[] = definitions.map((d) => ({ label: d.label, ...total(unique.rows.filter((r) => d.pattern.test(normalizeText(r.equipment)))), weight: d.weight }));
    const complete = groups.every((g) => g.utilization !== null); if (!complete) warnings.push("اطلاعات معتبر هر دو گروه بنتونیت و کوردوایر برای بهره‌برداری ترکیبی لازم است.");
    return { value: complete ? groups.reduce((s, g) => s + g.utilization! * g.weight, 0) : null, groups, warnings, method: "۳۰٪ بهره‌برداری بنتونیت + ۷۰٪ بهره‌برداری کوردوایر", uniqueRows: unique.rows };
  }
  const aggregate = total(unique.rows); return { value: aggregate.utilization, groups: [{ label: unique.rows.length > 1 ? "مجموع خطوط" : "خط تولید", ...aggregate, weight: 1 }], warnings, method: unique.rows.length > 1 ? "جمع تولید ÷ جمع ظرفیت" : "تولید ÷ ظرفیت", uniqueRows: unique.rows };
}
