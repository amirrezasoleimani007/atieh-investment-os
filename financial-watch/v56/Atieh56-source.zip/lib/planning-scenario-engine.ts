import { normalizeText, type FinancialModel } from "./financial-engine";
import type { ProfitModel, ProfitRecord } from "./profit-engine";
import type { ProductionModel, ProductionRecord } from "./investment-engine";
import {
  canonicalCompanyKey,
  financialRecordByCanonicalCode,
  type HoldingKey,
} from "./company-resolver";
import {
  calibrateScenarioScore,
  carryForwardScenarioScore,
  SCORING_VERSION,
  type ScenarioScoreResult,
} from "./scenario-score-engine";
import { calculateCompanyUtilization } from "./utilization-engine";

export type ReleaseTreatment = "cash-retained" | "cash-exits";
export type ScenarioKind = "budget" | "optimized";
export interface PlanningAssumptions {
  budgetYear?: number;
  dso?: number;
  dio?: number;
  dpo?: number;
  taxRate?: number;
  cash?: number;
  operatingMarginDelta?: number;
  dsoReduction?: number;
  dioReduction?: number;
  releaseTreatment?: ReleaseTreatment;
}
export interface FieldSource {
  source: "Financial" | "Profit" | "Product" | "calculated" | "assumption";
  year: number;
  code?: string;
  note: string;
}
export interface AssetSchedule {
  receivables: number;
  inventory: number;
  cash: number;
  shortTermInvestments: number;
  longTermInvestments: number;
  fixedAssets: number;
  intangibleAssets: number;
  otherCurrentAssets: number;
  otherNonCurrentAssets: number;
  averageTotalAssets: number;
  averageInvestedCapital: number;
}
export interface PlanningScenarioSnapshot {
  company: string;
  holding: HoldingKey;
  year: number;
  kind: ScenarioKind;
  unit: string;
  revenue: number;
  cogs: number;
  grossProfit: number;
  reportedGrossProfit: number | null;
  operatingProfit: number;
  netProfit: number | null;
  dso: number;
  dio: number;
  dpo: number;
  ccc: number;
  taxRate: number;
  nopat: number;
  roic: number;
  wacc: number;
  spread: number;
  revenueGrowth: number|null;
  assetTurnover: number;
  fcfMargin: number | null;
  assetSchedule: AssetSchedule;
  utilization: number | null;
  productionRows: ProductionRecord[];
  scores: Record<string, ScenarioScoreResult | null>;
  map: {
    x: number | null;
    y: number | null;
    coverage: number;
    verticalMetric: "utilization" | "asset-productivity";
  };
  sources: Record<string, FieldSource>;
  warnings: string[];
  quality: "complete" | "partial";
  dataQuality: "high" | "medium" | "limited";
  releaseTreatment: ReleaseTreatment;
  scoringVersion: string;
}

export interface ScenarioAssetCompositionItem {
  key: "receivables" | "inventory" | "cash" | "investments" | "fixed" | "other";
  label: string;
  amount: number;
  share: number;
  color: string;
  codes: string[];
}

const value = (
  model: FinancialModel,
  company: string,
  year: number,
  code: string,
) => financialRecordByCanonicalCode(model, company, year, code)?.value ?? null;
const record = (
  model: FinancialModel,
  company: string,
  year: number,
  code: string,
) => financialRecordByCanonicalCode(model, company, year, code);
const finite = (v: number | null): v is number =>
  v !== null && Number.isFinite(v);
const boundedRate = (v: number) => Math.max(0, Math.min(0.6, v));

function latestActualValue(
  model: FinancialModel,
  company: string,
  code: string,
  throughYear = 1404,
) {
  const years = [...model.years]
    .filter((year) => year <= throughYear)
    .sort((a, b) => b - a);
  for (const year of years) {
    const found = value(model, company, year, code);
    if (finite(found)) return { value: found, year };
  }
  return null;
}

export function buildScenarioAssetComposition(
  schedule: AssetSchedule,
): ScenarioAssetCompositionItem[] {
  const rows = [
    {
      key: "receivables" as const,
      label: "مطالبات",
      amount: schedule.receivables,
      color: "#0f8a78",
      codes: ["129"],
    },
    {
      key: "inventory" as const,
      label: "موجودی",
      amount: schedule.inventory,
      color: "#2563eb",
      codes: ["128"],
    },
    {
      key: "cash" as const,
      label: "نقد",
      amount: schedule.cash,
      color: "#d69a1e",
      codes: ["130"],
    },
    {
      key: "investments" as const,
      label: "سرمایه‌گذاری‌ها",
      amount: schedule.shortTermInvestments + schedule.longTermInvestments,
      color: "#8b5cf6",
      codes: ["132", "127"],
    },
    {
      key: "fixed" as const,
      label: "دارایی ثابت و نامشهود",
      amount: schedule.fixedAssets + schedule.intangibleAssets,
      color: "#dd6b4d",
      codes: ["125", "126"],
    },
    {
      key: "other" as const,
      label: "سایر دارایی‌ها",
      amount: schedule.otherCurrentAssets + schedule.otherNonCurrentAssets,
      color: "#78909c",
      codes: ["133", "131"],
    },
  ];
  const total = rows.reduce((sum, row) => sum + row.amount, 0);
  return rows.map((row) => ({
    ...row,
    share: total > 0 ? row.amount / total : 0,
  }));
}

function budgetTotal(
  profit: ProfitModel,
  company: string,
  holding: HoldingKey,
  year?:number,
): ProfitRecord | null {
  const key = canonicalCompanyKey(company);
  const rows = profit.records.filter(
    (row) =>
      row.companyKey === key &&
      row.isBudget &&
      row.isTotal &&
      (year===undefined||row.year===year) &&
      (!row.holding || row.holding === holding),
  );
  rows.sort((a,b)=>b.year-a.year);
  if(rows.length>1&&rows[0].year===rows[1].year)return null;
  return rows[0] ?? null;
}

export function buildPlanningScenarioSnapshot(
  financial: FinancialModel,
  profit: ProfitModel | null,
  production: ProductionModel | null,
  holding: HoldingKey,
  company: string,
  assumptions: PlanningAssumptions = {},
): PlanningScenarioSnapshot | null {
  if (!profit) return null;
  const total = budgetTotal(profit, company, holding,assumptions.budgetYear);
  if (!total) return null;
  const budgetYear=total.year,baseYear=budgetYear-1;
  const warnings: string[] = [];
  const financialUnit = record(financial, company, baseYear, "111")?.unit ?? "";
  if (!financialUnit || !total.unit || normalizeText(financialUnit) !== normalizeText(total.unit)) return null;
  const baseRevenue = value(financial, company, baseYear, "111");
  const dsoBase = value(financial, company, baseYear, "166"),
    dioBase = value(financial, company, baseYear, "165"),
    dpoBase = value(financial, company, baseYear, "167");
  const cashBase = value(financial, company, baseYear, "130"),
    shortInv = value(financial, company, baseYear, "132"),
    longInv = value(financial, company, baseYear, "127");
  const fixed = value(financial, company, baseYear, "125"),
    intangible = value(financial, company, baseYear, "126"),
    current = value(financial, company, baseYear, "133"),
    noncurrent = value(financial, company, baseYear, "131");
  const arBase = value(financial, company, baseYear, "129"),
    inventoryBase = value(financial, company, baseYear, "128");
  const waccSource = latestActualValue(financial, company, "179",baseYear),
    taxSource = latestActualValue(financial, company, "182",baseYear),
    fcfSource = latestActualValue(financial, company, "175",baseYear);
  const wacc = waccSource?.value ?? null,
    taxBase = taxSource?.value ?? null,
    fcfMargin = fcfSource?.value ?? null;
  if (
    ![
      baseRevenue,
      dsoBase,
      dioBase,
      dpoBase,
      cashBase,
      shortInv,
      longInv,
      fixed,
      intangible,
      current,
      noncurrent,
      arBase,
      inventoryBase,
      wacc,
      taxBase,
    ].every(finite)
  )
    return null;
  if (
    !finite(total.budgetOperatingProfit) ||
    !finite(total.revenue) ||
    !finite(total.normalizedCogs)
  )
    return null;
  const revenue = total.revenue,
    cogs = -Math.abs(total.normalizedCogs),
    grossProfit = revenue + cogs;
  const operatingProfit =
    total.budgetOperatingProfit +
    revenue * (assumptions.operatingMarginDelta ?? 0);
  const dso = Math.max(
    0,
    assumptions.dso ?? dsoBase! - Math.max(0, assumptions.dsoReduction ?? 0),
  );
  const dio = Math.max(
    0,
    assumptions.dio ?? dioBase! - Math.max(0, assumptions.dioReduction ?? 0),
  );
  const dpo = Math.max(0, assumptions.dpo ?? dpoBase!);
  const taxRate = boundedRate(assumptions.taxRate ?? taxBase!);
  const releaseTreatment = assumptions.releaseTreatment ?? "cash-retained";
  const ratio = baseRevenue! > 0 ? revenue / baseRevenue! : 1;
  const otherCurrentBase =
    current! - cashBase! - shortInv! - arBase! - inventoryBase!;
  const otherNonCurrentAssets = noncurrent! - fixed! - intangible! - longInv!;
  const receivables = (revenue * dso) / 365,
    inventory = (Math.abs(cogs) * dio) / 365;
  const baselineReceivables = (revenue * dsoBase!) / 365,
    baselineInventory = (Math.abs(cogs) * dioBase!) / 365;
  const releasedCash =
    Math.max(0, baselineReceivables - receivables) +
    Math.max(0, baselineInventory - inventory);
  let cash = assumptions.cash ?? cashBase!;
  if (releaseTreatment === "cash-retained") cash += releasedCash;
  const otherCurrentAssets = otherCurrentBase * ratio;
  const averageTotalAssets =
    receivables +
    inventory +
    cash +
    shortInv! +
    longInv! +
    fixed! +
    intangible! +
    otherCurrentAssets +
    otherNonCurrentAssets;
  const averageInvestedCapital = averageTotalAssets - cash - shortInv!;
  if(!Number.isFinite(averageInvestedCapital)||averageInvestedCapital<=0||!Number.isFinite(averageTotalAssets)||averageTotalAssets<=0)return null;
  if (
    Math.abs(total.grossProfitDifference) >
    Math.max(1, Math.abs(revenue) * 0.001)
  )
    warnings.push(
      "سود ناخالص ثبت‌شده Profit با درآمد منهای قدرمطلق بهای تمام‌شده مغایرت دارد؛ مقدار محاسبه‌شده استفاده شد.",
    );
  const nopat = operatingProfit * (1 - taxRate),
    roic = nopat / averageInvestedCapital,
    spread = roic - wacc!;
  const assetTurnover = revenue / averageTotalAssets,
    revenueGrowth = baseRevenue! === 0 ? null : revenue / baseRevenue! - 1,
    ccc = dso + dio - dpo;
  const raw: Record<string, number | null> = {
    "144": revenueGrowth,
    "150": roic,
    "152": assetTurnover,
    "175": fcfMargin,
    "176": spread,
  };
  const scores: Record<string, ScenarioScoreResult | null> = {};
  for (const code of ["144", "150", "152", "176"])
    scores[code] =
      raw[code] === null
        ? null
        : calibrateScenarioScore(financial, company, holding, code, raw[code]!,baseYear);
  scores["175"] = fcfMargin === null ? null : carryForwardScenarioScore(financial, company, holding, "175", fcfMargin,baseYear);
  const scoreValues = ["176", "150", "175", "144"].map(
    (code) => scores[code]?.score ?? null,
  );
  const coverage = scoreValues.filter(finite).length / 4;
  const x =
    coverage === 1
      ? (scoreValues[0]! * 0.4 +
          scoreValues[1]! * 0.25 +
          scoreValues[2]! * 0.2 +
          scoreValues[3]! * 0.15) /
        10
      : null;
  const productionRows =
    holding === "atieh"
      ? (production?.records.filter(
          (row) =>
            canonicalCompanyKey(row.company) === canonicalCompanyKey(company) &&
            row.year === budgetYear &&
            (row.capacity ?? 0) > 0,
        ) ?? [])
      : [];
  const utilizationResult = calculateCompanyUtilization(company, productionRows);
  const utilization = utilizationResult.value;
  warnings.push(...utilizationResult.warnings);
  const yScore = scores["152"]?.score ?? null;
  const y = utilization ?? (yScore === null ? null : yScore / 10);
  if (coverage < 1)
    warnings.push(
      "کالیبراسیون تاریخی برای یک یا چند امتیاز سناریویی کافی نیست؛ نقطه نقشه ناقص است.",
    );
  const sources: Record<string, FieldSource> = {
    revenue: { source: "Profit", year: budgetYear, note: "ردیف جمع بودجه سال منتخب" },
    cogs: {
      source: "Profit",
      year: budgetYear,
      note: "ردیف جمع؛ قدرمطلق هزینه با علامت منفی",
    },
    operatingProfit: {
      source: assumptions.operatingMarginDelta ? "assumption" : "Profit",
      year: budgetYear,
      note: "سود عملیاتی بودجه و اثر سناریو",
    },
    dso: {
      source:
        assumptions.dso !== undefined || assumptions.dsoReduction
          ? "assumption"
          : "Financial",
      year: baseYear,
      code: "166",
      note: "حمل از عملکرد واقعی",
    },
    dio: {
      source:
        assumptions.dio !== undefined || assumptions.dioReduction
          ? "assumption"
          : "Financial",
      year: baseYear,
      code: "165",
      note: "حمل از عملکرد واقعی",
    },
    dpo: {
      source: assumptions.dpo !== undefined ? "assumption" : "Financial",
      year: baseYear,
      code: "167",
      note: "حمل از عملکرد واقعی",
    },
    cash: {
      source: assumptions.cash !== undefined ? "assumption" : "Financial",
      year: baseYear,
      code: "130",
      note: "حمل مانده نقد؛ آزادسازی طبق روش انتخابی",
    },
    wacc: {
      source: "Financial",
      year: waccSource!.year,
      code: "179",
      note: "آخرین مقدار معتبر عملکرد واقعی",
    },
    fcfMargin: {
      source: "Financial",
      year: fcfSource?.year ?? baseYear,
      code: "175",
      note: "آخرین مقدار معتبر؛ امتیاز ذخیره‌شده بدون بازبرآورد",
    },
    assets: {
      source: "calculated",
      year: budgetYear,
      note: "برنامه برآوردی اجزای دارایی؛ بدون residual مصنوعی",
    },
    utilization: {
      source: "Product",
      year: budgetYear,
      note: "فقط ظرفیت و تولید خطوط معتبر",
    },
  };
  const isOptimized = Object.keys(assumptions).some(
    (key) => key!=='budgetYear'&&assumptions[key as keyof PlanningAssumptions] !== undefined,
  );
  const dataQuality =
    coverage === 1 && y !== null && warnings.length === 0
      ? "high"
      : coverage >= 0.75
        ? "medium"
        : "limited";
  return {
    company,
    holding,
    year: budgetYear,
    kind: isOptimized ? "optimized" : "budget",
    unit: total.unit,
    revenue,
    cogs,
    grossProfit,
    reportedGrossProfit: total.reportedGrossProfit,
    operatingProfit,
    netProfit: total.budgetNetProfit,
    dso,
    dio,
    dpo,
    ccc,
    taxRate,
    nopat,
    roic,
    wacc: wacc!,
    spread,
    revenueGrowth,
    assetTurnover,
    fcfMargin,
    assetSchedule: {
      receivables,
      inventory,
      cash,
      shortTermInvestments: shortInv!,
      longTermInvestments: longInv!,
      fixedAssets: fixed!,
      intangibleAssets: intangible!,
      otherCurrentAssets,
      otherNonCurrentAssets,
      averageTotalAssets,
      averageInvestedCapital,
    },
    utilization,
    productionRows,
    scores,
    map: {
      x,
      y,
      coverage,
      verticalMetric:
        utilization === null ? "asset-productivity" : "utilization",
    },
    sources,
    warnings,
    quality: coverage === 1 && y !== null ? "complete" : "partial",
    dataQuality,
    releaseTreatment,
    scoringVersion: `FY${baseYear}-FROZEN-COMPANY-v1`,
  };
}
