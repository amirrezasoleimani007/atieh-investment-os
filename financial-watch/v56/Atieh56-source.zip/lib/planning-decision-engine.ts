import type {
  PlanningScenarioSnapshot,
  ScenarioAssetCompositionItem,
} from "./planning-scenario-engine";
import type { ProfitRecord } from "./profit-engine";
import type { ValueSnapshot } from "./value-creation-engine";

export interface GrowthEconomics {
  revenueGrowth: number | null;
  operatingProfitGrowth: number | null;
  nopatGrowth: number | null;
  assetGrowth: number | null;
  investedCapitalGrowth: number | null;
  capitalPerAddedRevenue: number | null;
  deltaRevenue: number;
  deltaNopat: number;
  deltaAssets: number | null;
  deltaInvestedCapital: number;
  incrementalReturn: number | null;
  incrementalSpread: number | null;
  comparableActualNopat: number | null;
  comparableScenarioNopat: number;
  capitalState: "added" | "released" | "unchanged";
}
export interface ScenarioAction {
  key: string;
  label: string;
  snapshot: PlanningScenarioSnapshot;
  spreadGain: number;
  investedCapitalReduction: number;
  turnoverGain: number;
  appliedFrom: number | null;
  appliedTo: number | null;
}
export interface CapitalAllocationLimit {
  budgetInvestedCapital: number;
  economicCapitalLimit: number | null;
  capitalGap: number | null;
  requiredNopatIncrease: number | null;
  state: "excess" | "capacity" | "unavailable";
}

export interface ProductRoicDriver {
  key: string;
  label: string;
  revenue: number;
  grossMargin: number | null;
  marginDeltaPp: number;
  addedGrossProfit: number;
  addedNopat: number;
  roicGain: number;
  resultingRoic: number;
  resultingSpread: number;
  sensitivityShare: number;
}

const growth = (next: number, base: number) =>
  base === 0 ? null : (next - base) / Math.abs(base);
const fa = (value: number, digits = 1) =>
  new Intl.NumberFormat("fa-IR", {
    minimumFractionDigits: digits,
    maximumFractionDigits: digits,
  }).format(value);

export function calculateGrowthEconomics(
  actual: ValueSnapshot,
  scenario: PlanningScenarioSnapshot,
): GrowthEconomics {
  const comparableActualNopat = actual.operatingProfit === null ? null : actual.operatingProfit * (1 - actual.taxRate);
  const comparableScenarioNopat = scenario.operatingProfit * (1 - scenario.taxRate);
  const deltaRevenue = scenario.revenue - actual.revenue,
    deltaNopat = comparableActualNopat === null ? 0 : comparableScenarioNopat - comparableActualNopat;
  const deltaAssets =
    actual.averageTotalAssets === null
      ? null
      : scenario.assetSchedule.averageTotalAssets - actual.averageTotalAssets;
  const deltaInvestedCapital =
    scenario.assetSchedule.averageInvestedCapital - actual.averageIc;
  const capitalState =
    deltaInvestedCapital > 1e-9
      ? "added"
      : deltaInvestedCapital < -1e-9
        ? "released"
        : "unchanged";
  const incrementalReturn =
    comparableActualNopat !== null && deltaInvestedCapital > 1e-9 ? deltaNopat / deltaInvestedCapital : null;
  return {
    revenueGrowth: growth(scenario.revenue, actual.revenue),
    operatingProfitGrowth: actual.operatingProfit === null ? null : growth(scenario.operatingProfit, actual.operatingProfit),
    nopatGrowth: comparableActualNopat === null ? null : growth(comparableScenarioNopat, comparableActualNopat),
    assetGrowth:
      actual.averageTotalAssets === null
        ? null
        : growth(
            scenario.assetSchedule.averageTotalAssets,
            actual.averageTotalAssets,
          ),
    investedCapitalGrowth: growth(
      scenario.assetSchedule.averageInvestedCapital,
      actual.averageIc,
    ),
    capitalPerAddedRevenue:
      deltaRevenue > 0 ? deltaInvestedCapital / deltaRevenue : null,
    deltaRevenue,
    deltaNopat,
    deltaAssets,
    deltaInvestedCapital,
    incrementalReturn,
    incrementalSpread:
      incrementalReturn === null ? null : incrementalReturn - scenario.wacc,
    comparableActualNopat,
    comparableScenarioNopat,
    capitalState,
  };
}

export function calculateCapitalAllocationLimit(scenario: PlanningScenarioSnapshot): CapitalAllocationLimit {
  const budgetInvestedCapital = scenario.assetSchedule.averageInvestedCapital;
  if (!(scenario.wacc > 0) || !Number.isFinite(scenario.nopat))
    return { budgetInvestedCapital, economicCapitalLimit: null, capitalGap: null, requiredNopatIncrease: null, state: "unavailable" };
  const economicCapitalLimit = scenario.nopat / scenario.wacc;
  const capitalGap = budgetInvestedCapital - economicCapitalLimit;
  return {
    budgetInvestedCapital, economicCapitalLimit, capitalGap,
    requiredNopatIncrease: Math.max(0, budgetInvestedCapital * scenario.wacc - scenario.nopat),
    state: capitalGap > 1e-6 ? "excess" : "capacity",
  };
}

export function buildCapitalBridge(
  actual: ValueSnapshot,
  scenario: PlanningScenarioSnapshot,
) {
  const s = scenario.assetSchedule;
  const actualAr = actual.averageReceivables ?? actual.receivables,
    actualInventory = actual.averageInventory ?? actual.inventory;
  const actualOther = actual.averageIc - actualAr - actualInventory;
  const scenarioOther =
    s.otherCurrentAssets +
    s.fixedAssets +
    s.intangibleAssets +
    s.longTermInvestments +
    s.otherNonCurrentAssets;
  const rows = [
    { key: "receivables", label: "مطالبات", value: s.receivables - actualAr },
    { key: "inventory", label: "موجودی", value: s.inventory - actualInventory },
    {
      key: "other",
      label: "سایر سرمایه درگیر",
      value: scenarioOther - actualOther,
    },
  ];
  const total = rows.reduce((sum, row) => sum + row.value, 0);
  return {
    rows,
    total,
    reconciliationDifference:
      total - (s.averageInvestedCapital - actual.averageIc),
  };
}

export function reconcileScenarioInvestedCapital(base: PlanningScenarioSnapshot, scenario: PlanningScenarioSnapshot) {
  const b = base.assetSchedule, s = scenario.assetSchedule;
  const rows = [
    { key: "receivables", value: s.receivables - b.receivables },
    { key: "inventory", value: s.inventory - b.inventory },
    { key: "other-current", value: s.otherCurrentAssets - b.otherCurrentAssets },
    { key: "long-investments", value: s.longTermInvestments - b.longTermInvestments },
    { key: "fixed", value: s.fixedAssets + s.intangibleAssets - b.fixedAssets - b.intangibleAssets },
    { key: "other-noncurrent", value: s.otherNonCurrentAssets - b.otherNonCurrentAssets },
  ];
  const explainedChange = rows.reduce((sum, row) => sum + row.value, 0);
  const actualChange = s.averageInvestedCapital - b.averageInvestedCapital;
  const difference = explainedChange - actualChange;
  return { rows, explainedChange, actualChange, difference, ok: Math.abs(difference) <= Math.max(1, Math.abs(actualChange) * 1e-9) };
}

export function rankScenarioActions(
  base: PlanningScenarioSnapshot,
  candidates: Array<{
    key: string;
    label: string;
    snapshot: PlanningScenarioSnapshot | null;
  }>,
): ScenarioAction[] {
  return candidates
    .flatMap(({ key, label, snapshot }) =>
      snapshot
        ? [
            {
              key,
              label,
              snapshot,
              spreadGain: snapshot.spread - base.spread,
              investedCapitalReduction:
                base.assetSchedule.averageInvestedCapital -
                snapshot.assetSchedule.averageInvestedCapital,
              turnoverGain: snapshot.assetTurnover - base.assetTurnover,
              appliedFrom: key === "dso" ? base.dso : key === "dio" ? base.dio : null,
              appliedTo: key === "dso" ? snapshot.dso : key === "dio" ? snapshot.dio : null,
            },
          ]
        : [],
    )
    .sort(
      (a, b) =>
        b.spreadGain - a.spreadGain ||
        b.investedCapitalReduction - a.investedCapitalReduction ||
        b.turnoverGain - a.turnoverGain,
    );
}

/**
 * Compares detailed budget lines using one identical managerial shock:
 * a one percentage-point improvement in each line's gross margin. The model
 * assumes the gross-profit improvement reaches EBIT while operating expenses,
 * tax rate and invested capital remain unchanged.
 */
export function buildProductRoicDrivers(
  base: PlanningScenarioSnapshot,
  records: ProfitRecord[],
  marginDeltaPp = 1,
): ProductRoicDriver[] {
  if (!(base.assetSchedule.averageInvestedCapital > 0) || !(marginDeltaPp > 0))
    return [];
  const grouped = new Map<string, { label: string; revenue: number; grossProfit: number }>();
  for (const record of records) {
    if (record.isTotal || !(record.revenue > 0) || !Number.isFinite(record.calculatedGrossProfit)) continue;
    const key = record.product.trim().toLocaleLowerCase("fa");
    const current = grouped.get(key) ?? { label: record.product, revenue: 0, grossProfit: 0 };
    current.revenue += record.revenue;
    current.grossProfit += record.calculatedGrossProfit;
    grouped.set(key, current);
  }
  const rate = marginDeltaPp / 100;
  const rows = [...grouped.entries()].map(([key, row]) => {
    const addedGrossProfit = row.revenue * rate;
    const addedNopat = addedGrossProfit * (1 - base.taxRate);
    const roicGain = addedNopat / base.assetSchedule.averageInvestedCapital;
    return {
      key,
      label: row.label,
      revenue: row.revenue,
      grossMargin: row.revenue ? row.grossProfit / row.revenue : null,
      marginDeltaPp,
      addedGrossProfit,
      addedNopat,
      roicGain,
      resultingRoic: base.roic + roicGain,
      resultingSpread: base.spread + roicGain,
      sensitivityShare: 0,
    };
  }).sort((a, b) => b.roicGain - a.roicGain || a.label.localeCompare(b.label, "fa"));
  const total = rows.reduce((sum, row) => sum + row.roicGain, 0);
  return rows.map((row) => ({ ...row, sensitivityShare: total > 0 ? row.roicGain / total : 0 }));
}

export function buildManagementVerdict(
  actual: ValueSnapshot,
  budget: PlanningScenarioSnapshot,
  optimized: PlanningScenarioSnapshot,
  composition: ScenarioAssetCompositionItem[],
  economics: GrowthEconomics,
  topAction?: ScenarioAction,
) {
  const dominant = [...composition].sort((a, b) => b.share - a.share)[0];
  const lines: string[] = [];
  lines.push(
    budget.spread >= 0
      ? "بودجه ۱۴۰۵ هزینه سرمایه را پوشش می‌دهد و وارد محدوده ارزش‌آفرینی می‌شود."
      : `بودجه ۱۴۰۵ هنوز ${fa(Math.abs(budget.spread * 100))} واحد درصد تا پوشش هزینه سرمایه فاصله دارد.`,
  );
  if (economics.revenueGrowth !== null && economics.assetGrowth !== null)
    lines.push(
      economics.revenueGrowth > economics.assetGrowth
        ? "رشد فروش از رشد دارایی سریع‌تر است؛ بهره‌وری دارایی در مسیر بودجه بهتر می‌شود."
        : "دارایی‌ها سریع‌تر از فروش رشد می‌کنند؛ تحقق بودجه به کنترل شدت سرمایه نیاز دارد.",
    );
  if (dominant?.key === "receivables" && dominant.share > 0.5)
    lines.push(
      `تمرکز اصلی دارایی با سهم ${fa(dominant.share * 100, 0)}٪ در مطالبات است.`,
    );
  else if (dominant)
    lines.push(
      `${dominant.label} با سهم ${fa(dominant.share * 100, 0)}٪ بزرگ‌ترین جزء دارایی سناریو است.`,
    );
  if (topAction)
    lines.push(
      `اولویت نخست سناریویی «${topAction.label}» است؛ فاصله ارزش‌آفرینی را ${fa(topAction.spreadGain * 100)} واحد درصد بهبود می‌دهد.`,
    );
  if (optimized.spread >= 0 && budget.spread < 0)
    lines.push(
      "سناریوی فعال شکاف ارزش‌آفرینی را می‌بندد؛ اجرای آن باید با مالک اقدام و پایش ماهانه همراه شود.",
    );
  return lines.slice(0, 4);
}
