import { normalizeText, type FinancialModel, type FinancialRecord } from "./financial-engine";

export type HoldingKey = "atieh" | "metil";

function companyBase(value: unknown) {
  return normalizeText(String(value ?? "").normalize("NFKC"))
    .replace(/^شرکت\s+/, "")
    .replace(/‌/g, " ")
    .replace(/فرآیند/g, "فرایند")
    .replace(/فولاد\s*گستران/g, "فولاد گستران")
    .replace(/چهار\s*محال/g, "چهارمحال")
    .replace(/حدید\s*کاران/g, "حدید کاران")
    .replace(/\s+/g, " ")
    .trim();
}

const COMPANY_ALIASES: Record<string, string> = {
  "آرتاویل": "آهن و فولاد آرتاویل ساخت", "آرتاویل ساخت": "آهن و فولاد آرتاویل ساخت",
  "صنایع آهن و فولاد آرتاویل ساخت": "آهن و فولاد آرتاویل ساخت", "آهن و فولاد آرتاویل ساخت اردبیل": "آهن و فولاد آرتاویل ساخت",
  "آهن فولاد کاسپین": "آهن و فولاد کاسپین", "آهن و فولاد کاسپین": "آهن و فولاد کاسپین", "کاسپین": "آهن و فولاد کاسپین",
  "اصفهان": "آهن و فولاد اصفهان", "بجنورد": "فولاد گستران بجنورد", "فولاد گستران بجنورد": "فولاد گستران بجنورد",
  "پارس فولاد": "پارس فولاد مبین", "توس": "صنایع آهن و فولاد توس", "فولاد توس": "صنایع آهن و فولاد توس",
  "زاگرس چهارمحال": "فولاد زاگرس چهارمحال", "فولاد زاگرس چهارمحال": "فولاد زاگرس چهارمحال",
  "ساخت جنوب": "فولاد ساخت جنوب", "ساوالان زنجان": "آهن و فولاد ساوالان زنجان", "سمنان": "دانا فولاد سمنان",
  "سهند آغاز": "صنایع فولاد سهند آغاز", "صنیع کاوه": "آهن و فولاد صنیع کاوه تهران", "صنیع کاوه تهران": "آهن و فولاد صنیع کاوه تهران",
  "فرا بازار": "فولاد گستر فرابازار", "فولاد گستر فرا بازار": "فولاد گستر فرابازار", "فولاد گستر فرابازار": "فولاد گستر فرابازار",
  "فرایند البرز": "پردازش فولاد فرایند البرز", "فولاد فرایند البرز": "پردازش فولاد فرایند البرز", "پردازش فولاد فرایند البرز": "پردازش فولاد فرایند البرز",
  "کویر": "فولاد فرایند متیل کویر", "فولاد فرایند متیل کویر": "فولاد فرایند متیل کویر",
  "گیلان": "صبا فولاد گیلان", "لرستان": "حدید کاران لرستان", "حدید کاران لرستان": "حدید کاران لرستان",
  "مهر صنعت": "نام آوران مهر صنعت فولاد", "نور": "آهن و فولاد نور", "فولاد نور": "آهن و فولاد نور",
  "صنایع آهن و فولاد نور": "آهن و فولاد نور", "آهن و فولاد نور": "آهن و فولاد نور",
  "هرمزگان": "فولاد گستران هرمزگان", "یزد": "فولاد گستر یزد",
  "صنایع آهن و فولاد درخشان اراک": "فولاد درخشان اراک", "فولاد درخشان اراک": "فولاد درخشان اراک", "درخشان اراک": "فولاد درخشان اراک",
};

export function canonicalCompanyKey(value: unknown) {
  const base = companyBase(value);
  return COMPANY_ALIASES[base] ?? base;
}

export function canonicalHolding(value: unknown): HoldingKey | null {
  const key = companyBase(value);
  if (/آتیه/.test(key)) return "atieh";
  if (/متیل/.test(key)) return "metil";
  return null;
}

export function companyMatches(a: unknown, b: unknown) { return canonicalCompanyKey(a) === canonicalCompanyKey(b); }

export function resolveFinancialCompany(model: FinancialModel, name: unknown) {
  const key = canonicalCompanyKey(name);
  return model.companies.find((company) => canonicalCompanyKey(company) === key) ?? null;
}

export function financialRecordByCanonicalCode(model: FinancialModel, name: unknown, year: number, code: string): FinancialRecord | undefined {
  const company = resolveFinancialCompany(model, name);
  return company ? model.codeIndex.get(company)?.get(year)?.get(code) : undefined;
}
