"use client";
import {useScenarioState,finiteNumber,stringValue,marginMap} from "@/lib/use-scenario-state";

import { useMemo, useState, type ReactNode } from "react";
import { Activity, AlertTriangle, ArrowLeft, BarChart3, Building2, ChevronDown, CircleGauge, RotateCcw, Send, SlidersHorizontal, Target, TrendingUp, WalletCards } from "lucide-react";
import type { FinancialModel } from "@/lib/financial-engine";
import { profitCompanyKey, type ProfitModel } from "@/lib/profit-engine";
import type { ProductionModel } from "@/lib/investment-engine";
import { buildPlanningScenarioSnapshot, type ReleaseTreatment } from "@/lib/planning-scenario-engine";
import { buildProductRoicDrivers, calculateCapitalAllocationLimit, calculateGrowthEconomics, rankScenarioActions, reconcileScenarioInvestedCapital } from "@/lib/planning-decision-engine";
import type { HoldingKey } from "@/lib/company-resolver";
import type { ValueSnapshot } from "@/lib/value-creation-engine";
import CompanySpreadChart from "@/components/company-spread-chart";
import BudgetCapitalPanel from "@/components/budget-capital-panel";

const nf = (v: number | null, d = 1) => v === null || !Number.isFinite(v) ? "—" : new Intl.NumberFormat("fa-IR", { maximumFractionDigits: d, minimumFractionDigits: d }).format(v);
const pct = (v: number | null, d = 1) => v === null ? "—" : `${nf(v * 100, d)}٪`;
const pp = (v: number | null, d = 1) => v === null ? "—" : `${v >= 0 ? "+" : ""}${nf(v * 100, d)} واحد درصد`;
const money = (v: number | null) => v === null ? "—" : Math.abs(v) >= 1000 ? `${nf(v / 1000, 1)} میلیارد ریال` : `${nf(v, 0)} میلیون ریال`;

function Metric({ label, value, sub }: { label: string; value: string; sub?: string }) {
  return <div className="vc-metric"><small>{label}</small><strong><bdi>{value}</bdi></strong>{sub && <span>{sub}</span>}</div>;
}
function SectionTitle({ n, title, icon }: { n: number; title: string; icon: ReactNode }) {
  return <header className="vc32-section-title"><span>{icon}</span><div><h2>{title}</h2></div><b className="vc-section-number" aria-label={`بخش ${n.toLocaleString("fa-IR")}`}>{n.toLocaleString("fa-IR", { minimumIntegerDigits: 2 })}</b></header>;
}
function Disclosure({ n, title, icon, children, className = "" }: { n: number; title: string; icon: ReactNode; children: ReactNode; className?: string }) {
  return <details className={`vc32-section vc32-disclosure ${className}`}><summary><SectionTitle n={n} title={title} icon={icon}/><ChevronDown size={20}/></summary><div className="vc32-disclosure-body">{children}</div></details>;
}

export default function BudgetManagerView({ financialModel, profitModel, productionModel, holding, company, companies, actual, onCompany, onActual }: {
  financialModel: FinancialModel; profitModel: ProfitModel | null; productionModel: ProductionModel | null; holding: HoldingKey;
  company: string; companies: string[]; actual: ValueSnapshot; onCompany: (company: string) => void; onActual: () => void;
}) {
  const scenarioKey=JSON.stringify([holding,company,financialModel.importedAt,profitModel?.importedAt]);
  const [marginDelta,setMarginDelta]=useScenarioState<number>(scenarioKey+':margin',0,finiteNumber),[dsoReduction,setDsoReduction]=useScenarioState<number>(scenarioKey+':dso',0,finiteNumber),[dioReduction,setDioReduction]=useScenarioState<number>(scenarioKey+':dio',0,finiteNumber);
  const [cash,setCash]=useScenarioState<string>(scenarioKey+':cash','',stringValue),[releaseTreatment,setReleaseTreatment]=useScenarioState<ReleaseTreatment>(scenarioKey+':release','cash-retained',(v):v is ReleaseTreatment=>v==='cash-retained'||v==='cash-exits'),[sent,setSent]=useState(false);
  const [productMarginDeltas,setProductMarginDeltas]=useScenarioState<Record<string,number>>(scenarioKey+':products',{},marginMap);
  const budget = useMemo(() => buildPlanningScenarioSnapshot(financialModel, profitModel, productionModel, holding, company), [financialModel, profitModel, productionModel, holding, company]);
  const management = useMemo(() => buildPlanningScenarioSnapshot(financialModel, profitModel, productionModel, holding, company, {
    operatingMarginDelta: marginDelta / 100, dsoReduction, dioReduction,
    cash: cash === "" ? undefined : Math.max(0,Number(cash)), releaseTreatment,
  }), [financialModel, profitModel, productionModel, holding, company, marginDelta, dsoReduction, dioReduction, cash, releaseTreatment]);
  const actions = useMemo(() => budget ? rankScenarioActions(budget, [
    { key: "margin", label: "افزایش حاشیه سود عملیاتی +۱ واحد درصد", snapshot: buildPlanningScenarioSnapshot(financialModel, profitModel, productionModel, holding, company, { operatingMarginDelta: .01 }) },
    { key: "dso", label: "کاهش DSO", snapshot: buildPlanningScenarioSnapshot(financialModel, profitModel, productionModel, holding, company, { dsoReduction: 10 }) },
    { key: "dio", label: "کاهش DIO", snapshot: buildPlanningScenarioSnapshot(financialModel, profitModel, productionModel, holding, company, { dioReduction: 10 }) },
  ]) : [], [budget, financialModel, profitModel, productionModel, holding, company]);
  const productRows = useMemo(() => profitModel?.records.filter((row) => row.companyKey === profitCompanyKey(company) && row.isBudget && row.year===budget?.year && !row.isTotal && (!row.holding || row.holding === holding)) ?? [], [profitModel, company, holding,budget?.year]);
  const productDrivers = useMemo(() => budget ? buildProductRoicDrivers(budget, productRows) : [], [budget, productRows]);
  const productScenario = useMemo(() => {
    if (!budget) return null;
    const addedGrossProfit = productDrivers.reduce((sum, driver) => sum + driver.revenue * (productMarginDeltas[driver.key] ?? 0) / 100, 0);
    const addedNopat = addedGrossProfit * (1 - budget.taxRate);
    const roic = (budget.nopat + addedNopat) / budget.assetSchedule.averageInvestedCapital;
    return {
      addedGrossProfit, addedNopat, roic, spread: roic - budget.wacc,
      operatingMargin: budget.revenue ? (budget.operatingProfit + addedGrossProfit) / budget.revenue : null,
      activeCount: Object.values(productMarginDeltas).filter((value) => value !== 0).length,
    };
  }, [budget, productDrivers, productMarginDeltas]);
  if (!budget || !management) return <div className="vc32-empty"><AlertTriangle /><strong>برآورد دوره بودجه قابل محاسبه نیست.</strong><span>بودجه معتبر، نرخ مالیات، WACC، اقلام دارایی و واحد پولی سازگار لازم است؛ داده مفقود صفر فرض نمی‌شود.</span><button onClick={onActual}>بازگشت به عملکرد واقعی</button></div>;

  const economics = calculateGrowthEconomics(actual, budget), managementControl = reconcileScenarioInvestedCapital(budget, management);
  const capitalLimit = calculateCapitalAllocationLimit(budget), qualityLabel = { high: "بالا", medium: "متوسط", limited: "محدود" }[budget.dataQuality];
  const actualTurnover = actual.averageTotalAssets ? actual.revenue / actual.averageTotalAssets : null;
  const appliedDso = Math.max(0, budget.dso - management.dso), appliedDio = Math.max(0, budget.dio - management.dio);
  const scenarioSentence = `حاشیه سود ${marginDelta>0?"+":""}${nf(marginDelta, 1)} واحد | DSO از ${nf(budget.dso, 1)} به ${nf(management.dso, 1)} روز | DIO از ${nf(budget.dio, 1)} به ${nf(management.dio, 1)} روز`;
  const scenarioVerdict = management.spread >= 0 && budget.spread < 0 ? "شرکت پس از اقدامات مدیریتی وارد محدوده ارزش‌آفرینی می‌شود." : management.spread > budget.spread ? `بهبود ${nf((management.spread - budget.spread) * 100, 1)} واحد درصدی؛ Spread همچنان ${management.spread >= 0 ? "مثبت" : "منفی"} است.` : "سناریوی فعال بهبود معناداری در Spread ایجاد نمی‌کند.";
  const productRevenue = productRows.reduce((sum, row) => sum + row.revenue, 0), productGross = productRows.reduce((sum, row) => sum + row.calculatedGrossProfit, 0);
  const resetAll=()=>{setMarginDelta(0);setDsoReduction(0);setDioReduction(0);setCash("");setReleaseTreatment("cash-retained");setProductMarginDeltas({});setSent(false);};
  const send = () => { window.dispatchEvent(new CustomEvent("ips-optimized-point", { detail: management })); setSent(true); };

  return <div className="value-creation-page vc32-page">
    <header className="vc-workspace-heading"><div><span>موتور ارزش‌آفرینی · برنامه دوره بودجه</span><h1>مسیر سرمایه و سودآوری</h1></div><p>عملکرد واقعی ← بودجه پایه ← سناریوی مدیریتی</p></header>
    <section className="vc32-toolbar no-print"><label><span>شرکت</span><div><Building2 size={17}/><select value={company} onChange={(e) => { onCompany(e.target.value); }}>{companies.map((item) => <option key={item}>{item}</option>)}</select></div></label><button onClick={onActual}>عملکرد واقعی سال پایه</button><span className={`vc32-quality ${budget.dataQuality}`}>کیفیت داده: {qualityLabel}</span></section>

    <button className="outline-button no-print" onClick={resetAll}>بازنشانی تمام سناریوها به بودجه پایه</button><p>دوره بودجه: {budget.year.toLocaleString("fa-IR",{useGrouping:false})} · سال پایه: {(budget.year-1).toLocaleString("fa-IR",{useGrouping:false})}</p><section className="vc32-scenario-controls no-print"><header><SlidersHorizontal size={20}/><div><strong>سناریوی مدیریتی دوره بودجه</strong><small>بودجه ثابت است؛ فقط اثر اهرم‌های انتخابی محاسبه می‌شود.</small></div></header><div>
      <label><span>بهبود حاشیه عملیاتی</span><input type="range" min="0" max="8" step=".5" value={marginDelta} onChange={(e) => { setMarginDelta(Number(e.target.value)); setSent(false); }}/><b>+{nf(marginDelta, 1)} واحد درصد</b></label>
      <label><span>کاهش دوره وصول مطالبات</span><input type="range" min="0" max={Math.max(0, budget.dso)} step="1" value={Math.min(dsoReduction, budget.dso)} onChange={(e) => { setDsoReduction(Number(e.target.value)); setSent(false); }}/><b>{nf(appliedDso, 1)} روز</b></label>
      <label><span>کاهش دوره نگهداری موجودی</span><input type="range" min="0" max={Math.max(0, budget.dio)} step=".1" value={Math.min(dioReduction, budget.dio)} onChange={(e) => { setDioReduction(Number(e.target.value)); setSent(false); }}/><b>{nf(appliedDio, 1)} روز</b></label>
    </div><button className="vc32-send" onClick={send}><Send size={16}/>{sent ? "سناریوی فعال به نقشه ارسال شد" : "ارسال همین سناریو به نقشه"}</button></section>

    <section className="vc32-section" data-qa-section="1"><SectionTitle n={1} title="وضعیت و مسیر" icon={<Activity/>}/><div className="vc32-path">
      {[
        { label: `واقعی ${actual.year.toLocaleString("fa-IR",{useGrouping:false})}`, turnover: actualTurnover, ic: actual.averageIc, roic: actual.roic, spread: actual.spread, kind: "actual" },
        { label: `بودجه ${budget.year.toLocaleString("fa-IR",{useGrouping:false})}`, turnover: budget.assetTurnover, ic: budget.assetSchedule.averageInvestedCapital, roic: budget.roic, spread: budget.spread, kind: "budget" },
        { label: "سناریوی مدیریتی دوره بودجه", turnover: management.assetTurnover, ic: management.assetSchedule.averageInvestedCapital, roic: management.roic, spread: management.spread, kind: "optimized" },
      ].map((item, index) => <div className="vc32-path-item" key={item.kind}><article className={item.kind}><span>{item.label}</span><Metric label="گردش دارایی" value={`${nf(item.turnover, 2)} برابر`}/><Metric label="متوسط سرمایه درگیر" value={money(item.ic)}/><Metric label="بازده سرمایه (ROIC)" value={pct(item.roic)}/><Metric label="اسپرد ارزش‌آفرینی" value={pp(item.spread)}/></article>{index < 2 && <ArrowLeft/>}</div>)}
    </div><p className="vc32-applied">{scenarioSentence}</p><p className={`vc32-scenario-verdict ${management.spread >= 0 ? "positive" : "negative"}`}>{scenarioVerdict}</p>{!managementControl.ok && <p className="vc32-warning">سناریو به علت مغایرت تطبیق سرمایه درگیر معتبر نیست.</p>}</section>

    <Disclosure n={2} title="رشد و سرمایه موردنیاز" icon={<TrendingUp/>}><div className="vc32-kpis compact-four"><Metric label="رشد درآمد" value={pct(economics.revenueGrowth)}/><Metric label="رشد سود عملیاتی" value={pct(economics.operatingProfitGrowth)}/><Metric label="رشد متوسط سرمایه درگیر" value={pct(economics.investedCapitalGrowth)}/><Metric label="سرمایه لازم به ازای هر ۱ ریال فروش افزوده" value={economics.capitalPerAddedRevenue === null ? "قابل محاسبه نیست" : nf(economics.capitalPerAddedRevenue, 2)} sub={economics.capitalPerAddedRevenue === null ? "فروش افزوده مثبت نیست" : `برای هر ۱ ریال فروش، ${nf(economics.capitalPerAddedRevenue, 2)} ریال سرمایه`}/></div></Disclosure>

    <BudgetCapitalPanel actual={actual} budget={budget}/>

    <Disclosure n={4} title="آیا رشد ارزش‌آفرین است؟" icon={<CircleGauge/>}><div className="vc32-incremental"><Metric label="بازده سرمایه افزوده" value={economics.incrementalReturn === null ? (economics.capitalState === "released" ? "همزمان با رشد، سرمایه آزاد شده است" : "قابل محاسبه نیست") : pct(economics.incrementalReturn)}/><span>در مقایسه با</span><Metric label="هزینه سرمایه" value={pct(budget.wacc)}/></div><p className={economics.incrementalReturn !== null && economics.incrementalReturn > budget.wacc ? "positive" : "negative"}>{economics.incrementalReturn === null ? (economics.capitalState === "released" ? "رشد بدون نیاز به سرمایه افزوده رخ داده است." : "داده کافی برای تفسیر بازده افزوده وجود ندارد.") : economics.incrementalReturn > budget.wacc ? "رشد جدید ارزش‌آفرین است." : "رشد جدید هنوز هزینه سرمایه را پوشش نمی‌دهد."}</p></Disclosure>

    <Disclosure n={5} title="مقایسه Spread شرکت‌ها" icon={<BarChart3/>} className="vc32-spread-disclosure"><CompanySpreadChart financialModel={financialModel} profitModel={profitModel} productionModel={productionModel} holding={holding} year={budget.year} basis="budget" selectedCompany={company}/></Disclosure>

    <section className="vc32-section vc32-driver-lab" data-qa-section="6"><SectionTitle n={6} title="شبیه‌ساز حاشیه سود محصولات و اثر بر ROIC" icon={<BarChart3/>}/>{productDrivers.length > 0 && productScenario ? <><div className="vc32-product-scenario-result"><div><small>ROIC بودجه پایه</small><strong>{pct(budget.roic)}</strong></div><ArrowLeft/><div className="active"><small>ROIC سناریوی محصول</small><strong>{pct(productScenario.roic)}</strong><span>{pp(productScenario.roic - budget.roic)} تغییر</span></div><div><small>Spread جدید</small><strong className={productScenario.spread >= 0 ? "positive" : "negative"}>{pp(productScenario.spread)}</strong></div><div><small>NOPAT افزوده</small><strong>{money(productScenario.addedNopat)}</strong></div></div><div className="vc32-product-simulator-head"><div><strong>حاشیه کدام محصول تغییر کند؟</strong><span>اسلایدر هر ردیف مستقل است و اثر همه تغییرات با هم محاسبه می‌شود.</span></div><button type="button" onClick={() => setProductMarginDeltas({})} disabled={productScenario.activeCount === 0}><RotateCcw size={16}/>بازنشانی</button></div><div className="vc32-product-sliders">{productDrivers.map((driver, index) => { const delta = productMarginDeltas[driver.key] ?? 0; const rowNopat = driver.revenue * delta / 100 * (1 - budget.taxRate); return <article className={delta !== 0 ? "changed" : ""} key={driver.key}><span className="rank">{(index + 1).toLocaleString("fa-IR")}</span><div className="product-identity"><strong>{driver.label}</strong><small>حاشیه پایه: {pct(driver.grossMargin)} · حساسیت هر ۱ واحد: {pp(driver.roicGain)}</small></div><label><span>تغییر حاشیه</span><input type="range" min="-5" max="10" step=".5" value={delta} onChange={(e) => setProductMarginDeltas((current) => ({ ...current, [driver.key]: Number(e.target.value) }))}/><b>{delta > 0 ? "+" : ""}{nf(delta, 1)} واحد درصد</b></label><div className="product-impact"><strong>{pp(rowNopat / budget.assetSchedule.averageInvestedCapital)}</strong><small>اثر بر ROIC</small></div></article>; })}</div><div className="vc32-scenario-foot"><Metric label="حاشیه عملیاتی سناریو" value={pct(productScenario.operatingMargin)}/><Metric label="سود عملیاتی افزوده" value={money(productScenario.addedGrossProfit)}/><p><strong>مبنای محاسبه:</strong> تغییر حاشیه ناخالص هر محصول مستقیماً به سود عملیاتی منتقل شده و درآمد، سرمایه درگیر و نرخ مالیات ثابت مانده‌اند. مقادیر منفی نیز برای آزمون ریسک بودجه قابل انتخاب‌اند.</p></div></> : <div className="vc32-driver-empty"><AlertTriangle/><div><strong>شکست تفصیلی بودجه این شرکت در دسترس نیست.</strong><span>برای شبیه‌سازی، ردیف‌های محصول/فعالیت شامل درآمد و بهای تمام‌شده بودجه پایه را بارگذاری کنید.</span></div></div>}</section>

    <Disclosure n={7} title="اولویت اقدامات مدیریتی تجمیعی" icon={<Target/>}>{actions.length > 0 && actions.every((action) => action.snapshot.spread < 0) && <p className="vc32-note">هیچ‌یک از اقدامات منفرد فعلی به‌تنهایی Spread را به صفر نمی‌رساند.</p>}<div className="vc32-actions">{actions.slice(0, 3).map((action, index) => <article key={action.key}><span>{(index + 1).toLocaleString("fa-IR")}</span><div><strong>{action.key === "dso" ? `کاهش دوره وصول از ${nf(action.appliedFrom, 1)} به ${nf(action.appliedTo, 1)} روز` : action.key === "dio" ? `کاهش دوره موجودی از ${nf(action.appliedFrom, 1)} به ${nf(action.appliedTo, 1)} روز` : action.label}</strong><small>اثر بر Spread: {pp(action.spreadGain)}{action.investedCapitalReduction > 0 ? ` · سرمایه آزادشده: ${money(action.investedCapitalReduction)}` : ""}</small></div></article>)}</div></Disclosure>

    {productRows.length > 0 && <details className="vc32-section vc32-products" data-qa-section="8"><summary><SectionTitle n={8} title="جزئیات سودآوری محصولات/فعالیت‌ها" icon={<WalletCards/>}/><ChevronDown/></summary><div className="vc32-product-table"><div className="head"><span>محصول/فعالیت</span><span>درآمد</span><span>بهای تمام‌شده</span><span>سود ناخالص</span><span>حاشیه</span><span>سهم فروش</span><span>سهم سود ناخالص</span></div>{productRows.map((row) => <div key={`${row.product}-${row.sourceRow}`}><strong>{row.product}</strong><span>{money(row.revenue)}</span><span>{money(row.normalizedCogs)}</span><span>{money(row.calculatedGrossProfit)}</span><span>{pct(row.revenue ? row.calculatedGrossProfit / row.revenue : null)}</span><span>{pct(productRevenue ? row.revenue / productRevenue : null)}</span><span>{pct(productGross ? row.calculatedGrossProfit / productGross : null)}</span></div>)}</div><p>سود عملیاتی کل شرکت: <strong>{money(budget.operatingProfit)}</strong>؛ این مبلغ بین محصولات تخصیص داده نشده است.</p></details>}

    <Disclosure n={9} title="سرمایه قابل‌تخصیص و حد مجاز" icon={<WalletCards/>} className="vc32-capital-limit"><div className="vc32-kpis compact-three"><Metric label="سرمایه موردنیاز بودجه" value={money(capitalLimit.budgetInvestedCapital)}/><Metric label="سقف سرمایه اقتصادی قابل‌قبول" value={money(capitalLimit.economicCapitalLimit)}/><Metric label={capitalLimit.state === "excess" ? "مازاد سرمایه نسبت به سطح ارزش‌آفرین" : "ظرفیت سرمایه تا نقطه سربه‌سر"} value={money(capitalLimit.capitalGap === null ? null : Math.abs(capitalLimit.capitalGap))}/></div>{capitalLimit.state === "excess" && <p>برای رسیدن به Spread صفر، با سطح فعلی سودآوری تقریباً <strong>{money(capitalLimit.capitalGap)}</strong> سرمایه باید آزاد شود؛ یا NOPAT حدود <strong>{money(capitalLimit.requiredNopatIncrease)}</strong> افزایش یابد.</p>}</Disclosure>

    <details className="vc32-method"><summary><SlidersHorizontal size={18}/><span><strong>مفروضات و تنظیمات پیشرفته</strong><small>نقد پایه، رفتار نقد، منابع و روش محاسبه</small></span><ChevronDown size={18}/></summary><div className="vc32-advanced-controls no-print"><label><span>نقد پایه سناریوی دوره بودجه</span><input type="number" min="0" value={cash} placeholder={nf(budget.assetSchedule.cash, 0)} onChange={(e) => { setCash(e.target.value); setSent(false); }}/></label><label><span>رفتار نقد آزادشده</span><select value={releaseTreatment} onChange={(e) => { setReleaseTreatment(e.target.value as ReleaseTreatment); setSent(false); }}><option value="cash-retained">حفظ در نقد شرکت</option><option value="cash-exits">خروج از ترازنامه</option></select></label><p>نقد، WACC و FCF از آخرین عملکرد معتبر حمل می‌شوند. امتیاز سناریویی بر مبنای خط‌کش ثابت عملکرد واقعی تا پایان سال پایه است ({budget.scoringVersion}).</p><p>رشد NOPAT قابل‌مقایسه: {pct(economics.nopatGrowth)} · رشد متوسط دارایی: {pct(economics.assetGrowth)}. NOPAT قابل‌مقایسه هر دو سال از سود عملیاتی × (۱−نرخ مالیات) ساخته می‌شود.</p>{budget.warnings.map((warning) => <p className="warning" key={warning}>{warning}</p>)}</div></details>
  </div>;
}
