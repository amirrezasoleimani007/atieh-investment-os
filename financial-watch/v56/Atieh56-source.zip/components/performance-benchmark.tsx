"use client";
import {buildBenchmarkRows} from "@/lib/benchmark-engine";

import { useEffect, useMemo, useRef, useState } from "react";
import * as XLSX from "xlsx";
import { BarChart3, Check, ChevronDown, Eye, FileSpreadsheet, ImageDown, Info, Maximize2, Minimize2, Printer, RotateCcw, SlidersHorizontal, Sparkles, X } from "lucide-react";
import {
  BENCHMARK_METRIC_DEFINITIONS,
  medianMetric,
  peersFor,
  type BenchmarkCompany,
  type BenchmarkMetricKey,
  type BenchmarkModel,
} from "@/lib/benchmark-engine";
import { formatComputedBenchmark, formatRawBenchmark, rawBenchmarkUnit } from "@/lib/benchmark-format";

const MAIN_METRICS = ["operatingProfitGrowth", "netProfitGrowth", "revenueGrowth", "operatingMarginDelta", "cfoMarginDelta"] as const satisfies readonly BenchmarkMetricKey[];
type MainMetricKey = (typeof MAIN_METRICS)[number];
type SortMode = "ascending" | "descending" | "fixed" | "alphabetical";
type ReferenceMode = "median" | "average";
type ComparisonMode = "peers" | "competitors" | "atieh";
type SelectionBasis = "company" | "nature";

const METRIC_TITLES: Record<MainMetricKey, { fa: string; en: string; story: string }> = {
  operatingProfitGrowth: { fa: "رشد سود عملیاتی", en: "Operating Profit Growth", story: "سود عملیاتی" },
  netProfitGrowth: { fa: "رشد سود خالص", en: "Net Profit Growth", story: "سود خالص" },
  revenueGrowth: { fa: "رشد درآمد", en: "Revenue Growth", story: "درآمد عملیاتی" },
  operatingMarginDelta: { fa: "تغییر حاشیه سود عملیاتی", en: "Operating Margin Change", story: "حاشیه سود عملیاتی" },
  cfoMarginDelta: { fa: "تغییر CFO Margin", en: "CFO Margin Change", story: "CFO Margin" },
};

function compactName(value: string, aggressive = false) {
  const normalized = value.replace(/سرمایه\s*گذاری/g, "سرمایه‌گذاری").replace(/گروه صنعتی/g, "").replace(/شرکت/g, "").replace(/سهامی\s*(عام|خاص)/g, "").replace(/نقش جهان/g, "").trim();
  return !aggressive || normalized.length <= 18 ? normalized : `${normalized.slice(0, 17).trim()}…`;
}

function chartLabelLines(value: string) {
  const normalized = compactName(value);
  const max = 15;
  const words = normalized.split(/\s+/).filter(Boolean);
  const lines: string[] = [];
  let current = "";

  for (const word of words) {
    const candidate = `${current}${current ? " " : ""}${word}`;
    if (candidate.length <= max || !current) current = candidate;
    else {
      lines.push(current);
      current = word;
    }
  }
  if (current) lines.push(current);

  // Keep the complete recognizable part of the company name visible in a
  // maximum of three balanced lines. Only exceptionally long names are cut.
  if (lines.length <= 3) return lines;
  return [lines[0], lines[1], `${lines.slice(2).join(" ").slice(0, max + 4).trim()}…`];
}

function meanMetric(rows: BenchmarkCompany[], metric: BenchmarkMetricKey) {
  const values = rows.map((row) => row.metrics[metric].value).filter((value): value is number => value !== null && Number.isFinite(value));
  return values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : null;
}

function quantile(values: number[], probability: number) {
  const sorted = [...values].sort((a, b) => a - b);
  const position = (sorted.length - 1) * probability;
  const base = Math.floor(position);
  const rest = position - base;
  return sorted[base + 1] === undefined ? sorted[base] : sorted[base] + rest * (sorted[base + 1] - sorted[base]);
}

function robustDomain(values: number[]) {
  if (!values.length) return { min: -10, max: 10, clippedLow: false, clippedHigh: false };
  const actualMin = Math.min(...values);
  const actualMax = Math.max(...values);
  if (actualMin === actualMax) {
    const pad = Math.max(Math.abs(actualMin) * 0.25, 5);
    return { min: Math.min(0, actualMin - pad), max: Math.max(0, actualMax + pad), clippedLow: false, clippedHigh: false };
  }
  let low = actualMin;
  let high = actualMax;
  if (values.length >= 5) {
    const q1 = quantile(values, 0.25);
    const q3 = quantile(values, 0.75);
    const iqr = q3 - q1;
    if (iqr > 0) {
      low = Math.max(actualMin, q1 - 1.75 * iqr);
      high = Math.min(actualMax, q3 + 1.75 * iqr);
    }
  }
  low = Math.min(low, 0);
  high = Math.max(high, 0);
  const span = Math.max(high - low, 1);
  return { min: low - span * 0.08, max: high + span * 0.1, clippedLow: actualMin < low, clippedHigh: actualMax > high };
}

function formatAxis(value: number, metric: MainMetricKey) {
  const number = value.toLocaleString("fa-IR", { maximumFractionDigits: Math.abs(value) >= 100 ? 0 : 1 });
  return BENCHMARK_METRIC_DEFINITIONS[metric].unit === "pp" ? `${number} واحد درصد` : `${number}٪`;
}

function rankFor(rows: BenchmarkCompany[], metric: MainMetricKey, company: BenchmarkCompany) {
  const ranked = [...rows].filter((row) => row.metrics[metric].sortValue !== null).sort((a, b) => (b.metrics[metric].sortValue as number) - (a.metrics[metric].sortValue as number));
  const index = ranked.findIndex((row) => row.name === company.name);
  return index < 0 ? null : { rank: index + 1, total: ranked.length };
}

function useElementWidth<T extends HTMLElement>() {
  const ref = useRef<T>(null);
  const [width, setWidth] = useState(720);
  useEffect(() => {
    if (!ref.current) return;
    const update = () => setWidth(Math.max(320, ref.current?.clientWidth ?? 720));
    update();
    const observer = new ResizeObserver(update);
    observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);
  return [ref, width] as const;
}

function MarkerPlot({ metric, rows, target, referenceMode, sortMode, fixedOrder, activeCompany, onActiveCompany, focusMode, onInspect, priority }: {
  metric: MainMetricKey;
  rows: BenchmarkCompany[];
  target: BenchmarkCompany;
  referenceMode: ReferenceMode;
  sortMode: SortMode;
  fixedOrder: string[];
  activeCompany: string | null;
  onActiveCompany: (name: string | null) => void;
  focusMode: boolean;
  onInspect: (company: BenchmarkCompany, metric: MainMetricKey) => void;
  priority?: boolean;
}) {
  const [hostRef, measuredWidth] = useElementWidth<HTMLDivElement>();
  const hovered = activeCompany ? rows.find((row) => row.name === activeCompany) ?? null : null;
  const sortedRows = useMemo(() => {
    const copy = [...rows];
    if (sortMode === "alphabetical") return copy.sort((a, b) => a.name.localeCompare(b.name, "fa"));
    if (sortMode === "fixed") return copy.sort((a, b) => fixedOrder.indexOf(a.name) - fixedOrder.indexOf(b.name));
    return copy.sort((a, b) => {
      const av = a.metrics[metric].sortValue;
      const bv = b.metrics[metric].sortValue;
      if (av === null) return 1;
      if (bv === null) return -1;
      return sortMode === "ascending" ? av - bv : bv - av;
    });
  }, [rows, metric, sortMode, fixedOrder]);
  const referenceRows = rows.filter((row) => row.name !== target.name);
  const reference = referenceMode === "median" ? medianMetric(referenceRows, metric) : meanMetric(referenceRows, metric);
  const referenceValues = referenceRows.map((row) => row.metrics[metric].value).filter((value): value is number => value !== null && Number.isFinite(value));
  const q1 = referenceValues.length >= 3 ? quantile(referenceValues, .25) : null;
  const q3 = referenceValues.length >= 3 ? quantile(referenceValues, .75) : null;
  const values = rows.map((row) => row.metrics[metric].value).filter((value): value is number => value !== null && Number.isFinite(value));
  if (reference !== null) values.push(reference);
  const domain = robustDomain(values);
  // Reserve a real horizontal slot for every company. On narrower layouts the
  // plot scrolls horizontally instead of compressing or overlapping labels.
  const companySlotWidth = 134;
  const width = Math.max(measuredWidth, sortedRows.length * companySlotWidth + 132);
  const height = 586;
  // Keep a protected band above the plot so value labels never sit on top of
  // the marker, including the larger animated Atieh marker.
  const margin = { top: 78, right: 42, bottom: 142, left: 76 };
  const plotWidth = Math.max(100, width - margin.right - margin.left);
  const plotHeight = height - margin.top - margin.bottom;
  const x = (index: number) => margin.left + ((index + 0.5) / Math.max(1, sortedRows.length)) * plotWidth;
  const y = (value: number) => margin.top + ((domain.max - Math.max(domain.min, Math.min(domain.max, value))) / (domain.max - domain.min)) * plotHeight;
  const ticks = Array.from({ length: 5 }, (_, index) => domain.min + ((domain.max - domain.min) * index) / 4);
  const hoveredIndex = hovered ? sortedRows.findIndex((row) => row.name === hovered.name) : -1;
  const hoveredMetric = hovered?.metrics[metric];
  const hoveredRank = hovered ? rankFor(rows, metric, hovered) : null;
  const hoveredX = hoveredIndex >= 0 ? x(hoveredIndex) : 0;
  const hoveredY = hoveredMetric?.value !== null && hoveredMetric?.value !== undefined ? y(hoveredMetric.value) : hoveredMetric?.status === "turnaround" ? margin.top + 8 : margin.top + plotHeight - 8;
  const targetMetric = target.metrics[metric];
  const valueLabel = (company: BenchmarkCompany) => company.metrics[metric].label;



  return (
    <article className={`benchmark-viz-card ${priority ? "priority" : ""}`}>
      <header className="benchmark-viz-header">
        <div className="benchmark-viz-title"><span className="benchmark-viz-eyebrow">{METRIC_TITLES[metric].en}</span><h2>{METRIC_TITLES[metric].fa}</h2><p>عملکرد واقعی دوره منتخب نسبت به دوره پایه · {BENCHMARK_METRIC_DEFINITIONS[metric].unit === "pp" ? "واحد درصد" : "درصد"}</p></div>
        <div className="benchmark-chart-insights">
          <div className="benchmark-reference-summary"><span>{referenceMode === "median" ? "میانه هم‌رده‌ها" : "میانگین هم‌رده‌ها"}</span><strong>{formatComputedBenchmark(reference, metric)}</strong></div>
          <div className="benchmark-selected-summary"><span>{compactName(target.name)}</span><strong>{targetMetric.label}</strong></div>
        </div>
      </header>
      <div className={`benchmark-plot-host ${focusMode ? "focus-mode" : ""}`} ref={hostRef} onMouseLeave={() => onActiveCompany(null)}>
        <svg width={width} height={height} role="img" aria-label={`نمودار مقایسه ${METRIC_TITLES[metric].fa}`}>
          <defs>
            <linearGradient id={`atieh-marker-${metric}`} x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#22d3c5" />
              <stop offset="100%" stopColor="#2474b5" />
            </linearGradient>
            <linearGradient id={`target-marker-${metric}`} x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#21c7b5" />
              <stop offset="100%" stopColor="#0b5f8f" />
            </linearGradient>
          </defs>
          <g className="benchmark-company-columns">
            {sortedRows.map((company, index) => {
              const slotWidth = plotWidth / Math.max(1, sortedRows.length);
              const isTarget = company.name === target.name;
              const isAtieh = company.position === "atieh";
              return <g key={company.name} className={isTarget ? "selected" : isAtieh ? "atieh" : "competitor"}>
                <rect x={margin.left + index * slotWidth} y={margin.top} width={slotWidth} height={plotHeight} />
                {index > 0 && <line x1={margin.left + index * slotWidth} x2={margin.left + index * slotWidth} y1={margin.top} y2={margin.top + plotHeight} />}
              </g>;
            })}
          </g>
          <g className="benchmark-axis-layer">
            {q1 !== null && q3 !== null && <g className="benchmark-quartile-band"><rect x={margin.left} y={y(q3)} width={plotWidth} height={Math.max(2, y(q1) - y(q3))} /><text x={width - margin.right - 8} y={y(q3) + 17}>محدوده متعارف</text></g>}
            {ticks.map((tick, index) => { const tickY = y(tick); return <g key={index}><line x1={margin.left} x2={width - margin.right} y1={tickY} y2={tickY} className="benchmark-grid-line" /><text x={margin.left - 14} y={tickY + 5} className="benchmark-y-label">{formatAxis(tick, metric)}</text></g>; })}
            {domain.min <= 0 && domain.max >= 0 && <g className="benchmark-zero-reference"><line x1={margin.left} x2={width - margin.right} y1={y(0)} y2={y(0)} className="benchmark-zero-line" /><rect x={width - margin.right - 54} y={y(0) - 13} width="50" height="23" rx="6" /><text x={width - margin.right - 29} y={y(0) + 4}>صفر</text></g>}
            {reference !== null && <g className="benchmark-reference-line" style={{ transform: `translateY(${y(reference)}px)` }}><line x1={margin.left} x2={width - margin.right} y1={0} y2={0} /><circle cx={width - margin.right} cy={0} r="4.5" /><g className="benchmark-reference-label"><rect x={margin.left + 8} y={-15} width="196" height="28" rx="7" /><text x={margin.left + 106} y={5}>{referenceMode === "median" ? "میانه سایر هم‌رده‌ها" : "میانگین سایر هم‌رده‌ها"} · {formatComputedBenchmark(reference, metric)}</text></g></g>}
          </g>
          <g className={`benchmark-markers ${hovered ? "has-hover" : ""}`}>
            {sortedRows.map((company, index) => {
              const metricValue = company.metrics[metric];
              const isTarget = company.name === target.name;
              const isAtieh = company.position === "atieh";
              const isHovered = hovered?.name === company.name;
              const hasRaw = metricValue.previous !== null || metricValue.current !== null;
              if (metricValue.value === null && !hasRaw) return null;
              const statusY = metricValue.status === "turnaround" ? margin.top + 9 : margin.top + plotHeight - 9;
              const pointY = metricValue.value === null ? statusY : y(metricValue.value);
              const clipped = metricValue.value !== null && (metricValue.value < domain.min || metricValue.value > domain.max);
              const radius = isTarget ? 11 : isAtieh ? 9 : 7.5;
              const visualRadius = isTarget ? 19 : isAtieh ? 15 : radius;
              const labelHalfHeight = 13;
              const labelGap = isAtieh ? 11 : 9;
              const labelY = Math.max(19, pointY - visualRadius - labelHalfHeight - labelGap);
              return (
                <g key={company.name} className="benchmark-marker-position" style={{ transform: `translate(${x(index)}px, ${pointY}px)` }}>
                  <g className={`benchmark-marker ${isTarget ? "target" : isAtieh ? "atieh" : "competitor"} ${isHovered ? "hovered" : ""} ${activeCompany && !isHovered ? "deemphasized" : ""} ${metricValue.status}`} role="button" tabIndex={0} aria-label={`${company.name}: ${metricValue.label}`} onMouseEnter={() => onActiveCompany(company.name)} onFocus={() => onActiveCompany(company.name)} onBlur={() => onActiveCompany(null)} onClick={() => onInspect(company, metric)} onKeyDown={(event) => { if (event.key === "Enter" || event.key === " ") onInspect(company, metric); }} style={{ animationDelay: `${Math.min(index * 28, 280)}ms` }}>
                    {isTarget && <circle cx="0" cy="0" r="19" className="benchmark-marker-pulse" />}
                    {isAtieh && <circle cx="0" cy="0" r={isTarget ? 14.5 : 12} className="benchmark-marker-ring" />}
                    <circle cx="0" cy="0" r={radius} className="benchmark-dot" style={{ fill: isTarget ? `url(#target-marker-${metric})` : isAtieh ? `url(#atieh-marker-${metric})` : undefined }} />
                    {(metricValue.value === null || clipped) && <circle cx="0" cy="0" r={2.2} className="benchmark-status-core" />}
                  </g>
                  <g className={`benchmark-point-value ${isTarget ? "target" : isAtieh ? "atieh" : "competitor"} ${activeCompany && !isHovered ? "deemphasized" : ""}`} transform={`translate(0 ${labelY - pointY})`}>
                    {isAtieh && <rect x="-40" y="-15" width="80" height="27" rx="9" />}
                    <text x="0" y="4.5">{valueLabel(company)}</text>
                  </g>
                </g>
              );
            })}
          </g>
          <g className="benchmark-label-rail"><rect x={margin.left} y={height - margin.bottom + 8} width={plotWidth} height={112} rx="8" /></g>
          <g className="benchmark-x-labels">{sortedRows.map((company, index) => { const lines = chartLabelLines(company.name); const labelY = height - margin.bottom + 34; const isTarget = company.name === target.name; const isActive = company.name === activeCompany; return <g key={company.name} className={`${isTarget ? "selected" : company.position} ${isActive ? "active" : ""} ${activeCompany && !isActive ? "deemphasized" : ""}`}>{(isTarget || isActive) && <rect x={x(index) - 61} y={labelY - 23} width="122" height={lines.length === 3 ? 78 : lines.length === 2 ? 59 : 41} rx="8" />}<text x={x(index)} y={labelY} textAnchor="middle"><title>{company.name}</title>{lines.map((line, lineIndex) => <tspan key={lineIndex} x={x(index)} dy={lineIndex === 0 ? 0 : 21}>{line}</tspan>)}</text>{company.position === "atieh" && <circle cx={x(index)} cy={labelY + lines.length * 21 + 1} r={isTarget ? 3.5 : 2.8} className="benchmark-company-badge" />}</g>; })}</g>
        </svg>
        {hovered && hoveredMetric && <div className="benchmark-tooltip" style={{ left: Math.min(width - 174, Math.max(174, hoveredX)), top: Math.max(86, Math.min(height - 190, hoveredY)) }}><strong>{hovered.name}</strong><b>{hoveredMetric.label}</b><div className="benchmark-tooltip-period"><span>دوره پایه <em>{formatRawBenchmark(hoveredMetric.previous, metric, hoveredMetric.previousUnit)}</em></span><i>←</i><span>دوره منتخب <em>{formatRawBenchmark(hoveredMetric.current, metric, hoveredMetric.currentUnit)}</em></span></div><dl><div><dt>{referenceMode === "median" ? "میانه هم‌رده‌ها" : "میانگین هم‌رده‌ها"}</dt><dd>{formatComputedBenchmark(reference, metric)}</dd></div><div><dt>فاصله از مرجع</dt><dd>{hoveredMetric.value === null || reference === null ? "—" : formatComputedBenchmark(hoveredMetric.value - reference, metric)}</dd></div><div><dt>رتبه</dt><dd>{hoveredRank ? `${hoveredRank.rank.toLocaleString("fa-IR")} از ${hoveredRank.total.toLocaleString("fa-IR")}` : "—"}</dd></div><div><dt>مالکیت</dt><dd>{hovered.position === "atieh" ? "آتیه" : "رقیب"}</dd></div></dl><span>برای مشاهده جزئیات کامل کلیک کنید</span></div>}
      </div>
      {(domain.clippedHigh || domain.clippedLow) && <span className="benchmark-outlier-badge" title="مقادیر پرت با دایره دارای هسته مشخص می‌شوند و مقدار واقعی در Tooltip محفوظ است."><Info size={15} /> داده پرت</span>}
    </article>
  );
}

function DrawerColumnChart({ metric, company, comparison }: { metric: MainMetricKey; company: BenchmarkCompany; comparison: BenchmarkCompany }) {
  const width = 560;
  const height = 332;
  const margin = { top: 58, right: 35, bottom: 50, left: 35 };
  const plotHeight = height - margin.top - margin.bottom;
  const values = [company.metrics[metric].previous, comparison.metrics[metric].previous, company.metrics[metric].current, comparison.metrics[metric].current].filter((value): value is number => value !== null && Number.isFinite(value));
  const min = Math.min(0, ...values);
  const max = Math.max(0, ...values);
  const span = Math.max(max - min, 1);
  const domainMin = min - span * 0.08;
  const domainMax = max + span * 0.18;
  const y = (value: number) => margin.top + ((domainMax - value) / (domainMax - domainMin)) * plotHeight;
  const zeroY = y(0);
  const years = [1403, 1404] as const;
  const series = [company, comparison];
  return <div className="benchmark-drawer-chart"><div className="benchmark-drawer-unit">ارقام به {rawBenchmarkUnit(metric, company.metrics[metric].currentUnit || comparison.metrics[metric].currentUnit)}</div><svg viewBox={`0 0 ${width} ${height}`} role="img" aria-label={`مقایسه مقادیر واقعی ${METRIC_TITLES[metric].story}`}><line x1={margin.left} x2={width - margin.right} y1={zeroY} y2={zeroY} className="drawer-zero-line" />{years.map((year, yearIndex) => { const groupCenter = yearIndex === 0 ? 165 : 395; return <g key={year}>{series.map((row, seriesIndex) => { const metricValue = row.metrics[metric]; const value = year === 1403 ? metricValue.previous : metricValue.current; const unit = year === 1403 ? metricValue.previousUnit : metricValue.currentUnit; if (value === null) return null; const barWidth = 70; const gap = 16; const barX = groupCenter + (seriesIndex === 0 ? -barWidth - gap / 2 : gap / 2); const barY = Math.min(y(value), zeroY); const barHeight = Math.max(2, Math.abs(zeroY - y(value))); return <g key={`${year}-${seriesIndex}-${row.name}`} className={`drawer-bar-series ${seriesIndex === 0 ? "inspected" : "selected"}`} style={{ animationDelay: `${yearIndex * 80 + seriesIndex * 90}ms` }}><rect x={barX} y={barY} width={barWidth} height={barHeight} rx="8" /><text x={barX + barWidth / 2} y={value >= 0 ? Math.max(29, barY - 14) : Math.min(height - 58, barY + barHeight + 23)} className="drawer-bar-value">{formatRawBenchmark(value, metric, unit, false)}</text></g>; })}<text x={groupCenter} y={height - 15} className="drawer-year-label">{year.toLocaleString("fa-IR", { useGrouping: false })}</text></g>; })}</svg></div>;
}

function MetricSummary({ company, metric, role }: { company: BenchmarkCompany; metric: MainMetricKey; role: "inspected" | "selected" }) {
  const value = company.metrics[metric];
  const unit = rawBenchmarkUnit(metric, value.currentUnit || value.previousUnit);
  return <article className={`benchmark-drawer-summary ${role}`}><span>{role === "selected" ? "شرکت منتخب آتیه" : company.position === "atieh" ? "شرکت آتیه" : "شرکت رقیب"}<small>ارقام به {unit}</small></span><h3>{company.name}</h3><div className="benchmark-period-flow"><p><small>دوره پایه</small><strong>{formatRawBenchmark(value.previous, metric, value.previousUnit, false)}</strong></p><i aria-hidden="true">←</i><p><small>دوره منتخب</small><strong>{formatRawBenchmark(value.current, metric, value.currentUnit, false)}</strong></p></div><footer><span>تغییر دوره منتخب نسبت به دوره پایه</span><b>{value.label}</b></footer></article>;
}

function DetailDrawer({ company, metric, target, atiehCompanies, onClose }: { company: BenchmarkCompany; metric: MainMetricKey; target: BenchmarkCompany; atiehCompanies: BenchmarkCompany[]; onClose: () => void }) {
  const initialComparison = target.name !== company.name ? target.name : atiehCompanies.find((row) => row.name !== company.name)?.name ?? target.name;
  const [comparisonName, setComparisonName] = useState(initialComparison);
  const comparison = atiehCompanies.find((row) => row.name === comparisonName) ?? target;
  useEffect(() => { const closeOnEscape = (event: KeyboardEvent) => { if (event.key === "Escape") onClose(); }; document.addEventListener("keydown", closeOnEscape); return () => document.removeEventListener("keydown", closeOnEscape); }, [onClose]);
  return <aside className="benchmark-story-drawer benchmark-chart-only-drawer" aria-label="نمودار مقایسه عملکرد واقعی"><header><div><span>مقایسه مقادیر واقعی</span><h2>{METRIC_TITLES[metric].story}</h2><p>{company.name} در مقایسه با {comparison.name}</p></div><button type="button" onClick={onClose} aria-label="بستن نمودار مقایسه"><X size={20} /></button></header><div className="benchmark-drawer-toolbar"><label className="benchmark-compare-select"><span>مقایسه با شرکت آتیه</span><select value={comparisonName} onChange={(event) => setComparisonName(event.target.value)}>{atiehCompanies.filter((row) => row.name !== company.name || atiehCompanies.length === 1).map((row) => <option key={row.name}>{row.name}</option>)}</select><ChevronDown size={17} /></label></div><section className="benchmark-drawer-chart-only"><DrawerColumnChart metric={metric} company={company} comparison={comparison} /><div className="benchmark-drawer-legend"><span className="inspected">{company.name}</span><span className="selected">{comparison.name}</span></div></section></aside>;
}

function managerialSummary(rows: BenchmarkCompany[], target: BenchmarkCompany, metric: MainMetricKey, referenceMode: ReferenceMode) {
  const referenceRows = rows.filter((row) => row.name !== target.name);
  const reference = referenceMode === "median" ? medianMetric(referenceRows, metric) : meanMetric(referenceRows, metric);
  const value = target.metrics[metric].value;
  const rank = rankFor(rows, metric, target);
  if (value === null) return { tone: "neutral", result: target.metrics[metric].label, detail: "رتبه‌پذیر نیست" };
  const distance = reference === null ? null : value - reference;
  return {
    tone: distance === null ? "neutral" : distance > 0 ? "positive" : distance < 0 ? "negative" : "neutral",
    result: target.metrics[metric].label,
    detail: rank ? `رتبه ${rank.rank.toLocaleString("fa-IR")} از ${rank.total.toLocaleString("fa-IR")} · ${distance === null ? "مرجع ناموجود" : `${formatComputedBenchmark(Math.abs(distance), metric)} ${distance >= 0 ? "بالاتر" : "پایین‌تر"} از مرجع`}` : "رتبه ناموجود",
  };
}

export default function PerformanceBenchmark({ model:sourceModel }: { model: BenchmarkModel }) {
  const [chosenYear,setChosenYear]=useState<number|null>(null);
  const model=useMemo(()=>sourceModel.sourceRows?buildBenchmarkRows(sourceModel.sourceRows,sourceModel.fileName,chosenYear??undefined):sourceModel,[sourceModel,chosenYear]);
  const [selectedCompany, setSelectedCompany] = useState(model.atiehCompanies[0]?.name ?? "");
  const [selectionBasis, setSelectionBasis] = useState<SelectionBasis>("company");
  const [selectedNature, setSelectedNature] = useState(model.atiehCompanies[0]?.peerGroup ?? model.natures[0] ?? "");
  const [comparisonMode, setComparisonMode] = useState<ComparisonMode>("peers");
  const [referenceMode, setReferenceMode] = useState<ReferenceMode>("median");
  const [sortMode, setSortMode] = useState<SortMode>("fixed");
  const [activeCompany, setActiveCompany] = useState<string | null>(null);
  const [focusMode, setFocusMode] = useState(false);
  const [inspected, setInspected] = useState<{ company: BenchmarkCompany; metric: MainMetricKey } | null>(null);
  const [exporting, setExporting] = useState(false);
  const [presentation, setPresentation] = useState(false);
  const reportRef = useRef<HTMLDivElement>(null);
  const atiehInSelectedNature = useMemo(
    () => model.atiehCompanies.filter((company) => company.peerGroup === selectedNature),
    [model.atiehCompanies, selectedNature],
  );
  const target = selectionBasis === "nature"
    ? atiehInSelectedNature.find((company) => company.name === selectedCompany) ?? atiehInSelectedNature[0]
    : model.atiehCompanies.find((company) => company.name === selectedCompany) ?? model.atiehCompanies[0];
  const comparison = useMemo(() => {
    if (!target) return [];
    const activeNature = selectionBasis === "nature" ? selectedNature : target.peerGroup;
    const sameNature = model.companies.filter((company) => company.peerGroup === activeNature);
    if (comparisonMode === "atieh") return sameNature.filter((company) => company.position === "atieh");
    const competitors = peersFor(model, target, false);
    if (comparisonMode === "competitors") return [target, ...competitors];
    return sameNature;
  }, [comparisonMode, model, selectedNature, selectionBasis, target]);
  const fixedOrder = useMemo(() => [...comparison].sort((a, b) => {
    if (a.name === target?.name) return -1;
    if (b.name === target?.name) return 1;
    const av = a.metrics.operatingProfitGrowth.sortValue;
    const bv = b.metrics.operatingProfitGrowth.sortValue;
    if (av === null) return 1;
    if (bv === null) return -1;
    return bv - av;
  }).map((row) => row.name), [comparison, target]);

  useEffect(() => { const onFullscreen = () => setPresentation(document.fullscreenElement === reportRef.current); document.addEventListener("fullscreenchange", onFullscreen); return () => document.removeEventListener("fullscreenchange", onFullscreen); }, []);
  async function togglePresentation() { if (!reportRef.current) return; if (document.fullscreenElement) await document.exitFullscreen(); else await reportRef.current.requestFullscreen(); }
  function exportExcel() {
    const rows = model.companies.flatMap((company) => MAIN_METRICS.map((key) => ({ جایگاه: company.position === "atieh" ? "آتیه" : "رقیب", شرکت: company.name, ماهیت: company.peerGroup, شاخص: BENCHMARK_METRIC_DEFINITIONS[key].label, "مقدار محاسبه‌شده": company.metrics[key].value, وضعیت: company.metrics[key].status === "numeric" ? "" : company.metrics[key].label, واحد: BENCHMARK_METRIC_DEFINITIONS[key].unit, "مقدار دوره پایه": company.metrics[key].previous, "مقدار دوره منتخب": company.metrics[key].current })));
    const workbook = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(rows), "پایش تطبیقی"); XLSX.writeFile(workbook, "گزارش-پایش-تطبیقی-عملکرد-دوره منتخب.xlsx");
  }
  async function exportImage() { if (!reportRef.current) return; setExporting(true); try { const { toPng } = await import("html-to-image"); const dataUrl = await toPng(reportRef.current, { cacheBust: true, pixelRatio: 1.6, backgroundColor: "#f3f6fa" }); const anchor = document.createElement("a"); anchor.download = `پایش-تطبیقی-${selectedCompany}.png`; anchor.href = dataUrl; anchor.click(); } finally { setExporting(false); } }
  if (!target) return null;
  const operatingRank = rankFor(comparison, "operatingProfitGrowth", target);
  const summaries = MAIN_METRICS.map((metric) => ({ metric, ...managerialSummary(comparison, target, metric, referenceMode) }));
  const markerProps = { rows: comparison, target, referenceMode, sortMode, fixedOrder, activeCompany, onActiveCompany: setActiveCompany, focusMode, onInspect: (company: BenchmarkCompany, metric: MainMetricKey) => setInspected({ company, metric }) };
  return <div className="benchmark-page benchmark-actual-page" ref={reportRef}>
    <section className="benchmark-title-row benchmark-compact-title"><div><span className="benchmark-kicker"><Sparkles size={16} /> Performance Benchmark</span><h1>پایش تطبیقی عملکرد</h1><p>مقایسه عملکرد واقعی دوره منتخب با شرکت‌های هم‌رده</p></div><div className="benchmark-actions no-print"><button type="button" onClick={exportExcel}><FileSpreadsheet size={18} />Excel</button><button type="button" onClick={exportImage} disabled={exporting}><ImageDown size={18} />{exporting ? "در حال تهیه…" : "تصویر"}</button><button type="button" onClick={() => window.print()}><Printer size={18} />چاپ</button><button type="button" onClick={togglePresentation}>{presentation ? <Minimize2 size={18} /> : <Maximize2 size={18} />}{presentation ? "خروج" : "ارائه"}</button></div></section>
    <section className="benchmark-control-dock no-print">
      <div className="benchmark-primary-controls"><label><span>مبنای مقایسه</span><select value={selectionBasis} onChange={(event) => { const basis = event.target.value as SelectionBasis; setSelectionBasis(basis); if (basis === "company") setSelectedNature(target.peerGroup); else { const first = model.atiehCompanies.find((row) => row.peerGroup === selectedNature); if (first) setSelectedCompany(first.name); } setInspected(null); }}><option value="company">شرکت آتیه</option><option value="nature">ماهیت فعالیت</option></select><ChevronDown size={17} /></label>{selectionBasis === "company" ? <label><span>شرکت مورد بررسی</span><select value={selectedCompany} onChange={(event) => { const name = event.target.value; setSelectedCompany(name); const company = model.atiehCompanies.find((row) => row.name === name); if (company) setSelectedNature(company.peerGroup); setInspected(null); }}>{model.atiehCompanies.map((company) => <option key={company.name}>{company.name}</option>)}</select><ChevronDown size={17} /></label> : <label><span>ماهیت فعالیت</span><select value={selectedNature} onChange={(event) => { const nature = event.target.value; setSelectedNature(nature); const first = model.atiehCompanies.find((row) => row.peerGroup === nature); if (first) setSelectedCompany(first.name); setInspected(null); }}>{model.natures.map((nature) => <option key={nature}>{nature}</option>)}</select><ChevronDown size={17} /></label>}<label><span>جامعه مقایسه</span><select value={comparisonMode} onChange={(event) => setComparisonMode(event.target.value as ComparisonMode)}><option value="peers">همه هم‌ماهیت‌ها</option><option value="competitors">شرکت منتخب و رقبا</option><option value="atieh">فقط شرکت‌های آتیه</option></select><ChevronDown size={17} /></label><button type="button" className={`benchmark-focus-toggle ${focusMode ? "active" : ""}`} onClick={() => setFocusMode((value) => !value)}><Eye size={17} />تمرکز بر منتخب</button></div>
      <details className="benchmark-advanced-controls"><summary><SlidersHorizontal size={17} />تنظیمات نمودار</summary><div><label><span>مرجع آماری</span><select value={referenceMode} onChange={(event) => setReferenceMode(event.target.value as ReferenceMode)}><option value="median">میانه سایر هم‌رده‌ها</option><option value="average">میانگین سایر هم‌رده‌ها</option></select><ChevronDown size={17} /></label><label><span>ترتیب شرکت‌ها</span><select value={sortMode} onChange={(event) => setSortMode(event.target.value as SortMode)}><option value="fixed">ترتیب ثابت در همه نمودارها</option><option value="descending">رتبه‌بندی نزولی هر شاخص</option><option value="ascending">رتبه‌بندی صعودی هر شاخص</option><option value="alphabetical">ترتیب الفبایی</option></select><ChevronDown size={17} /></label><button type="button" className="benchmark-reset" onClick={() => { const first = model.atiehCompanies[0]; setSelectionBasis("company"); setSelectedCompany(first?.name ?? ""); setSelectedNature(first?.peerGroup ?? model.natures[0] ?? ""); setComparisonMode("peers"); setReferenceMode("median"); setSortMode("fixed"); setFocusMode(false); setActiveCompany(null); setInspected(null); }}><RotateCcw size={17} />بازنشانی</button></div></details>
    </section>
    {model.warnings.length > 0 && <div className="benchmark-note"><Info size={18} /><span>{model.warnings.join(" · ")}</span></div>}
    <div className="workspace-tools no-print"><label>دوره مقایسه: <select value={model.currentYear??model.years.at(-1)} onChange={e=>setChosenYear(Number(e.target.value))}>{model.years.map(y=><option key={y} value={y}>{y.toLocaleString("fa-IR",{useGrouping:false})}</option>)}</select></label><span>پایه: {model.previousYear?.toLocaleString("fa-IR",{useGrouping:false})} ← منتخب: {model.currentYear?.toLocaleString("fa-IR",{useGrouping:false})}</span></div><section className="benchmark-context-bar"><div><strong>{target.name}</strong><span>{target.peerGroup}</span><span>{comparison.length.toLocaleString("fa-IR")} شرکت در مقایسه</span><span>دوره دوره منتخب/دوره پایه</span></div><div className="benchmark-context-side"><p>رتبه رشد سود عملیاتی: <b>{operatingRank ? `${operatingRank.rank.toLocaleString("fa-IR")} از ${operatingRank.total.toLocaleString("fa-IR")}` : "داده ناکافی"}</b></p><div className="benchmark-legend" aria-label="راهنمای نمودار"><span className="target">منتخب</span><span className="atieh">سایر آتیه</span><span className="competitor">رقبا</span></div></div></section>
    <section className="benchmark-managerial-strip" aria-label="جمع‌بندی مدیریتی">{summaries.map(({ metric, tone, result, detail }) => <a key={metric} href={`#benchmark-${metric}`} className={tone}><span>{METRIC_TITLES[metric].fa}</span><strong>{result}</strong><small>{detail}</small></a>)}</section>
    <nav className="benchmark-jump-nav no-print" aria-label="دسترسی سریع به نمودارها"><BarChart3 size={16} />{MAIN_METRICS.map((metric) => <a key={metric} href={`#benchmark-${metric}`}>{METRIC_TITLES[metric].story}</a>)}</nav>
    <section className={`benchmark-analysis-stage ${inspected ? "has-detail" : ""}`}><div className="benchmark-chart-grid">{MAIN_METRICS.map((metric, index) => <div key={metric} id={`benchmark-${metric}`} className={`benchmark-chart-slot ${index === 0 ? "operating" : ""}`}><MarkerPlot metric={metric} {...markerProps} priority={index === 0} /></div>)}</div>{inspected && <DetailDrawer key={`${inspected.company.name}-${inspected.metric}-${target.name}`} company={inspected.company} metric={inspected.metric} target={target} atiehCompanies={model.atiehCompanies} onClose={() => setInspected(null)} />}</section>
    <details className="benchmark-general-help no-print"><summary><Info size={17} />راهنمای خواندن نمودار</summary><div><p><Check size={16} />رشدها از مقادیر واقعی دوره پایه و دوره منتخب محاسبه شده‌اند؛ تغییر حاشیه سود عملیاتی و حاشیه جریان نقد عملیاتی برحسب واحد درصد است.</p><p><Check size={16} />نوار سبز کم‌رنگ، فاصله چارک اول تا سوم سایر هم‌رده‌ها را نشان می‌دهد. خط مرجع نیز شرکت منتخب را از محاسبه کنار می‌گذارد.</p><p><Check size={16} />با قرارگرفتن روی یک شرکت، همان شرکت در هر پنج نمودار برجسته می‌شود. برای مقایسه ارقام واقعی روی دایره کلیک کنید.</p><small>{model.summary.companies.toLocaleString("fa-IR")} شرکت · پوشش داده {Math.round(model.summary.completeness * 100).toLocaleString("fa-IR")}٪</small></div></details>
  </div>;
}
