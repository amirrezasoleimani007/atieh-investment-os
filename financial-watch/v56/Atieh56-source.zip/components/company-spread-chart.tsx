"use client";

import { useMemo } from "react";
import { ChartNoAxesCombined } from "lucide-react";
import type { FinancialModel } from "@/lib/financial-engine";
import type { ProfitModel } from "@/lib/profit-engine";
import type { ProductionModel } from "@/lib/investment-engine";
import type { HoldingKey } from "@/lib/company-resolver";
import { buildCompanySpreadRanking } from "@/lib/value-creation-engine";

const number = (value: number, signed = false) => new Intl.NumberFormat("fa-IR", {
  maximumFractionDigits: 1,
  minimumFractionDigits: 1,
  signDisplay: signed ? "exceptZero" : "auto",
}).format(value);

// Chart contract: all companies in one holding, one exact year, ROIC − WACC in pp.
// Horizontal diverging bars, descending top-to-bottom; fixed zero, signed labels,
// blue/orange marks, unranked missing rows. Uses the dashboard's native SVG stack.
export default function CompanySpreadChart({ financialModel, profitModel, productionModel, holding, year, basis, selectedCompany }: {
  financialModel: FinancialModel;
  profitModel: ProfitModel | null;
  productionModel: ProductionModel | null;
  holding: HoldingKey;
  year: number;
  basis: "actual" | "budget";
  selectedCompany: string;
}) {
  const rows = useMemo(() => buildCompanySpreadRanking(financialModel, profitModel, productionModel, holding, year, basis),
    [financialModel, profitModel, productionModel, holding, year, basis]);
  const valid = rows.filter((row) => row.spread !== null);
  const missing = rows.filter((row) => row.spread === null);
  const max = Math.max(0.01, ...valid.map((row) => Math.abs(row.spread!))) * 1.12;
  const ticks = [-max, -max / 2, 0, max / 2, max];
  return (
    <section className="vc-spread-chart" aria-label="مقایسه اسپرد همه شرکت‌ها">
      <header className="vc-spread-heading">
        <div className="vc-spread-title">
          <ChartNoAxesCombined size={24} aria-hidden="true" />
          <div>
            <h2>مقایسه اسپرد شرکت‌های {holding === "atieh" ? "آتیه" : "متیل"}</h2>
            <p>{year.toLocaleString("fa-IR", { useGrouping: false })} · {basis === "budget" ? "بودجه پایه، بدون اعمال سناریو" : "عملکرد واقعی"} · بازده سرمایه منهای هزینه سرمایه (ROIC − WACC)</p>
          </div>
        </div>
        <span className="vc-spread-order">از بیشترین به کمترین ↓</span>
      </header>
      <div className="vc-spread-caption">
        <span>واحد: واحد درصد · خط صفر: مرز ارزش‌آفرینی</span>
        <span>{valid.length.toLocaleString("fa-IR")} از {rows.length.toLocaleString("fa-IR")} شرکت دارای داده معتبر</span>
      </div>
      {valid.length ? <>
        <div className="vc-spread-axis" aria-hidden="true">
          <span>اسپرد</span>
          <div>{ticks.map((tick, index) => <span key={index} style={{ left: `${index * 25}%` }}>{number(tick * 100)}</span>)}</div>
          <span>شرکت · ترتیب نزولی</span>
        </div>
        <ol className="vc-spread-rows">
          {valid.map((row, index) => {
            const spread = row.spread!;
            const end = 50 + spread / max * 50;
            const selected = row.company === selectedCompany;
            return <li key={row.company} className={`${spread < 0 ? "negative" : "positive"}${selected ? " selected" : ""}`}>
              <strong className="vc-spread-value"><bdi dir="ltr">{number(spread * 100, true)}</bdi></strong>
              <svg className="vc-spread-plot" width="100%" height="38" aria-hidden="true">
                {[0, 25, 50, 75, 100].map((x) => <line key={x} x1={`${x}%`} x2={`${x}%`} y1="0" y2="38" className={x === 50 ? "zero" : "grid"} />)}
                <rect x={`${Math.min(50, end)}%`} y="9" width={`${Math.abs(end - 50)}%`} height="20" rx="5" />
                <circle cx={`${end}%`} cy="19" r="3.5" />
              </svg>
              <div className="vc-spread-company" dir="rtl">
                <span className="vc-spread-rank">{(index + 1).toLocaleString("fa-IR")}</span>
                <div><strong>{row.company}</strong>{selected && <small>شرکت انتخاب‌شده</small>}</div>
              </div>
              <div className="vc-spread-detail" dir="rtl">بازده سرمایه: <bdi>{number(row.roic! * 100)}٪</bdi> · هزینه سرمایه: <bdi>{number(row.wacc! * 100)}٪</bdi></div>
            </li>;
          })}
        </ol>
      </> : <p className="vc-spread-empty">برای این دوره داده معتبر اسپرد موجود نیست.</p>}
      {missing.length > 0 && <div className="vc-spread-missing">
        <strong>فاقد داده معتبر در دوره انتخاب‌شده ({missing.length.toLocaleString("fa-IR")} شرکت)</strong>
        <p>{missing.map((row) => row.company).join("، ")}</p>
        <small>این شرکت‌ها رتبه‌بندی نشده‌اند؛ داده سال دیگر یا مقدار صفر جایگزین نشده است.</small>
      </div>}
    </section>
  );
}
