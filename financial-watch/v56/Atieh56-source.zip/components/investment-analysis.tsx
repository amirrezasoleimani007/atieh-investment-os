"use client";

import { useEffect, useMemo, useState } from "react";
import {useScenarioState} from '@/lib/use-scenario-state';
import * as XLSX from "xlsx";
import {
  Activity,
  AlertTriangle,
  ArrowLeft,
  ArrowRight,
  BarChart3,
  Boxes,
  Building2,
  Check,
  ChevronDown,
  CircleGauge,
  Download,
  Factory,
  HeartPulse,
  Layers3,
  ListTree,
  Package,
  PieChart,
  RotateCcw,
  Search,
  SlidersHorizontal,
  Sparkles,
  Target,
  TrendingUp,
  Wrench,
  X,
} from "lucide-react";
import {
  DEFAULT_INVESTMENT_WEIGHTS,
  INVESTMENT_COMPONENTS,
  buildInvestmentPoints,
  investmentWeightTotal,
  type InvestmentPoint,
  type InvestmentWeights,
  type ProductionModel,
} from "@/lib/investment-engine";
import {
  activityForCompany,
  assetsForCompany,
  canonicalCompanyKey,
  equipmentForCompany,
  type AssetModel,
  type AssetRecord,
  type EquipmentModel,
  type EquipmentRecord,
  type InvestmentHolding,
  type MetilActivityModel,
  type MetilActivityRecord,
} from "@/lib/investment-data-engine";
import type { FinancialModel } from "@/lib/financial-engine";
import type { ProfitModel } from "@/lib/profit-engine";
import ValueCreationEngine from "@/components/value-creation-engine";
import PortfolioPulseView from "@/components/portfolio-pulse";
import {
  buildScenarioAssetComposition,
  type PlanningScenarioSnapshot,
} from "@/lib/planning-scenario-engine";

type Scope = "production" | "other";
type DetailTab =
  "operations" | "capital" | "assets" | "activity" | "equipment" | "method";
const palette = [
  "#0f8a78",
  "#2563eb",
  "#8b5cf6",
  "#e59b18",
  "#df5c74",
  "#0891b2",
  "#75a63e",
  "#e56b2f",
  "#64748b",
];
const assetPalette = [
  "#0f8a78",
  "#2563eb",
  "#d69a1e",
  "#8b5cf6",
  "#dd6b4d",
  "#64748b",
];
const investmentPalette = ["#0f8a78", "#2563eb", "#d69a1e", "#8b5cf6"];

function faNumber(value: number | null, digits = 1) {
  if (value === null || !Number.isFinite(value)) return "—";
  return new Intl.NumberFormat("fa-IR", {
    maximumFractionDigits: digits,
    minimumFractionDigits: digits,
  }).format(value);
}
function faInteger(value: number | null) {
  if (value === null || !Number.isFinite(value)) return "—";
  return new Intl.NumberFormat("fa-IR", { maximumFractionDigits: 0 }).format(
    value,
  );
}
function percent(value: number | null, digits = 1) {
  return value === null ? "—" : `${faNumber(value * 100, digits)}٪`;
}
function millionRial(value: number | null) {
  if (value === null || !Number.isFinite(value)) return "—";
  return new Intl.NumberFormat("fa-IR", { maximumFractionDigits: 0 }).format(
    value / 1_000_000,
  );
}
function pointColor(company: string, companies: string[]) {
  return palette[Math.max(0, companies.indexOf(company)) % palette.length];
}
function scoreBand(score: number) {
  if (score >= 0.7) return { label: "اثر‌بخشی بالا", className: "good" };
  if (score >= 0.4) return { label: "اثر‌بخشی متوسط", className: "mid" };
  return { label: "نیازمند اقدام", className: "weak" };
}

function adjustInvestmentWeight(
  weights: InvestmentWeights,
  key: keyof InvestmentWeights,
  percentValue: number,
) {
  const targetPercent = Math.round(Math.max(0, Math.min(100, percentValue)));
  const keys = INVESTMENT_COMPONENTS.map((item) => item.key);
  const otherKeys = keys.filter((item) => item !== key);
  const otherTotal = otherKeys.reduce((sum, item) => sum + weights[item], 0);
  const remainderPercent = 100 - targetPercent;
  const rawShares = otherKeys.map((otherKey) => ({
    key: otherKey,
    raw:
      otherTotal > 0
        ? (weights[otherKey] / otherTotal) * remainderPercent
        : remainderPercent / otherKeys.length,
  }));
  const integerShares = rawShares.map((share) => ({
    ...share,
    value: Math.floor(share.raw),
  }));
  let unitsLeft =
    remainderPercent -
    integerShares.reduce((sum, share) => sum + share.value, 0);
  integerShares.sort((a, b) => b.raw - b.value - (a.raw - a.value));
  for (
    let index = 0;
    index < integerShares.length && unitsLeft > 0;
    index += 1, unitsLeft -= 1
  )
    integerShares[index].value += 1;
  const next = { ...weights, [key]: targetPercent / 100 };
  for (const share of integerShares) next[share.key] = share.value / 100;
  return next;
}

function WeightEditor({
  weights,
  onChange,
}: {
  weights: InvestmentWeights;
  onChange: (weights: InvestmentWeights) => void;
}) {
  const total = investmentWeightTotal(weights);
  const cumulative = INVESTMENT_COMPONENTS.map((_, index) =>
    INVESTMENT_COMPONENTS.slice(0, index + 1).reduce(
      (sum, item) => sum + weights[item.key],
      0,
    ),
  );
  const segments = INVESTMENT_COMPONENTS.map(
    (_, index) =>
      `${investmentPalette[index]} ${(cumulative[index - 1] ?? 0) * 360}deg ${cumulative[index] * 360}deg`,
  ).join(", ");
  return (
    <section className="investment-weight-card iv-weight-editor">
      <header>
        <div>
          <SlidersHorizontal size={20} />
          <span>
            <strong>ترکیب امتیاز اثربخشی سرمایه</strong>
            <small>
              با تغییر هر وزن، باقیمانده بین سه مؤلفه دیگر توزیع می‌شود.
            </small>
          </span>
        </div>
        <div className="iv-weight-presets">
          <button
            type="button"
            onClick={() =>
              onChange({
                spread: 0.25,
                roic: 0.25,
                fcfMargin: 0.25,
                revenueGrowth: 0.25,
              })
            }
          >
            برابر
          </button>
          <button
            type="button"
            onClick={() => onChange({ ...DEFAULT_INVESTMENT_WEIGHTS })}
          >
            <RotateCcw size={14} />
            پیش‌فرض
          </button>
        </div>
      </header>
      <div className="iv-weight-overview">
        <div
          className="iv-weight-donut"
          style={{ background: `conic-gradient(${segments})` }}
        >
          <span>
            <strong>{percent(total, 0)}</strong>
            <small>مجموع وزن</small>
          </span>
        </div>
        <div>
          {INVESTMENT_COMPONENTS.map((item, index) => (
            <span key={item.key}>
              <i style={{ background: investmentPalette[index] }} />
              <b>{item.shortLabel}</b>
              <strong>{percent(weights[item.key], 0)}</strong>
            </span>
          ))}
        </div>
      </div>
      <div className="investment-weight-list">
        {INVESTMENT_COMPONENTS.map((item, index) => {
          const value = Math.round(weights[item.key] * 100);
          return (
            <label
              key={item.key}
              style={
                {
                  "--iv-weight-color": investmentPalette[index],
                } as React.CSSProperties
              }
            >
              <span>
                <i>{index + 1}</i>
                <b>{item.shortLabel}</b>
                <small>
                  کد{" "}
                  {Number(item.code).toLocaleString("fa-IR", {
                    useGrouping: false,
                  })}
                </small>
              </span>
              <input
                type="range"
                min="0"
                max="100"
                step="1"
                value={value}
                onChange={(event) =>
                  onChange(
                    adjustInvestmentWeight(
                      weights,
                      item.key,
                      Number(event.target.value),
                    ),
                  )
                }
                style={{ "--weight-fill": `${value}%` } as React.CSSProperties}
              />
              <div className="iv-weight-number">
                <input
                  aria-label={`وزن ${item.shortLabel}`}
                  type="number"
                  min="0"
                  max="100"
                  value={value}
                  onChange={(event) =>
                    onChange(
                      adjustInvestmentWeight(
                        weights,
                        item.key,
                        Number(event.target.value),
                      ),
                    )
                  }
                />
                <b>٪</b>
              </div>
            </label>
          );
        })}
      </div>
      <footer>
        <Check size={16} />
        <span>
          مجموع وزن‌ها همواره دقیقاً ۱۰۰٪ است و عدد کنار هر اسلایدر همان وزن
          مؤثر در محاسبه خواهد بود.
        </span>
      </footer>
    </section>
  );
}

function InvestmentScatter({
  points,
  companies,
  selectedCompany,
  hoveredCompany,
  onHover,
  onSelect,
  verticalTitle,
}: {
  points: InvestmentPoint[];
  companies: string[];
  selectedCompany: string;
  hoveredCompany: string;
  onHover: (company: string) => void;
  onSelect: (point: InvestmentPoint) => void;
  verticalTitle: string;
}) {
  const width = 1160,
    height = 670,
    pad = { top: 58, right: 58, bottom: 92, left: 96 };
  const innerW = width - pad.left - pad.right,
    innerH = height - pad.top - pad.bottom;
  const xScale = (value: number) =>
    pad.left + Math.max(0, Math.min(1, value)) * innerW;
  const yScale = (value: number) =>
    pad.top + (1 - Math.max(0, Math.min(1, value))) * innerH;
  const series = companies
    .map((company) => ({
      company,
      points: points
        .filter((point) => point.company === company)
        .sort((a, b) => a.year - b.year),
    }))
    .filter((item) => item.points.length);
  const curve = (a: InvestmentPoint, b: InvestmentPoint) => {
    const x1 = xScale(a.x),
      y1 = yScale(a.y),
      x2 = xScale(b.x),
      y2 = yScale(b.y);
    const bend = Math.max(24, Math.abs(x2 - x1) * 0.38);
    return `M ${x1} ${y1} C ${x1 + (x2 >= x1 ? bend : -bend)} ${y1}, ${x2 - (x2 >= x1 ? bend : -bend)} ${y2}, ${x2} ${y2}`;
  };
  const assetMode = points.some(
    (point) => point.verticalMetric === "asset-productivity",
  );
  return (
    <div className="investment-scatter-wrap">
      {!points.length ? (
        <div className="investment-empty">
          <AlertTriangle size={30} />
          <strong>نقطه قابل محاسبه وجود ندارد</strong>
          <span>
            چهار امتیاز محور سرمایه و امتیاز معتبر کد ۱۵۲ (یا داده بهره‌برداری
            تولید) باید موجود باشد.
          </span>
        </div>
      ) : (
        <svg
          className="investment-scatter"
          viewBox={`0 0 ${width} ${height}`}
          role="img"
          aria-label={`نمودار امتیاز اثربخشی سرمایه در برابر ${verticalTitle}`}
        >
          <defs>
            <filter
              id="iv22-shadow"
              x="-70%"
              y="-70%"
              width="240%"
              height="240%"
            >
              <feDropShadow
                dx="0"
                dy="6"
                stdDeviation="7"
                floodColor="#102f3d"
                floodOpacity="0.22"
              />
            </filter>
            {series.flatMap((item, index) => [
              <marker
                key={`${item.company}-active`}
                id={`iv22-arrow-${index}`}
                markerWidth="18"
                markerHeight="18"
                refX="14"
                refY="9"
                orient="auto"
                markerUnits="userSpaceOnUse"
              >
                <path
                  d="M1,1 L17,9 L1,17 L5.5,9 Z"
                  fill={pointColor(item.company, companies)}
                  stroke="#fff"
                  strokeWidth="1.5"
                />
              </marker>,
              <marker
                key={`${item.company}-muted`}
                id={`iv22-arrow-muted-${index}`}
                markerWidth="14"
                markerHeight="14"
                refX="11"
                refY="7"
                orient="auto"
                markerUnits="userSpaceOnUse"
              >
                <path
                  d="M1,1 L13,7 L1,13 L4.5,7 Z"
                  fill={pointColor(item.company, companies)}
                  fillOpacity=".42"
                  stroke="#fff"
                  strokeWidth="1.2"
                />
              </marker>,
            ])}
          </defs>
          <rect
            x={pad.left}
            y={pad.top}
            width={innerW / 2}
            height={innerH / 2}
            className="quadrant q-neutral"
          />
          <rect
            x={pad.left + innerW / 2}
            y={pad.top}
            width={innerW / 2}
            height={innerH / 2}
            className="quadrant q-good"
          />
          <rect
            x={pad.left}
            y={pad.top + innerH / 2}
            width={innerW / 2}
            height={innerH / 2}
            className="quadrant q-watch"
          />
          <rect
            x={pad.left + innerW / 2}
            y={pad.top + innerH / 2}
            width={innerW / 2}
            height={innerH / 2}
            className="quadrant q-potential"
          />
          {[0, 0.25, 0.5, 0.75, 1].map((tick) => (
            <g key={`y-${tick}`}>
              <line
                x1={pad.left}
                x2={width - pad.right}
                y1={yScale(tick)}
                y2={yScale(tick)}
                className="investment-grid-line"
              />
              <text
                x={pad.left - 19}
                y={yScale(tick) + 5}
                textAnchor="end"
                className="investment-tick"
              >
                {faNumber(tick, 2)}
              </text>
            </g>
          ))}
          {[0, 0.25, 0.5, 0.75, 1].map((tick) => (
            <g key={`x-${tick}`}>
              <line
                x1={xScale(tick)}
                x2={xScale(tick)}
                y1={pad.top}
                y2={height - pad.bottom}
                className="investment-grid-line vertical"
              />
              <text
                x={xScale(tick)}
                y={height - pad.bottom + 35}
                textAnchor="middle"
                className="investment-tick"
              >
                {faNumber(tick, 2)}
              </text>
            </g>
          ))}
          <line
            x1={xScale(0.5)}
            x2={xScale(0.5)}
            y1={pad.top}
            y2={height - pad.bottom}
            className="investment-midline"
          />
          <line
            x1={pad.left}
            x2={width - pad.right}
            y1={yScale(0.5)}
            y2={yScale(0.5)}
            className="investment-midline"
          />
          <text x={pad.left + 20} y={pad.top + 30} className="quadrant-label">
            {assetMode
              ? "گردش بالا، ارزش‌آفرینی ضعیف"
              : "عملیات قوی · سرمایه کم‌اثر"}
          </text>
          <text
            x={width - pad.right - 20}
            y={pad.top + 30}
            textAnchor="end"
            className="quadrant-label good"
          >
            {assetMode ? "مقیاس کارآمد و ارزش‌آفرین" : "ناحیه ممتاز"}
          </text>
          <text
            x={pad.left + 20}
            y={height - pad.bottom - 22}
            className="quadrant-label watch"
          >
            {assetMode ? "بازسازی مدل عملیاتی" : "نیازمند بازنگری"}
          </text>
          <text
            x={width - pad.right - 20}
            y={height - pad.bottom - 22}
            textAnchor="end"
            className="quadrant-label potential"
          >
            {assetMode ? "ظرفیت رشد" : "پتانسیل سرمایه · ضعف عملیات"}
          </text>
          {series.flatMap((item) =>
            item.points.slice(1).map((point, index) => {
              const previous = item.points[index],
                active =
                  item.company === selectedCompany ||
                  item.company === hoveredCompany,
                color = pointColor(item.company, companies),
                markerIndex = series.findIndex(
                  (entry) => entry.company === item.company,
                ),
                path = curve(previous, point);
              return (
                <g
                  key={`${item.company}-${previous.year}-${point.year}`}
                  className={active ? "active-flow" : ""}
                >
                  {active && (
                    <path
                      d={path}
                      fill="none"
                      stroke={color}
                      strokeWidth="13"
                      strokeOpacity=".09"
                    />
                  )}
                  <path
                    d={path}
                    fill="none"
                    stroke={color}
                    strokeWidth={active ? 5.2 : 2.3}
                    strokeOpacity={active ? 1 : 0.28}
                    strokeDasharray={point.isForecast ? "12 10" : undefined}
                    markerEnd={`url(#iv22-arrow${active ? "" : "-muted"}-${markerIndex})`}
                    className={
                      point.isForecast ? "forecast-path" : "actual-path"
                    }
                  />
                  {active && !point.isForecast && (
                    <circle
                      r="5"
                      fill={color}
                      stroke="#fff"
                      strokeWidth="1.6"
                      className="flow-particle"
                    >
                      <animateMotion
                        dur="2.1s"
                        repeatCount="indefinite"
                        path={path}
                      />
                    </circle>
                  )}
                </g>
              );
            }),
          )}
          {series.flatMap((item) =>
            item.points.map((point) => {
              const active =
                  item.company === selectedCompany ||
                  item.company === hoveredCompany,
                color = pointColor(item.company, companies),
                cx = xScale(point.x),
                cy = yScale(point.y);
              return (
                <g
                  key={point.id}
                  className={`investment-point ${active ? "active" : ""} ${point.isForecast ? "forecast" : ""} ${point.pointType}`}
                  role="button"
                  tabIndex={0}
                  onMouseEnter={() => onHover(item.company)}
                  onMouseLeave={() => onHover("")}
                  onFocus={() => onHover(item.company)}
                  onBlur={() => onHover("")}
                  onClick={() => onSelect(point)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter" || event.key === " ")
                      onSelect(point);
                  }}
                >
                  {active && (
                    <circle
                      cx={cx}
                      cy={cy}
                      r="28"
                      fill={color}
                      opacity=".12"
                      className={
                        point.isForecast ? "forecast-halo" : "investment-pulse"
                      }
                    />
                  )}
                  <circle
                    className="point-shell"
                    cx={cx}
                    cy={cy}
                    r={active ? 15 : 10.5}
                    fill={
                      point.pointType === "optimized"
                        ? "#f59e0b"
                        : point.isForecast
                          ? "#fff"
                          : color
                    }
                    stroke="#fff"
                    strokeWidth={active ? 5 : 3.5}
                    filter={active ? "url(#iv22-shadow)" : undefined}
                  />
                  <circle
                    className="point-core"
                    cx={cx}
                    cy={cy}
                    r={active ? 6 : 4.5}
                    fill={point.isForecast ? "#fff" : color}
                    stroke={point.isForecast ? color : "#fff"}
                    strokeWidth={point.isForecast ? 3 : 1.5}
                  />
                  <text
                    x={cx}
                    y={cy - (active ? 21 : 16)}
                    textAnchor="middle"
                    className={`point-year ${active ? "active" : ""}`}
                  >
                    {point.year.toLocaleString("fa-IR", { useGrouping: false })}
                  </text>
                  {active && (
                    <g className="point-tooltip">
                      <rect
                        x={cx - 105}
                        y={cy + 22}
                        width="210"
                        height="52"
                        rx="13"
                      />
                      <text x={cx} y={cy + 43} textAnchor="middle">
                        {item.company}
                      </text>
                      <text x={cx} y={cy + 62} textAnchor="middle">
                        سرمایه {faNumber(point.x, 2)} · {point.verticalLabel}{" "}
                        {faNumber(point.y, 2)}
                      </text>
                    </g>
                  )}
                </g>
              );
            }),
          )}
          <text
            x={pad.left + innerW / 2}
            y={height - 19}
            textAnchor="middle"
            className="investment-axis-title"
          >
            امتیاز اثربخشی سرمایه · صفر تا یک
          </text>
          <text
            transform={`translate(24 ${pad.top + innerH / 2}) rotate(-90)`}
            textAnchor="middle"
            className="investment-axis-title"
          >
            {verticalTitle} · صفر تا یک
          </text>
        </svg>
      )}
    </div>
  );
}

function AssetProductivitySection({ point }: { point: InvestmentPoint }) {
  const data = point.assetProductivity;
  if (!data)
    return (
      <div className="iv-unavailable">
        <AlertTriangle size={30} />
        <strong>داده بهره‌وری دارایی در دسترس نیست</strong>
        <span>امتیاز معتبر کد ۱۵۲ برای ساخت این نما الزامی است.</span>
      </div>
    );
  return (
    <section className="iv-financial-assets">
      <div className="iv-data-kpis iv-productivity-kpis">
        <article>
          <small>گردش دارایی</small>
          <strong>
            {faNumber(data.storedTurnover ?? data.rawTurnover, 2)}
          </strong>
          <span>برابر</span>
        </article>
        <article>
          <small>امتیاز بهره‌وری</small>
          <strong>{faNumber(data.turnoverScore, 2)}</strong>
          <span>از ۱۰</span>
        </article>
        <article>
          <small>متوسط کل دارایی</small>
          <strong>{faInteger(data.averageTotalAssets)}</strong>
          <span>میلیون ریال</span>
        </article>
        <article>
          <small>درآمد عملیاتی</small>
          <strong>{faInteger(data.revenue)}</strong>
          <span>میلیون ریال</span>
        </article>
      </div>
      <div className="iv-productivity-formula">
        <CircleGauge size={18} />
        <span>
          <strong>درآمد ÷ متوسط کل دارایی</strong>
          <small>
            {faInteger(data.revenue)} ÷ {faInteger(data.averageTotalAssets)} ={" "}
            {faNumber(data.rawTurnover, 4)} برابر
          </small>
        </span>
      </div>
      {point.isForecast ? (
        <div className="iv-period-assets scenario-assets">
          <article>
            <small>کل دارایی سناریوی ۱۴۰۵</small>
            <strong>{faInteger(data.averageTotalAssets)}</strong>
            <span>جمع برنامه برآوردی اجزای دارایی</span>
          </article>
          <article>
            <small>درآمد دوره بودجه منتخب</small>
            <strong>{faInteger(data.revenue)}</strong>
            <span>ردیف جمع Profit</span>
          </article>
          <article>
            <small>گردش دارایی سناریو</small>
            <strong>{faNumber(data.rawTurnover, 2)}</strong>
            <span>درآمد ÷ جمع اجزای دارایی</span>
          </article>
        </div>
      ) : (
        <div className="iv-period-assets">
          <article>
            <small>کل دارایی ابتدای دوره</small>
            <strong>{faInteger(data.totalAssetsBeginning)}</strong>
            <span>
              سال{" "}
              {(point.year - 1).toLocaleString("fa-IR", { useGrouping: false })}
            </span>
          </article>
          <article>
            <small>کل دارایی انتهای دوره</small>
            <strong>{faInteger(data.totalAssetsEnding)}</strong>
            <span>
              سال {point.year.toLocaleString("fa-IR", { useGrouping: false })}
            </span>
          </article>
          <article>
            <small>متوسط کل دارایی طی دوره</small>
            <strong>{faInteger(data.averageTotalAssets)}</strong>
            <span>(ابتدا + انتها) ÷ ۲</span>
          </article>
        </div>
      )}
      <article className="iv-average-assets-card">
        <header>
          <div>
            <Layers3 size={19} />
            <span>
              <strong>
                {point.isForecast
                  ? "ترکیب دارایی سناریوی ۱۴۰۵"
                  : "ساختار متوسط دارایی‌های مالی"}
              </strong>
              <small>
                {point.isForecast
                  ? "جمع برنامه برآوردی اجزای دارایی؛ نه میانگین ابتدا و انتهای دوره"
                  : "ترکیب متوسط دارایی‌های درگیر طی سال"}{" "}
                · مبالغ به میلیون ریال
              </small>
            </span>
          </div>
          <b className={data.reconciliationOk ? "ok" : "warning"}>
            {data.reconciliationOk ? "تطبیق کامل" : "نیازمند بررسی"}
          </b>
        </header>
        {data.averageTotalAssets === null ? (
          <div className="iv-unavailable compact">
            <AlertTriangle size={24} />
            <span>
              به‌دلیل نبود کل دارایی ابتدا یا انتهای دوره، ترکیب متوسط قابل
              محاسبه نیست.
            </span>
          </div>
        ) : (
          <>
            <div
              className="iv-stacked-assets"
              aria-label="نمودار ترکیب متوسط دارایی‌ها"
            >
              {data.assetComposition.map((item) =>
                item.amount !== null && (item.share ?? 0) > 0 ? (
                  <i
                    key={item.key}
                    title={`${item.label}: ${faInteger(item.amount)} میلیون ریال · ${percent(item.share)}`}
                    style={{
                      width: `${(item.share ?? 0) * 100}%`,
                      background: item.color,
                    }}
                  />
                ) : null,
              )}
            </div>
            <div className="iv-average-assets-legend">
              {data.assetComposition.map((item) => (
                <div
                  key={item.key}
                  title={
                    item.key === "other"
                      ? "شامل سایر اقلام دارایی و اقلامی است که تفکیک کامل آنها در دیتابیس موجود نیست."
                      : item.complete
                        ? "متوسط ابتدا و انتهای دوره"
                        : "تفکیک این قلم کامل نیست و مبلغ آن در سایر دارایی‌ها باقی مانده است."
                  }
                >
                  <i style={{ background: item.color }} />
                  <span>
                    <strong>{item.label}</strong>
                    <small>
                      {item.complete || item.key === "other"
                        ? faInteger(item.amount)
                        : "داده ناقص"}
                    </small>
                  </span>
                  <b>
                    {item.complete || item.key === "other"
                      ? percent(item.share)
                      : "—"}
                  </b>
                </div>
              ))}
            </div>
            <footer>
              <span>پوشش تفکیک اقلام: {percent(data.dataCoverage, 0)}</span>
              <span>
                اختلاف تطبیق: {faNumber(data.reconciliationDifference, 2)}{" "}
                میلیون ریال
              </span>
            </footer>
          </>
        )}
      </article>
      <article className="iv-working-capital-drivers">
        <header>
          <Activity size={19} />
          <span>
            <strong>محرک‌های سرمایه در گردش</strong>
            <small>شاخص‌های تشخیصی؛ بدون وزن در محور بهره‌وری دارایی‌ها</small>
          </span>
        </header>
        <div>
          {data.workingCapitalDrivers.map((driver) => (
            <span key={driver.code}>
              <small>
                {driver.key.toUpperCase()} · کد{" "}
                {Number(driver.code).toLocaleString("fa-IR", {
                  useGrouping: false,
                })}
              </small>
              <strong>{faNumber(driver.rawValue, 1)}</strong>
              <b>روز</b>
            </span>
          ))}
        </div>
      </article>
    </section>
  );
}

function AssetSection({
  records,
  hasFile,
  scopeNote,
}: {
  records: AssetRecord[];
  hasFile: boolean;
  scopeNote?: string;
}) {
  const [measure, setMeasure] = useState<"book" | "cost">("book");
  const [selectedClass, setSelectedClass] = useState("all");
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const pageSize = 50;
  const summary = useMemo(() => {
    const byClass = new Map<
      string,
      { label: string; cost: number; book: number; count: number }
    >();
    for (const record of records) {
      const current = byClass.get(record.assetClass) ?? {
        label: record.assetClass,
        cost: 0,
        book: 0,
        count: 0,
      };
      current.cost += record.costRial ?? 0;
      current.book += record.bookValueRial ?? 0;
      current.count++;
      byClass.set(record.assetClass, current);
    }
    const classes = [...byClass.values()].sort((a, b) =>
      measure === "book" ? b.book - a.book : b.cost - a.cost,
    );
    return {
      classes,
      cost: classes.reduce((sum, item) => sum + item.cost, 0),
      book: classes.reduce((sum, item) => sum + item.book, 0),
      count: records.length,
    };
  }, [measure, records]);
  if (!hasFile)
    return (
      <div className="iv-unavailable">
        <Boxes size={30} />
        <strong>فایل دارایی‌های تجمیع‌شده بارگذاری نشده است</strong>
        <span>
          فایل را از صفحه نخست اضافه کنید تا ترکیب تجهیزات این شرکت نمایش داده
          شود.
        </span>
      </div>
    );
  if (!records.length)
    return (
      <div className="iv-unavailable">
        <AlertTriangle size={30} />
        <strong>دارایی متناظر برای این شرکت پیدا نشد</strong>
        <span>
          نام شرکت در دو فایل با نگاشت کنترل‌شده تطبیق داده شد؛ مقدار صفر فرض
          نشده است.
        </span>
      </div>
    );
  const measureValue = (item: { book: number; cost: number }) =>
    measure === "book" ? item.book : item.cost;
  const measureTotal = measure === "book" ? summary.book : summary.cost;
  const chartRows = summary.classes.slice(0, 8);
  const max = Math.max(1, ...chartRows.map(measureValue));
  const top = summary.classes.slice(0, 5);
  const topValue = top.reduce((sum, item) => sum + measureValue(item), 0);
  const donut = [
    ...top,
    ...(measureTotal > topValue
      ? [
          {
            label: "سایر",
            book: measure === "book" ? measureTotal - topValue : 0,
            cost: measure === "cost" ? measureTotal - topValue : 0,
            count: 0,
          },
        ]
      : []),
  ];
  let angle = 0;
  const segments = donut
    .map((item, index) => {
      const start = angle;
      angle += measureTotal > 0 ? (measureValue(item) / measureTotal) * 360 : 0;
      return `${assetPalette[index % assetPalette.length]} ${start}deg ${angle}deg`;
    })
    .join(", ");
  const normalizedQuery = query.trim().toLocaleLowerCase("fa");
  const filteredRecords = records
    .filter(
      (record) =>
        (selectedClass === "all" || record.assetClass === selectedClass) &&
        (!normalizedQuery ||
          [
            record.description,
            record.city,
            record.location,
            record.acquisitionDate,
          ].some((value) =>
            value.toLocaleLowerCase("fa").includes(normalizedQuery),
          )),
    )
    .sort((a, b) =>
      measure === "book"
        ? (b.bookValueRial ?? 0) - (a.bookValueRial ?? 0)
        : (b.costRial ?? 0) - (a.costRial ?? 0),
    );
  const totalPages = Math.max(1, Math.ceil(filteredRecords.length / pageSize));
  const safePage = Math.min(page, totalPages);
  const pageRows = filteredRecords.slice(
    (safePage - 1) * pageSize,
    safePage * pageSize,
  );
  const startRow = filteredRecords.length ? (safePage - 1) * pageSize + 1 : 0;
  const endRow = Math.min(safePage * pageSize, filteredRecords.length);
  function exportAssets() {
    const rows = filteredRecords.map((record) => ({
      "ردیف منبع": record.sourceRow,
      گروه: record.group,
      شرکت: record.company,
      "طبقه دارایی": record.assetClass,
      "شرح دارایی": record.description,
      "تاریخ تحصیل": record.acquisitionDate,
      "شهر/استان": record.city,
      "محل استقرار": record.location,
      "قیمت تمام‌شده (ریال)": record.costRial,
      "ارزش دفتری (ریال)": record.bookValueRial,
    }));
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(
      workbook,
      XLSX.utils.json_to_sheet(rows),
      "جزئیات دارایی",
    );
    const company = (records[0]?.company || "شرکت").replace(
      /[\\/:*?"<>|]/g,
      "-",
    );
    const className = (
      selectedClass === "all" ? "همه-طبقات" : selectedClass
    ).replace(/[\\/:*?"<>|]/g, "-");
    XLSX.writeFile(workbook, `دارایی-${company}-${className}.xlsx`);
  }
  return (
    <section className="iv-assets">
      {scopeNote && (
        <div className="iv-asset-scope-note">
          <Layers3 size={18} />
          <span>{scopeNote}</span>
        </div>
      )}
      <div className="iv-data-kpis">
        <article>
          <small>قیمت تمام‌شده</small>
          <strong>{millionRial(summary.cost)}</strong>
          <span>میلیون ریال</span>
        </article>
        <article>
          <small>ارزش دفتری</small>
          <strong>{millionRial(summary.book)}</strong>
          <span>میلیون ریال</span>
        </article>
        <article>
          <small>نسبت ارزش باقی‌مانده</small>
          <strong>
            {percent(summary.cost > 0 ? summary.book / summary.cost : null)}
          </strong>
          <span>ارزش دفتری ÷ تمام‌شده</span>
        </article>
        <article>
          <small>تعداد اقلام دارایی</small>
          <strong>{summary.count.toLocaleString("fa-IR")}</strong>
          <span>
            {summary.classes.length.toLocaleString("fa-IR")} طبقه استانداردشده
          </span>
        </article>
      </div>
      <div className="iv-asset-charts">
        <article className="iv-asset-bars">
          <header>
            <div>
              <BarChart3 size={19} />
              <span>
                <strong>جزئیات دارایی‌های ثابت و فیزیکی</strong>
                <small>
                  میلیون ریال · هشت طبقه اصلی بر مبنای{" "}
                  {measure === "book" ? "ارزش دفتری" : "بهای تمام‌شده"}
                </small>
              </span>
            </div>
            <div className="iv-measure-switch">
              <button
                type="button"
                className={measure === "book" ? "active" : ""}
                onClick={() => {
                  setMeasure("book");
                  setPage(1);
                }}
              >
                ارزش دفتری
              </button>
              <button
                type="button"
                className={measure === "cost" ? "active" : ""}
                onClick={() => {
                  setMeasure("cost");
                  setPage(1);
                }}
              >
                بهای تمام‌شده
              </button>
            </div>
          </header>
          <div className="iv-bars-body">
            {chartRows.map((item) => (
              <button
                type="button"
                className={`iv-bar-row ${selectedClass === item.label ? "active" : ""}`}
                key={item.label}
                onClick={() => {
                  setSelectedClass(
                    selectedClass === item.label ? "all" : item.label,
                  );
                  setPage(1);
                }}
              >
                <span title={item.label}>
                  {item.label}
                  <small>{item.count.toLocaleString("fa-IR")} قلم</small>
                </span>
                <div>
                  <i
                    style={{ width: `${(measureValue(item) / max) * 100}%` }}
                  />
                </div>
                <b>{millionRial(measureValue(item))}</b>
              </button>
            ))}
          </div>
        </article>
        <article className="iv-donut-card">
          <header>
            <PieChart size={19} />
            <span>
              <strong>
                سهم {measure === "book" ? "ارزش دفتری" : "بهای تمام‌شده"}
              </strong>
              <small>پنج طبقه اصلی و سایر دارایی‌ها</small>
            </span>
          </header>
          <div className="iv-donut-wrap">
            <div
              className="iv-donut"
              style={{ background: `conic-gradient(${segments})` }}
            >
              <span>
                <b>{summary.classes.length.toLocaleString("fa-IR")}</b>طبقه
              </span>
            </div>
            <div className="iv-donut-legend">
              {donut.map((item, index) => (
                <div key={item.label}>
                  <i
                    style={{
                      background: assetPalette[index % assetPalette.length],
                    }}
                  />
                  <span>{item.label}</span>
                  <b>
                    {percent(
                      measureTotal > 0
                        ? measureValue(item) / measureTotal
                        : null,
                      0,
                    )}
                  </b>
                </div>
              ))}
            </div>
          </div>
        </article>
      </div>
      <div className="iv-rich-table">
        <header>
          <div>
            <Wrench size={18} />
            <span>
              <strong>جزئیات دارایی‌های ثابت</strong>
              <small>
                همه اقلام طبقه انتخاب‌شده با امکان جست‌وجو، مشاهده صفحه‌ای و
                دانلود کامل
              </small>
            </span>
          </div>
          <b>واحد نمایش: میلیون ریال</b>
        </header>
        <div className="iv-asset-table-tools">
          <label>
            <span>طبقه دارایی</span>
            <select
              value={selectedClass}
              onChange={(event) => {
                setSelectedClass(event.target.value);
                setPage(1);
              }}
            >
              <option value="all">
                همه طبقات ({records.length.toLocaleString("fa-IR")})
              </option>
              {summary.classes.map((item) => (
                <option key={item.label} value={item.label}>
                  {item.label} ({item.count.toLocaleString("fa-IR")})
                </option>
              ))}
            </select>
            <ChevronDown size={16} />
          </label>
          <label className="iv-asset-search">
            <Search size={17} />
            <input
              value={query}
              onChange={(event) => {
                setQuery(event.target.value);
                setPage(1);
              }}
              placeholder="جست‌وجو در شرح، شهر یا محل استقرار"
            />
          </label>
          <button
            type="button"
            className="iv-asset-download"
            onClick={exportAssets}
            disabled={!filteredRecords.length}
          >
            <Download size={17} />
            <span>
              <strong>دانلود فایل کامل</strong>
              <small>
                {filteredRecords.length.toLocaleString("fa-IR")} ردیف انتخاب‌شده
              </small>
            </span>
          </button>
        </div>
        <div className="detail-table-scroll iv-asset-detail-scroll">
          <table>
            <thead>
              <tr>
                <th>ردیف</th>
                <th>طبقه</th>
                <th>شرح دارایی</th>
                <th>محل استقرار</th>
                <th>تاریخ تحصیل</th>
                <th>قیمت تمام‌شده</th>
                <th>ارزش دفتری</th>
                <th>ماندگاری ارزش</th>
              </tr>
            </thead>
            <tbody>
              {pageRows.map((record) => (
                <tr key={`${record.sourceRow}-${record.description}`}>
                  <td>{record.sourceRow.toLocaleString("fa-IR")}</td>
                  <td>
                    <span className="iv-class-chip">{record.assetClass}</span>
                  </td>
                  <td>
                    <strong>{record.description}</strong>
                  </td>
                  <td>{record.city || record.location || "—"}</td>
                  <td>{record.acquisitionDate || "—"}</td>
                  <td>{millionRial(record.costRial)}</td>
                  <td>
                    <b>{millionRial(record.bookValueRial)}</b>
                  </td>
                  <td>
                    {percent(
                      record.costRial && record.bookValueRial !== null
                        ? record.bookValueRial / record.costRial
                        : null,
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <footer className="iv-asset-pagination">
          <span>
            نمایش {startRow.toLocaleString("fa-IR")} تا{" "}
            {endRow.toLocaleString("fa-IR")} از{" "}
            {filteredRecords.length.toLocaleString("fa-IR")} قلم
          </span>
          <div>
            <button
              type="button"
              disabled={safePage <= 1}
              onClick={() => setPage(Math.max(1, safePage - 1))}
            >
              <ArrowRight size={16} />
              قبلی
            </button>
            <b>
              صفحه {safePage.toLocaleString("fa-IR")} از{" "}
              {totalPages.toLocaleString("fa-IR")}
            </b>
            <button
              type="button"
              disabled={safePage >= totalPages}
              onClick={() => setPage(Math.min(totalPages, safePage + 1))}
            >
              بعدی
              <ArrowLeft size={16} />
            </button>
          </div>
        </footer>
      </div>
    </section>
  );
}

function ActivitySection({
  records,
  hasFile,
}: {
  records: MetilActivityRecord[];
  hasFile: boolean;
}) {
  if (!hasFile)
    return (
      <div className="iv-unavailable">
        <Package size={30} />
        <strong>فایل فعالیت گروه متیل بارگذاری نشده است</strong>
        <span>
          برای نمایش فروش و خدمات سال ۱۴۰۴، فایل Metil Group را در صفحه نخست
          بارگذاری کنید.
        </span>
      </div>
    );
  if (!records.length)
    return (
      <div className="iv-unavailable">
        <AlertTriangle size={30} />
        <strong>فعالیت متناظر برای این شرکت پیدا نشد</strong>
        <span>
          این وضعیت به معنی عملکرد صفر نیست؛ داده‌ای با نام قابل تطبیق در فایل
          وجود ندارد.
        </span>
      </div>
    );
  const isAmount = (record: MetilActivityRecord) =>
      /مبلغ/.test(record.variable) && /میلیون ریال/.test(record.unit),
    isQuantity = (record: MetilActivityRecord) =>
      /مقدار/.test(record.variable) && /تن/.test(record.unit),
    sales = records.filter((record) => /فروش/.test(record.operation)),
    services = records.filter((record) => /خدمات/.test(record.operation)),
    salesRevenue = sales
      .filter(isAmount)
      .reduce((sum, record) => sum + (record.value ?? 0), 0),
    serviceRevenue = services
      .filter(isAmount)
      .reduce((sum, record) => sum + (record.value ?? 0), 0),
    salesVolume = sales
      .filter(isQuantity)
      .reduce((sum, record) => sum + (record.value ?? 0), 0),
    products = new Map<string, { revenue: number; volume: number }>();
  for (const record of sales) {
    const label = record.product || "سایر محصولات",
      item = products.get(label) ?? { revenue: 0, volume: 0 };
    if (isAmount(record)) item.revenue += record.value ?? 0;
    if (isQuantity(record)) item.volume += record.value ?? 0;
    products.set(label, item);
  }
  const revenueRows = [...products.entries()]
      .map(([label, value]) => ({ label, value: value.revenue }))
      .filter((item) => item.value > 0)
      .sort((a, b) => b.value - a.value)
      .slice(0, 6),
    volumeRows = [...products.entries()]
      .map(([label, value]) => ({ label, value: value.volume }))
      .filter((item) => item.value > 0)
      .sort((a, b) => b.value - a.value)
      .slice(0, 6),
    maxRevenue = Math.max(1, ...revenueRows.map((item) => item.value)),
    maxVolume = Math.max(1, ...volumeRows.map((item) => item.value));
  return (
    <section className="iv-activity">
      <div className="iv-data-kpis">
        <article>
          <small>مبلغ فروش</small>
          <strong>{faInteger(salesRevenue)}</strong>
          <span>میلیون ریال</span>
        </article>
        <article>
          <small>درآمد خدمات</small>
          <strong>{faInteger(serviceRevenue)}</strong>
          <span>میلیون ریال</span>
        </article>
        <article>
          <small>مقدار فروش</small>
          <strong>{faInteger(salesVolume)}</strong>
          <span>تن</span>
        </article>
        <article>
          <small>سهم خدمات از درآمد</small>
          <strong>
            {percent(
              salesRevenue + serviceRevenue > 0
                ? serviceRevenue / (salesRevenue + serviceRevenue)
                : null,
            )}
          </strong>
          <span>سال ۱۴۰۴</span>
        </article>
      </div>
      <div className="iv-activity-grid">
        <article>
          <header>
            <div>
              <Package size={19} />
              <span>
                <strong>ترکیب مبلغ فروش محصولات</strong>
                <small>میلیون ریال · شش محصول اصلی سال ۱۴۰۴</small>
              </span>
            </div>
          </header>
          <div className="iv-rank-bars">
            {revenueRows.map((item, index) => (
              <div key={item.label}>
                <span>
                  <i>{(index + 1).toLocaleString("fa-IR")}</i>
                  {item.label}
                </span>
                <div>
                  <b style={{ width: `${(item.value / maxRevenue) * 100}%` }} />
                </div>
                <strong>{faInteger(item.value)}</strong>
              </div>
            ))}
          </div>
        </article>
        <article>
          <header>
            <div>
              <TrendingUp size={19} />
              <span>
                <strong>حجم فروش محصولات</strong>
                <small>تن · شش محصول اصلی سال ۱۴۰۴</small>
              </span>
            </div>
          </header>
          <div className="iv-rank-bars volume">
            {volumeRows.map((item, index) => (
              <div key={item.label}>
                <span>
                  <i>{(index + 1).toLocaleString("fa-IR")}</i>
                  {item.label}
                </span>
                <div>
                  <b style={{ width: `${(item.value / maxVolume) * 100}%` }} />
                </div>
                <strong>{faInteger(item.value)}</strong>
              </div>
            ))}
          </div>
        </article>
      </div>
    </section>
  );
}

function EquipmentSection({
  records,
  hasFile,
}: {
  records: EquipmentRecord[];
  hasFile: boolean;
}) {
  const [equipmentFilter, setEquipmentFilter] = useState("all");
  if (!hasFile)
    return (
      <div className="iv-unavailable">
        <Wrench size={30} />
        <strong>فایل تجهیزات گروه متیل بارگذاری نشده است</strong>
        <span>
          فایل Metil Equipment را در صفحه نخست بارگذاری کنید تا ظرفیت و محدوده
          عملکرد تجهیزات نمایش داده شود.
        </span>
      </div>
    );
  if (!records.length)
    return (
      <div className="iv-unavailable">
        <AlertTriangle size={30} />
        <strong>تجهیز متناظر برای این شرکت پیدا نشد</strong>
        <span>
          نام شرکت با نگاشت کنترل‌شده بررسی شد؛ نبود رکورد به معنی ظرفیت صفر
          نیست.
        </span>
      </div>
    );
  const actual = records.reduce(
    (sum, record) => sum + (record.actualCapacityTon ?? 0),
    0,
  );
  const nominal = records.reduce(
    (sum, record) => sum + (record.nominalCapacityTon ?? 0),
    0,
  );
  const equipmentTypes = [
    ...new Set(records.map((record) => record.equipment)),
  ].sort((a, b) => a.localeCompare(b, "fa"));
  const grouped = new Map<
    string,
    { label: string; count: number; actual: number; nominal: number }
  >();
  for (const record of records) {
    const item = grouped.get(record.equipment) ?? {
      label: record.equipment,
      count: 0,
      actual: 0,
      nominal: 0,
    };
    item.count++;
    item.actual += record.actualCapacityTon ?? 0;
    item.nominal += record.nominalCapacityTon ?? 0;
    grouped.set(record.equipment, item);
  }
  const chartRows = [...grouped.values()]
    .sort((a, b) => b.nominal - a.nominal)
    .slice(0, 8);
  const max = Math.max(1, ...chartRows.map((item) => item.nominal));
  const tableRows = records
    .filter(
      (record) =>
        equipmentFilter === "all" || record.equipment === equipmentFilter,
    )
    .sort((a, b) => (b.nominalCapacityTon ?? 0) - (a.nominalCapacityTon ?? 0));
  const rangeLabel = (from: number | null, to: number | null, unit: string) =>
    from === null && to === null
      ? "—"
      : `${faNumber(from, 2)} تا ${faNumber(to, 2)} ${unit}`;
  return (
    <section className="iv-equipment">
      <div className="iv-data-kpis">
        <article>
          <small>تعداد تجهیزات ثبت‌شده</small>
          <strong>{records.length.toLocaleString("fa-IR")}</strong>
          <span>{equipmentTypes.length.toLocaleString("fa-IR")} نوع تجهیز</span>
        </article>
        <article>
          <small>ظرفیت اسمی تک‌شیفت</small>
          <strong>{faInteger(nominal)}</strong>
          <span>تن در سال</span>
        </article>
        <article>
          <small>ظرفیت واقعی تک‌شیفت</small>
          <strong>{faInteger(actual)}</strong>
          <span>تن در سال</span>
        </article>
        <article>
          <small>نسبت ظرفیت واقعی به اسمی</small>
          <strong>{percent(nominal > 0 ? actual / nominal : null)}</strong>
          <span>بر مبنای ظرفیت‌های ثبت‌شده فایل</span>
        </article>
      </div>
      <div className="iv-equipment-layout">
        <article className="iv-equipment-chart">
          <header>
            <div>
              <Wrench size={19} />
              <span>
                <strong>ظرفیت تجهیزات به تفکیک نوع</strong>
                <small>هشت گروه اصلی · ظرفیت اسمی و واقعی تک‌شیفت</small>
              </span>
            </div>
            <div>
              <i className="nominal" />
              اسمی <i className="actual" />
              واقعی
            </div>
          </header>
          <div>
            {chartRows.map((item) => (
              <button
                type="button"
                key={item.label}
                className={equipmentFilter === item.label ? "active" : ""}
                onClick={() =>
                  setEquipmentFilter(
                    equipmentFilter === item.label ? "all" : item.label,
                  )
                }
              >
                <span>
                  {item.label}
                  <small>{item.count.toLocaleString("fa-IR")} دستگاه</small>
                </span>
                <div>
                  <i
                    className="nominal"
                    style={{ width: `${(item.nominal / max) * 100}%` }}
                  />
                  <i
                    className="actual"
                    style={{ width: `${(item.actual / max) * 100}%` }}
                  />
                </div>
                <b>{faInteger(item.actual)}</b>
              </button>
            ))}
          </div>
        </article>
        <article className="iv-equipment-range">
          <header>
            <Target size={19} />
            <span>
              <strong>دامنه فنی تجهیزات</strong>
              <small>حدود ثبت‌شده ضخامت و عرض</small>
            </span>
          </header>
          <div>
            <span>
              <small>کمینه ضخامت</small>
              <strong>
                {faNumber(
                  Math.min(
                    ...records
                      .map((record) => record.thicknessFromMm)
                      .filter((value): value is number => value !== null),
                  ),
                  2,
                )}{" "}
                mm
              </strong>
            </span>
            <span>
              <small>بیشینه ضخامت</small>
              <strong>
                {faNumber(
                  Math.max(
                    ...records
                      .map((record) => record.thicknessToMm)
                      .filter((value): value is number => value !== null),
                  ),
                  2,
                )}{" "}
                mm
              </strong>
            </span>
            <span>
              <small>کمینه عرض</small>
              <strong>
                {faInteger(
                  Math.min(
                    ...records
                      .map((record) => record.widthFromMm)
                      .filter((value): value is number => value !== null),
                  ),
                )}{" "}
                mm
              </strong>
            </span>
            <span>
              <small>بیشینه عرض</small>
              <strong>
                {faInteger(
                  Math.max(
                    ...records
                      .map((record) => record.widthToMm)
                      .filter((value): value is number => value !== null),
                  ),
                )}{" "}
                mm
              </strong>
            </span>
          </div>
        </article>
      </div>
      <div className="iv-rich-table iv-equipment-table">
        <header>
          <div>
            <ListTree size={18} />
            <span>
              <strong>فهرست تجهیزات و محدوده عملکرد</strong>
              <small>جزئیات کامل تجهیزات شرکت منتخب</small>
            </span>
          </div>
          <label>
            <span>نوع تجهیز</span>
            <select
              value={equipmentFilter}
              onChange={(event) => setEquipmentFilter(event.target.value)}
            >
              <option value="all">
                همه تجهیزات ({records.length.toLocaleString("fa-IR")})
              </option>
              {equipmentTypes.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
            <ChevronDown size={15} />
          </label>
        </header>
        <div className="detail-table-scroll">
          <table>
            <thead>
              <tr>
                <th>ردیف</th>
                <th>نام تجهیز</th>
                <th>محدوده عملکرد</th>
                <th>دامنه ضخامت</th>
                <th>دامنه عرض</th>
                <th>ظرفیت واقعی</th>
                <th>ظرفیت اسمی</th>
                <th>نسبت ظرفیت</th>
              </tr>
            </thead>
            <tbody>
              {tableRows.map((record) => (
                <tr key={`${record.sourceRow}-${record.equipment}`}>
                  <td>
                    {(record.rowNumber ?? record.sourceRow).toLocaleString(
                      "fa-IR",
                    )}
                  </td>
                  <td>
                    <strong>{record.equipment}</strong>
                  </td>
                  <td>{record.operation}</td>
                  <td>
                    {rangeLabel(
                      record.thicknessFromMm,
                      record.thicknessToMm,
                      "mm",
                    )}
                  </td>
                  <td>
                    {rangeLabel(record.widthFromMm, record.widthToMm, "mm")}
                  </td>
                  <td>
                    <b>{faInteger(record.actualCapacityTon)}</b>
                  </td>
                  <td>{faInteger(record.nominalCapacityTon)}</td>
                  <td>
                    <span className="iv-score-chip">
                      {percent(
                        record.nominalCapacityTon &&
                          record.actualCapacityTon !== null
                          ? record.actualCapacityTon / record.nominalCapacityTon
                          : null,
                      )}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}

function PointDetailPanel({
  point,
  holding,
  weights,
  assetRecords,
  activityRecords,
  equipmentRecords,
  hasAssetFile,
  hasActivityFile,
  hasEquipmentFile,
}: {
  point: InvestmentPoint;
  holding: InvestmentHolding;
  weights: InvestmentWeights;
  assetRecords: AssetRecord[];
  activityRecords: MetilActivityRecord[];
  equipmentRecords: EquipmentRecord[];
  hasAssetFile: boolean;
  hasActivityFile: boolean;
  hasEquipmentFile: boolean;
}) {
  const [tab, setTab] = useState<DetailTab>("operations");
  return (
    <section className="investment-detail-panel iv22-detail">
      <header>
        <div>
          <span>
            {point.pointType === "optimized"
              ? "سناریوی بهینه"
              : point.isForecast
                ? "بودجه مصوب"
                : "عملکرد واقعی"}
          </span>
          <h2>{point.company}</h2>
          <p>
            شناسنامه تحلیلی سال{" "}
            {point.year.toLocaleString("fa-IR", { useGrouping: false })}
          </p>
        </div>
        <div className="detail-hero-metrics compact">
          <div>
            <small>امتیاز اثربخشی سرمایه</small>
            <strong>{faNumber(point.x, 3)}</strong>
          </div>
          <div>
            <small>{point.verticalLabel}</small>
            <strong>{faNumber(point.y, 3)}</strong>
          </div>
          <div>
            <small>سال منبع سرمایه</small>
            <strong>
              {point.capitalSourceYear.toLocaleString("fa-IR", {
                useGrouping: false,
              })}
            </strong>
          </div>
        </div>
      </header>
      <nav
        className={`investment-detail-tabs iv22-tabs ${holding === "metil" ? "six" : "four"}`}
        aria-label="تب‌های جزئیات شرکت"
      >
        <button
          type="button"
          className={tab === "operations" ? "active" : ""}
          onClick={() => setTab("operations")}
        >
          <Activity size={19} />
          <span>
            <strong>
              {point.verticalMetric === "utilization"
                ? "عملکرد عملیاتی"
                : "بهره‌وری دارایی‌ها"}
            </strong>
            <small>
              {point.verticalMetric === "utilization"
                ? "تولید، ظرفیت و بهره‌برداری"
                : "گردش، ساختار دارایی و محرک‌ها"}
            </small>
          </span>
        </button>
        <button
          type="button"
          className={tab === "capital" ? "active" : ""}
          onClick={() => setTab("capital")}
        >
          <CircleGauge size={19} />
          <span>
            <strong>امتیاز اثربخشی سرمایه</strong>
            <small>چهار شاخص و سهم هر مؤلفه</small>
          </span>
        </button>
        <button
          type="button"
          className={tab === "assets" ? "active" : ""}
          onClick={() => setTab("assets")}
        >
          <Boxes size={19} />
          <span>
            <strong>جزئیات دارایی‌های ثابت و فیزیکی</strong>
            <small>تجهیزات و ارزش دفتری</small>
          </span>
        </button>
        {holding === "metil" && (
          <button
            type="button"
            className={tab === "activity" ? "active" : ""}
            onClick={() => setTab("activity")}
          >
            <Package size={19} />
            <span>
              <strong>فعالیت ۱۴۰۴</strong>
              <small>فروش و خدمات به تفکیک محصول</small>
            </span>
          </button>
        )}
        {holding === "metil" && (
          <button
            type="button"
            className={tab === "equipment" ? "active" : ""}
            onClick={() => setTab("equipment")}
          >
            <Wrench size={19} />
            <span>
              <strong>تجهیزات تولیدی</strong>
              <small>ظرفیت و محدوده عملکرد</small>
            </span>
          </button>
        )}
        <button
          type="button"
          className={tab === "method" ? "active" : ""}
          onClick={() => setTab("method")}
        >
          <ListTree size={19} />
          <span>
            <strong>روش محاسبه</strong>
            <small>فرمول‌ها و قواعد کنترلی</small>
          </span>
        </button>
      </nav>
      {tab === "operations" &&
        (point.verticalMetric === "utilization" ? (
          <section className="detail-section inline">
            <div className="detail-section-title">
              <Activity size={18} />
              <div>
                <strong>{point.verticalLabel}</strong>
                <span>{point.verticalMethod}</span>
              </div>
            </div>
            <div className="detail-table-scroll">
              <table>
                <thead>
                  <tr>
                    <th>تجهیز / خط</th>
                    <th>ظرفیت اسمی</th>
                    <th>تولید</th>
                    <th>ضریب بهره‌برداری</th>
                  </tr>
                </thead>
                <tbody>
                  {point.productionRows.map((row) => (
                    <tr key={`${row.sourceRow}-${row.equipment}`}>
                      <td>
                        <strong>{row.equipment || "خط اصلی"}</strong>
                        <small>
                          ردیف منبع {row.sourceRow.toLocaleString("fa-IR")}
                        </small>
                      </td>
                      <td>{faInteger(row.capacity)}</td>
                      <td>{faInteger(row.production)}</td>
                      <td>
                        <span className="iv-score-chip">
                          {percent(row.utilization)}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {point.productGroups.length > 1 && (
              <div className="iv-product-weights">
                {point.productGroups.map((group) => (
                  <article key={group.label}>
                    <span>{group.label}</span>
                    <strong>{percent(group.utilization)}</strong>
                    <small>وزن ثابت {percent(group.weight, 0)}</small>
                  </article>
                ))}
              </div>
            )}
          </section>
        ) : (
          <AssetProductivitySection point={point} />
        ))}
      {tab === "capital" && (
        <section className="detail-section inline">
          <div className="detail-section-title">
            <CircleGauge size={18} />
            <div>
              <strong>اجزای امتیاز اثربخشی سرمایه</strong>
              <span>
                امتیازهای نرمال‌شده دیتابیس مالی{" "}
                {holding === "atieh" ? "آتیه فولاد" : "فولاد متیل"}
              </span>
            </div>
          </div>
          <div className="detail-table-scroll">
            <table>
              <thead>
                <tr>
                  <th>شاخص</th>
                  <th>کد</th>
                  <th>مقدار خام</th>
                  <th>امتیاز</th>
                  <th>وزن مؤثر</th>
                  <th>سهم در شاخص</th>
                </tr>
              </thead>
              <tbody>
                {point.components.map((component) => (
                  <tr key={component.code}>
                    <td>
                      <strong>{component.label}</strong>
                    </td>
                    <td>
                      {Number(component.code).toLocaleString("fa-IR", {
                        useGrouping: false,
                      })}
                    </td>
                    <td>
                      {component.rawValue === null
                        ? "—"
                        : component.unit.includes("درصد")
                          ? percent(component.rawValue)
                          : faNumber(component.rawValue, 2)}
                    </td>
                    <td>
                      <div className="iv-score-cell">
                        <span>
                          <i
                            style={{ width: `${(component.score ?? 0) * 10}%` }}
                          />
                        </span>
                        <b>{faNumber(component.score, 2)}</b>
                      </div>
                      {point.pointType === "budget" && component.scoreSource && (
                        <small title={`سال‌های کالیبراسیون: ${(component.calibrationYears ?? []).join("، ")}`}>
                          امتیاز سناریویی دوره بودجه · خط‌کش ثابت سال پایه
                        </small>
                      )}
                    </td>
                    <td>{percent(component.effectiveWeight, 0)}</td>
                    <td>
                      <span className="iv-score-chip">
                        {faNumber(component.contribution, 3)}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr>
                  <td colSpan={5}>
                    <strong>امتیاز اثربخشی سرمایه</strong>
                  </td>
                  <td>
                    <b>{faNumber(point.x, 3)}</b>
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </section>
      )}
      {tab === "assets" && (
        <AssetSection
          records={assetRecords}
          hasFile={hasAssetFile}
          scopeNote={
            holding === "atieh" &&
            canonicalCompanyKey(point.company) ===
              canonicalCompanyKey("فولاد متیل")
              ? "دارایی‌های این نما به‌صورت تجمیعی از تمام شرکت‌های گروه متیل محاسبه شده‌اند."
              : undefined
          }
        />
      )}
      {tab === "activity" && holding === "metil" && (
        <ActivitySection records={activityRecords} hasFile={hasActivityFile} />
      )}
      {tab === "equipment" && holding === "metil" && (
        <EquipmentSection
          records={equipmentRecords}
          hasFile={hasEquipmentFile}
        />
      )}
      {tab === "method" && (
        <section className="investment-method-detail iv22-method">
          <div>
            <span>محور افقی</span>
            <strong>
              {INVESTMENT_COMPONENTS.map(
                (item) => `${percent(weights[item.key], 0)} ${item.shortLabel}`,
              ).join(" + ")}
            </strong>
          </div>
          <div>
            <span>محور عمودی</span>
            <strong>{point.verticalMethod}</strong>
          </div>
          <div>
            <span>قاعده داده ناقص</span>
            <strong>
              امتیاز مفقودی صفر یا بازتوزیع وزن نمی‌شود؛ نقطه ناقص محاسبه
              نمی‌شود.
            </strong>
          </div>
          <div>
            <span>دوره بودجه منتخب</span>
            <strong>
              محور سرمایه از آخرین عملکرد معتبر استفاده می‌کند؛ بهره‌وری دارایی
              فقط با امتیاز کد ۱۵۲ همان سال ساخته می‌شود.
            </strong>
          </div>
        </section>
      )}
      {point.warnings.map((warning) => (
        <div className="investment-warning" key={warning}>
          <AlertTriangle size={18} />
          <span>{warning}</span>
        </div>
      ))}
    </section>
  );
}

export default function InvestmentAnalysis({
  financialModel, allFinancialModel,
  productionModel,
  profitModel,
  holding,
  onHoldingChange,
  availableHoldings,
  assetModel,
  activityModel,
  equipmentModel,
  contextCompany,contextYear,onContextChange,
}: {
  financialModel: FinancialModel;
  allFinancialModel?: FinancialModel;
  productionModel: ProductionModel | null;
  profitModel: ProfitModel | null;
  holding: InvestmentHolding;
  onHoldingChange: (holding: InvestmentHolding) => void;
  availableHoldings: Record<InvestmentHolding, boolean>;
  assetModel: AssetModel | null;
  activityModel: MetilActivityModel | null;
  equipmentModel: EquipmentModel | null;
  contextCompany?:string;contextYear?:number;onContextChange?:(company:string,year?:number)=>void;
}) {
  const [moduleView, setModuleView] = useState<"map" | "value" | "pulse">("map");
  const [valueInitialCompany, setValueInitialCompany] = useState(contextCompany??"");
  useEffect(()=>{if(contextCompany){setSelectedCompany(contextCompany);setValueInitialCompany(contextCompany);}setDetailPoint(null);},[contextCompany,contextYear]);
  const [weights, setWeights] = useState<InvestmentWeights>({
      ...DEFAULT_INVESTMENT_WEIGHTS,
    }),
    [draftWeights, setDraftWeights] = useState<InvestmentWeights>({
      ...DEFAULT_INVESTMENT_WEIGHTS,
    }),
    [scope, setScope] = useState<Scope>("production"),
    [selectedCompany, setSelectedCompany] = useState(contextCompany??""),
    [hoveredCompany, setHoveredCompany] = useState(""),
    [detailPoint, setDetailPoint] = useState<InvestmentPoint | null>(null),
    [focusSelected, setFocusSelected] = useState(false),
    [weightsOpen, setWeightsOpen] = useState(false);
  const [optimizedSnapshots,setOptimizedSnapshots]=useScenarioState<Record<string,PlanningScenarioSnapshot>>(
    JSON.stringify([holding,financialModel.importedAt,profitModel?.importedAt,'map-snapshots']),{},
    (v):v is Record<string,PlanningScenarioSnapshot>=>!!v&&typeof v==='object'&&!Array.isArray(v)&&Object.values(v).every((s:any)=>s&&s.holding===holding&&typeof s.company==='string'&&Number.isFinite(s.year)&&Number.isFinite(s.roic)&&Number.isFinite(s.nopat)&&s.assetSchedule&&s.map&&Array.isArray(s.warnings)));
  useEffect(() => {
    const receive = (event: Event) => {
      const snapshot = (event as CustomEvent<PlanningScenarioSnapshot>).detail;
      if (snapshot?.holding === holding)
        setOptimizedSnapshots((current) => ({
          ...current,
          [canonicalCompanyKey(snapshot.company)+':'+snapshot.year]: snapshot,
        }));
    };
    window.addEventListener("ips-optimized-point", receive);
    return () => window.removeEventListener("ips-optimized-point", receive);
  }, [holding]);
  const basePoints = buildInvestmentPoints(
    financialModel,
    productionModel,
    weights,
    holding,
    profitModel,
  );
  const optimizedPoints = Object.values(optimizedSnapshots).flatMap(
    (snapshot): InvestmentPoint[] => {
      const budget = basePoints.find(
        (point) =>
          point.year === snapshot.year && point.pointType==='budget' &&
          canonicalCompanyKey(point.company) ===
            canonicalCompanyKey(snapshot.company),
      );
      if (!budget || snapshot.map.x === null) return [];
      const schedule = snapshot.assetSchedule,
        composition = buildScenarioAssetComposition(schedule),
        compositionSum = composition.reduce(
          (sum, item) => sum + item.amount,
          0,
        );
      return [
        {
          ...budget,
          id: `${budget.company}-${snapshot.year}-optimized`,
          x: snapshot.map.x,
          y: snapshot.map.y ?? budget.y,
          pointType: "optimized",
          assetProductivity: {
            ...budget.assetProductivity!,
            rawTurnover: snapshot.assetTurnover,
            turnoverScore: snapshot.scores["152"]?.score ?? 0,
            averageTotalAssets: schedule.averageTotalAssets,
            assetComposition: composition.map((item) => ({
              ...item,
              complete: true,
            })),
            workingCapitalDrivers: [
              {
                code: "165",
                key: "dio",
                label: "روزهای نگهداری موجودی (DIO)",
                rawValue: snapshot.dio,
                unit: "روز",
              },
              {
                code: "166",
                key: "dso",
                label: "روزهای وصول مطالبات (DSO)",
                rawValue: snapshot.dso,
                unit: "روز",
              },
              {
                code: "167",
                key: "dpo",
                label: "روزهای پرداخت بدهی (DPO)",
                rawValue: snapshot.dpo,
                unit: "روز",
              },
              {
                code: "168",
                key: "ccc",
                label: "چرخه تبدیل نقد (CCC)",
                rawValue: snapshot.ccc,
                unit: "روز",
              },
            ],
            reconciliationDifference:
              compositionSum - schedule.averageTotalAssets,
            reconciliationOk:
              Math.abs(compositionSum - schedule.averageTotalAssets) <=
              Math.max(1, Math.abs(schedule.averageTotalAssets) * 1e-9),
          },
          components: budget.components.map((component) => {
            const score = snapshot.scores[component.code]?.score ?? null;
            return {
              ...component,
              rawValue:
                component.code === "176"
                  ? snapshot.spread
                  : component.code === "150"
                    ? snapshot.roic
                    : component.code === "144"
                      ? snapshot.revenueGrowth
                      : component.code === "175"
                        ? snapshot.fcfMargin
                        : component.rawValue,
              score,
              contribution:
                score === null ? 0 : (score / 10) * component.effectiveWeight,
            };
          }),
          warnings: [
            ...snapshot.warnings,
            "این نقطه دقیقاً از آخرین سناریوی فعال کاربر ساخته شده است.",
          ],
        },
      ];
    },
  );
  const allPoints = [...basePoints, ...optimizedPoints];
  const recentPoints = allPoints;
  const hasProductionPoints = recentPoints.some(
    (point) => point.verticalMetric === "utilization",
  );
  const effectiveScope: Scope =
    holding === "atieh" && scope === "production" && !hasProductionPoints
      ? "other"
      : scope;
  const scopedPoints =
    holding === "metil"
      ? recentPoints
      : recentPoints.filter((point) =>
          effectiveScope === "production"
            ? point.verticalMetric === "utilization"
            : point.verticalMetric === "asset-productivity",
        );
  const companies = [
    ...new Set(scopedPoints.map((point) => point.company)),
  ].sort((a, b) => a.localeCompare(b, "fa"));
  const activeCompany = companies.includes(selectedCompany)
    ? selectedCompany
    : (companies[0] ?? "");
  const points = focusSelected
    ? scopedPoints.filter((point) => point.company === activeCompany)
    : scopedPoints;
  const selectedHistory = recentPoints
    .filter((point) => point.company === activeCompany)
    .sort((a, b) => a.year - b.year);
  const selectedPoint =
    [...selectedHistory].sort((a, b) => b.year - a.year)[0] ?? null;
  const selectedActual =
    [...selectedHistory]
      .filter((point) => !point.isForecast)
      .sort((a, b) => b.year - a.year)[0] ?? selectedPoint;
  const previousActual =
    selectedHistory
      .filter(
        (point) =>
          !point.isForecast && point.year < (selectedActual?.year ?? 0),
      )
      .at(-1) ?? null;
  const capitalDelta =
    selectedActual && previousActual
      ? selectedActual.x - previousActual.x
      : null;
  const operationDelta =
    selectedActual && previousActual
      ? selectedActual.y - previousActual.y
      : null;
  const shownDetailPoint =
    detailPoint?.company === activeCompany ? detailPoint : selectedPoint;
  const band = scoreBand(selectedPoint?.x ?? 0);
  const assetRecords = assetsForCompany(assetModel, activeCompany, holding);
  const activityRecords =
    holding === "metil" ? activityForCompany(activityModel, activeCompany) : [];
  const equipmentRecords =
    holding === "metil"
      ? equipmentForCompany(equipmentModel, activeCompany)
      : [];
  const verticalTitle =
    holding === "atieh" && effectiveScope === "production"
      ? "ضریب بهره‌برداری"
      : "بهره‌وری دارایی‌ها";
  const missingCapital = financialModel.companies.filter(
    (company) => !allPoints.some((point) => point.company === company),
  );
  return (
    <div className="investment-module-v26">
      <nav
        className="investment-module-switch no-print"
        aria-label="بخش‌های تحلیل سرمایه‌گذاری"
      >
        <button
          type="button"
          className={moduleView === "map" ? "active" : ""}
          onClick={() => setModuleView("map")}
        >
          <Target size={20} />
          <span>
            <strong>نقشه سرمایه و عملیات</strong>
            <small>اسکاتر چهارناحیه‌ای و مسیر شرکت‌ها</small>
          </span>
        </button>
        <button
          type="button"
          className={moduleView === "value" ? "active" : ""}
          onClick={() => setModuleView("value")}
        >
          <Sparkles size={20} />
          <span>
            <strong>موتور ارزش‌آفرینی</strong>
            <small>ROIC، Spread، علت‌ها و اهرم‌های اقدام</small>
          </span>
          <b>جدید</b>
        </button>
        <button
          type="button"
          className={moduleView === "pulse" ? "active" : ""}
          onClick={() => setModuleView("pulse")}
        >
          <HeartPulse size={20} />
          <span>
            <strong>نبض سرمایه‌گذاری</strong>
            <small>جمع‌بندی کل پرتفوی برای مدیرعامل</small>
          </span>
          <b>مدیریتی</b>
        </button>
      </nav>
      {moduleView === "pulse" ? (
        <PortfolioPulseView
          financialModel={financialModel}
          profitModel={profitModel}
          productionModel={productionModel}
          holding={holding}
          onHoldingChange={onHoldingChange}
          availableHoldings={availableHoldings}
          onCompany={(company) => { onContextChange?.(company);setValueInitialCompany(company); setModuleView("value"); }}
        />
      ) : moduleView === "value" ? (
        <ValueCreationEngine
          key={`value-${holding}-${valueInitialCompany}`}
          allFinancialModel={allFinancialModel ?? financialModel}
          holding={holding}
          financialModel={financialModel}
          profitModel={profitModel}
          productionModel={productionModel}
          initialCompany={valueInitialCompany}
          initialYear={contextYear} onContextChange={onContextChange}
        />
      ) : (
        <div className="investment-page investment-v22">
          <section className="iv22-hero">
            <div className="iv22-hero-copy">
              <span>
                <Sparkles size={17} /> تحلیل سرمایه‌گذاری · نسخه ۳۲
              </span>
              <h1>نقشه هوشمند سرمایه و عملیات</h1>
              <p>
                مسیر شرکت‌ها، کیفیت تخصیص سرمایه، بهره‌برداری تولید و بهره‌وری
                دارایی‌ها در یک نمای تصمیم‌محور
              </p>
            </div>
            <div
              className="iv22-holding-switch"
              role="tablist"
              aria-label="انتخاب گروه"
            >
              <span>گروه مورد بررسی</span>
              <div>
                {(["atieh", "metil"] as InvestmentHolding[]).map((key) => (
                  <button
                    key={key}
                    type="button"
                    disabled={!availableHoldings[key]}
                    className={holding === key ? "active" : ""}
                    onClick={() => onHoldingChange(key)}
                  >
                    <Layers3 size={18} />
                    <span>
                      <strong>
                        {key === "atieh" ? "آتیه فولاد" : "فولاد متیل"}
                      </strong>
                      <small>
                        {key === "atieh"
                          ? "تولیدی و سایر شرکت‌ها"
                          : "بازرگانی و خدماتی"}
                      </small>
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </section>
          <section className="iv-command iv22-command no-print">
            <label className="iv-company-select">
              <span>شرکت مورد بررسی</span>
              <div>
                <Building2 size={19} />
                <select
                  value={activeCompany}
                  onChange={(event) => {
                    setSelectedCompany(event.target.value);onContextChange?.(event.target.value);
                    setDetailPoint(null);
                  }}
                >
                  {companies.map((company) => (
                    <option key={company}>{company}</option>
                  ))}
                </select>
                <ChevronDown size={17} />
              </div>
            </label>
            {holding === "atieh" ? (
              <div className="iv-scope iv22-scope">
                <span>نوع شرکت</span>
                <div>
                  {(
                    [
                      {
                        key: "production",
                        label: "شرکت‌های تولیدی",
                        icon: <Factory size={17} />,
                      },
                      {
                        key: "other",
                        label: "سایر شرکت‌ها",
                        icon: <Building2 size={17} />,
                      },
                    ] as const
                  ).map((item) => (
                    <button
                      type="button"
                      key={item.key}
                      className={effectiveScope === item.key ? "active" : ""}
                      onClick={() => {
                        setScope(item.key);
                        setSelectedCompany("");
                        setDetailPoint(null);
                      }}
                    >
                      {item.icon}
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="iv22-fixed-scope">
                <span>مبنای محور عمودی</span>
                <strong>
                  <Activity size={18} />
                  بهره‌وری دارایی‌های شرکت‌های متیل
                </strong>
              </div>
            )}
            <button
              type="button"
              className={`iv-focus ${focusSelected ? "active" : ""}`}
              onClick={() => setFocusSelected(!focusSelected)}
            >
              <Target size={19} />
              <span>
                <strong>تمرکز بر شرکت منتخب</strong>
                <small>
                  {focusSelected
                    ? "فقط مسیر منتخب روی نمودار است"
                    : "برای برجسته‌سازی مسیر فعال کنید"}
                </small>
              </span>
              <i />
            </button>
            <button
              type="button"
              className="iv22-weight-button"
              onClick={() => {
                setDraftWeights({ ...weights });
                setWeightsOpen(true);
              }}
            >
              <SlidersHorizontal size={19} />
              <span>
                <strong>تنظیم وزن سرمایه</strong>
                <small>
                  {INVESTMENT_COMPONENTS.map(
                    (item) =>
                      `${item.shortLabel} ${percent(weights[item.key], 0)}`,
                  ).join(" · ")}
                </small>
              </span>
              <ArrowLeft size={17} />
            </button>
          </section>
          <section className="iv-kpis iv22-kpis">
            <article className="primary">
              <div>
                <CircleGauge size={21} />
                <span>
                  امتیاز اثربخشی سرمایه
                  <small>
                    {selectedPoint?.pointType === "budget"
                      ? "سناریوی دوره بودجه منتخب"
                      : `منبع سال ${selectedPoint?.capitalSourceYear.toLocaleString("fa-IR", { useGrouping: false }) ?? "—"}`}
                  </small>
                </span>
              </div>
              <strong>
                {selectedPoint ? faNumber(selectedPoint.x, 3) : "—"}
                <small>از ۱</small>
              </strong>
              <footer>
                <span className={band.className}>{band.label}</span>
                {capitalDelta !== null && (
                  <b className={capitalDelta >= 0 ? "up" : "down"}>
                    {capitalDelta >= 0 ? "+" : ""}
                    {faNumber(capitalDelta, 3)} نسبت به سال قبل
                  </b>
                )}
              </footer>
            </article>
            <article>
              <div>
                {verticalTitle === "ضریب بهره‌برداری" ? (
                  <Factory size={21} />
                ) : (
                  <Activity size={21} />
                )}
                <span>
                  {verticalTitle}
                  <small>
                    {verticalTitle === "ضریب بهره‌برداری"
                      ? "تولید ÷ ظرفیت"
                      : "امتیاز نرمال‌شده گردش دارایی · کد ۱۵۲"}
                  </small>
                </span>
              </div>
              <strong>
                {selectedPoint ? faNumber(selectedPoint.y, 3) : "—"}
                <small>از ۱</small>
              </strong>
              <footer>
                {selectedPoint?.assetProductivity ? (
                  <b>
                    گردش دارایی:{" "}
                    {faNumber(
                      selectedPoint.assetProductivity.storedTurnover ??
                        selectedPoint.assetProductivity.rawTurnover,
                      2,
                    )}
                    x
                  </b>
                ) : operationDelta !== null ? (
                  <b className={operationDelta >= 0 ? "up" : "down"}>
                    {operationDelta >= 0 ? "بهبود" : "افت"}{" "}
                    {faNumber(Math.abs(operationDelta), 3)}
                  </b>
                ) : (
                  <b>بدون دوره مقایسه</b>
                )}
              </footer>
            </article>
          </section>
          <section className="iv-workspace">
            <article className="investment-chart-card iv-chart-card iv22-chart-card">
              <header>
                <div>
                  <p className="eyebrow">ماتریس تصمیم‌گیری چهارناحیه‌ای</p>
                  <h2>امتیاز اثربخشی سرمایه در برابر {verticalTitle}</h2>
                  <span>
                    هر نقطه یک شرکت–سال است؛ برای مشاهده جزئیات همان نقطه کلیک
                    کنید.
                  </span>
                </div>
                <div className="chart-legend">
                  <span>
                    <i className="dot actual" />
                    واقعی
                  </span>
                  <span>
                    <i className="dot forecast" />
                    دوره بودجه منتخب
                  </span>
                  <span>
                    <i className="dot optimized" />
                    سناریوی مدیریتی ۱۴۰۵
                  </span>
                  <span>
                    <i className="line" />
                    جهت حرکت
                  </span>
                </div>
              </header>
              <InvestmentScatter
                points={points}
                companies={companies}
                selectedCompany={activeCompany}
                hoveredCompany={hoveredCompany}
                onHover={setHoveredCompany}
                onSelect={(point) => {
                  setSelectedCompany(point.company);onContextChange?.(point.company,point.year);
                  setDetailPoint(point);
                }}
                verticalTitle={verticalTitle}
              />
              <div className="iv-company-rail iv22-company-rail">
                <div>
                  <strong>شرکت‌های این نما</strong>
                  <small>برای برجسته‌سازی انتخاب کنید</small>
                </div>
                <div>
                  {companies.map((company) => (
                    <button
                      type="button"
                      key={company}
                      className={company === activeCompany ? "active" : ""}
                      onMouseEnter={() => setHoveredCompany(company)}
                      onMouseLeave={() => setHoveredCompany("")}
                      onClick={() => {
                        const latest = [
                          ...scopedPoints.filter(
                            (point) => point.company === company,
                          ),
                        ].sort((a, b) => b.year - a.year)[0];
                        setSelectedCompany(company);onContextChange?.(company);
                        if (latest) setDetailPoint(latest);
                      }}
                    >
                      <i
                        style={{ background: pointColor(company, companies) }}
                      />
                      <span>{company}</span>
                    </button>
                  ))}
                </div>
              </div>
            </article>
          </section>
          {shownDetailPoint && (
            <section className="iv-details-wrap iv22-details">
              <header>
                <div>
                  <span>تحلیل نقطه منتخب</span>
                  <h2>{shownDetailPoint.company}</h2>
                </div>
                <div>
                  {selectedHistory.map((point) => (
                    <button
                      type="button"
                      key={point.id}
                      className={
                        shownDetailPoint.id === point.id ? "active" : ""
                      }
                      onClick={() => setDetailPoint(point)}
                    >
                      {point.year.toLocaleString("fa-IR", {
                        useGrouping: false,
                      })}
                      {point.pointType === "optimized" ? (
                        <small>بهینه</small>
                      ) : (
                        point.isForecast && <small>بودجه</small>
                      )}
                    </button>
                  ))}
                </div>
              </header>
              <PointDetailPanel
                key={`${shownDetailPoint.id}-${holding}`}
                point={shownDetailPoint}
                holding={holding}
                weights={weights}
                assetRecords={assetRecords}
                activityRecords={activityRecords}
                equipmentRecords={equipmentRecords}
                hasAssetFile={Boolean(assetModel)}
                hasActivityFile={Boolean(activityModel)}
                hasEquipmentFile={Boolean(equipmentModel)}
              />
            </section>
          )}
          {weightsOpen && (
            <div
              className="iv-weight-overlay"
              role="presentation"
              onMouseDown={() => setWeightsOpen(false)}
            >
              <aside
                role="dialog"
                aria-label="تنظیم وزن امتیاز اثربخشی سرمایه"
                onMouseDown={(event) => event.stopPropagation()}
              >
                <header>
                  <div>
                    <span>مدل امتیازدهی</span>
                    <h2>وزن مؤلفه‌های امتیاز اثربخشی سرمایه</h2>
                    <p>
                      وزن‌های نهایی را تنظیم کنید؛ پس از تأیید، همه نقاط نمودار
                      دوباره محاسبه می‌شوند.
                    </p>
                  </div>
                  <button
                    type="button"
                    aria-label="بستن بدون اعمال تغییرات"
                    onClick={() => setWeightsOpen(false)}
                  >
                    <X size={21} />
                  </button>
                </header>
                <WeightEditor
                  weights={draftWeights}
                  onChange={setDraftWeights}
                />
                <footer>
                  <button
                    type="button"
                    className="iv-weight-cancel"
                    onClick={() => setWeightsOpen(false)}
                  >
                    انصراف
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setWeights(draftWeights);
                      setWeightsOpen(false);
                    }}
                  >
                    اعمال وزن‌ها و محاسبه مجدد <ArrowLeft size={18} />
                  </button>
                </footer>
              </aside>
            </div>
          )}
          {(holding === "atieh" && Boolean(productionModel?.issues.length)) ||
          missingCapital.length > 0 ? (
            <section className="investment-data-notes">
              <header>
                <AlertTriangle size={18} />
                <strong>یادداشت کیفیت داده</strong>
              </header>
              {holding === "atieh" &&
                productionModel?.issues
                  .slice(0, 2)
                  .map((issue, index) => (
                    <p key={`${issue.row}-${index}`}>{issue.message}</p>
                  ))}
              {missingCapital.length > 0 && (
                <p>
                  برای {missingCapital.length.toLocaleString("fa-IR")} شرکت،
                  چهار امتیاز محور سرمایه یا امتیاز کد ۱۵۲/داده بهره‌برداری کامل
                  نیست؛ نقطه ناقص نمایش داده نشده است.
                </p>
              )}
            </section>
          ) : null}
        </div>
      )}
    </div>
  );
}
