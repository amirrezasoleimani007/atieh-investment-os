"use client";

import { useMemo, useRef, useState, type CSSProperties } from "react";
import * as XLSX from "xlsx";
import {
  AlertTriangle,
  BarChart3,
  CircleHelp,
  Download,
  ImageDown,
  LoaderCircle,
  Sparkles,
  Target,
  X,
} from "lucide-react";
import {
  MARKET_DIMENSIONS,
  marketCompanyFor,
  type MarketCompanyData,
  type MarketDimensionKey,
  type MarketModel,
} from "@/lib/market-engine";
import {
  RANKING_METRICS,
  type DynamicRankingRow,
  type RankingMetricKey,
} from "@/lib/dynamic-ranking-engine";

type FinancialSelection = "overall" | RankingMetricKey;
type MatrixBand = "weak" | "medium" | "strong";

interface StrategyCell {
  financial: MatrixBand;
  market: MatrixBand;
  position: string;
  policy: string;
  priority: string;
  interpretation: string;
  actions: string[];
  tone: string;
}

interface MatrixPoint {
  company: string;
  marketCompany: MarketCompanyData;
  row: DynamicRankingRow;
  financialScore: number;
  marketScore: number;
  displayFinancialScore: number;
  displayMarketScore: number;
  financialBand: MatrixBand;
  marketBand: MatrixBand;
  strategy: StrategyCell;
  x: number;
  y: number;
  radius: number;
  labelDx: number;
  labelDy: number;
}

const FINANCIAL_OPTIONS: { value: FinancialSelection; label: string; axisLabel: string }[] = [
  { value: "overall", label: "امتیاز کل مالی", axisLabel: "امتیاز مالی – امتیاز کل" },
  ...RANKING_METRICS.map((metric) => ({
    value: metric.key,
    label: metric.label,
    axisLabel: `امتیاز مالی – ${metric.shortLabel}`,
  })),
];

const BAND_LABELS: Record<MatrixBand, string> = {
  weak: "ضعیف",
  medium: "متوسط",
  strong: "قوی",
};

const STRATEGIES: Record<string, StrategyCell> = {
  "strong-strong": {
    financial: "strong", market: "strong", position: "بازار قوی / عملکرد مالی قوی", policy: "رشد و سرمایه‌گذاری", priority: "بالا",
    interpretation: "شرکت هم در بازار جذاب و هم در عملکرد مالی جایگاه قوی دارد؛ تخصیص سرمایه توسعه‌ای با تمرکز بر رشد پایدار توجیه‌پذیر است.",
    actions: ["توسعه ظرفیت‌های پربازده", "تقویت سهم بازار", "سرمایه‌گذاری در مزیت رقابتی", "پایش بازده سرمایه"], tone: "grow",
  },
  "strong-medium": {
    financial: "medium", market: "strong", position: "بازار قوی / عملکرد مالی متوسط", policy: "توسعه انتخابی", priority: "متوسط رو به بالا",
    interpretation: "شرکت در بازاری با جذابیت بالا فعالیت می‌کند، اما عملکرد مالی آن متوسط است. توسعه باید هدفمند و همزمان با رفع نقاط ضعف مالی انجام شود.",
    actions: ["رفع گلوگاه‌های سودآوری", "اولویت‌دادن به CapEx پربازده", "توسعه هدفمند سهم بازار", "پایش نقد و سرمایه در گردش"], tone: "selective",
  },
  "strong-weak": {
    financial: "weak", market: "strong", position: "بازار قوی / عملکرد مالی ضعیف", policy: "بازسازی و سرمایه‌گذاری مشروط", priority: "مشروط",
    interpretation: "فرصت بازار مناسب است، اما ضعف مالی ریسک تخصیص سرمایه را بالا می‌برد. سرمایه‌گذاری باید مرحله‌ای و مشروط به تحقق برنامه اصلاح باشد.",
    actions: ["تدوین برنامه بازسازی مالی", "تعریف نقاط کنترل سرمایه‌گذاری", "اصلاح حاشیه سود و نقدسازی", "آزادسازی مرحله‌ای منابع"], tone: "conditional",
  },
  "medium-strong": {
    financial: "strong", market: "medium", position: "بازار متوسط / عملکرد مالی قوی", policy: "توسعه هدفمند", priority: "متوسط رو به بالا",
    interpretation: "عملکرد مالی قوی است، اما جذابیت بازار در سطح متوسط قرار دارد. توسعه باید به فرصت‌های منتخب و کم‌ریسک محدود شود.",
    actions: ["تمرکز بر بخش‌های جذاب بازار", "حفظ مزیت بهره‌وری", "توسعه بدون افزایش ریسک", "ارزیابی دقیق تقاضای آتی"], tone: "selective",
  },
  "medium-medium": {
    financial: "medium", market: "medium", position: "بازار متوسط / عملکرد مالی متوسط", policy: "حفظ و بهبود", priority: "متوسط",
    interpretation: "شرکت در موقعیتی میانه قرار دارد. اولویت با بهبود عملکرد، کنترل هزینه و توسعه محتاطانه است.",
    actions: ["بهبود بهره‌وری عملیاتی", "کنترل هزینه و نقدینگی", "انتخاب پروژه‌های کم‌ریسک", "پایش دوره‌ای جایگاه"], tone: "hold",
  },
  "medium-weak": {
    financial: "weak", market: "medium", position: "بازار متوسط / عملکرد مالی ضعیف", policy: "اصلاح ساختاری", priority: "پایین تا مشروط",
    interpretation: "بازار هنوز ظرفیت محدود دارد، اما ضعف مالی مانع توسعه است. ابتدا اصلاح مدل عملیاتی و مالی ضرورت دارد.",
    actions: ["بازسازی عملیات و ساختار هزینه", "توقف توسعه سرمایه‌بر", "اصلاح مدل کسب‌وکار", "تعیین اهداف مالی مرحله‌ای"], tone: "repair",
  },
  "weak-strong": {
    financial: "strong", market: "weak", position: "بازار ضعیف / عملکرد مالی قوی", policy: "برداشت نقد و حفظ موقعیت", priority: "پایین",
    interpretation: "شرکت از نظر مالی قوی است، اما بازار ظرفیت توسعه محدودی دارد. رویکرد مناسب، حفظ سودآوری و برداشت منضبط نقد است.",
    actions: ["تمرکز بر تولید نقد", "محدودکردن CapEx توسعه‌ای", "حفظ مشتریان سودآور", "انتقال منابع مازاد"], tone: "harvest",
  },
  "weak-medium": {
    financial: "medium", market: "weak", position: "بازار ضعیف / عملکرد مالی متوسط", policy: "برداشت و کنترل سرمایه", priority: "پایین",
    interpretation: "جذابیت پایین بازار و عملکرد متوسط، توسعه را کم‌اولویت می‌کند. کنترل سرمایه و بررسی گزینه‌های راهبردی مناسب‌تر است.",
    actions: ["کنترل سرمایه در گردش", "تعویق توسعه غیرضروری", "برداشت نقد عملیاتی", "بررسی گزینه‌های راهبردی"], tone: "harvest",
  },
  "weak-weak": {
    financial: "weak", market: "weak", position: "بازار ضعیف / عملکرد مالی ضعیف", policy: "بازنگری بنیادی / خروج", priority: "بسیار پایین",
    interpretation: "هم جذابیت بازار و هم عملکرد مالی ضعیف است. ادامه تخصیص سرمایه تنها با توجیه اصلاح بنیادی امکان‌پذیر است.",
    actions: ["ارزیابی اصلاح بنیادی", "بررسی ادغام یا واگذاری", "کاهش تخصیص سرمایه", "تعیین برنامه خروج یا احیا"], tone: "review",
  },
};

const CHART = { width: 980, height: 610, left: 88, right: 938, top: 34, bottom: 530 };
const ONE_THIRD = 10 / 3;
const TWO_THIRDS = 20 / 3;
const X_RANGES = [
  { band: "weak" as const, min: 0, max: ONE_THIRD },
  { band: "medium" as const, min: ONE_THIRD, max: TWO_THIRDS },
  { band: "strong" as const, min: TWO_THIRDS, max: 10 },
];
const Y_RANGES = [...X_RANGES].reverse();

function fa(value: number, digits = 2) {
  return value.toLocaleString("fa-IR", { minimumFractionDigits: digits, maximumFractionDigits: digits });
}

function bandFor(score: number): MatrixBand {
  if (score < ONE_THIRD) return "weak";
  if (score < TWO_THIRDS) return "medium";
  return "strong";
}

function strategyFor(market: MatrixBand, financial: MatrixBand) {
  return STRATEGIES[`${market}-${financial}`];
}

function xFor(score: number) {
  return CHART.left + (score / 10) * (CHART.right - CHART.left);
}

function yFor(score: number) {
  return CHART.bottom - (score / 10) * (CHART.bottom - CHART.top);
}

function activeFinancialScore(row: DynamicRankingRow, selection: FinancialSelection) {
  return selection === "overall" ? row.score : row.metrics[selection].score;
}

function shortCompanyName(name: string) {
  const compact = name.replace(/^شرکت\s+/, "").replace(/گروه سرمایه.?گذاری/g, "").trim();
  return compact.length > 24 ? `${compact.slice(0, 22)}…` : compact;
}

function percentileMidrank(value: number, values: number[]) {
  if (values.length < 2) return 0.5;
  const sorted = [...values].sort((a, b) => a - b);
  const first = sorted.findIndex((item) => item === value);
  const last = sorted.length - 1 - [...sorted].reverse().findIndex((item) => item === value);
  return ((first + last) / 2) / (sorted.length - 1);
}

function spreadScore(value: number, values: number[], halfSpan: number) {
  const percentile = percentileMidrank(value, values);
  return 5 - halfSpan + percentile * halfSpan * 2;
}

function resolveLabelOffsets(points: Omit<MatrixPoint, "labelDx" | "labelDy">[]) {
  return points.map((point, index) => {
    let labelDx = 0;
    let labelDy = -(point.radius + 10);
    points.slice(0, index).forEach((previous, previousIndex) => {
      if (Math.abs(point.x - previous.x) < 88 && Math.abs(point.y - previous.y) < 38) {
        const direction = (index + previousIndex) % 2 === 0 ? 1 : -1;
        labelDx += direction * 34;
        labelDy -= 18 + (index % 2) * 8;
      }
    });
    return { ...point, labelDx, labelDy };
  });
}

function MarketRadar({ company, averages }: { company: MarketCompanyData; averages: Record<MarketDimensionKey, { value: number | null; count: number }> }) {
  const center = { x: 190, y: 158 };
  const radius = 102;
  const point = (index: number, score: number) => {
    const angle = -Math.PI / 2 + (index / MARKET_DIMENSIONS.length) * Math.PI * 2;
    return { x: center.x + Math.cos(angle) * radius * (score / 10), y: center.y + Math.sin(angle) * radius * (score / 10) };
  };
  const polygon = (values: (number | null)[]) => values.map((value, index) => {
    const p = point(index, value ?? 0);
    return `${p.x},${p.y}`;
  }).join(" ");
  const companyValues = MARKET_DIMENSIONS.map((dimension) => company.dimensions[dimension.key]);
  const averageValues = MARKET_DIMENSIONS.map((dimension) => averages[dimension.key].value);
  return (
    <svg className="market-radar" viewBox="0 0 380 345" role="img" aria-label={`رادار پنج‌بُعدی بازار ${company.name}`}>
      {[2, 4, 6, 8, 10].map((score) => (
        <polygon key={score} points={MARKET_DIMENSIONS.map((_, index) => { const p = point(index, score); return `${p.x},${p.y}`; }).join(" ")} fill="none" stroke="#dbe3ee" />
      ))}
      {MARKET_DIMENSIONS.map((dimension, index) => {
        const edge = point(index, 10);
        const label = point(index, 12.4);
        return <g key={dimension.key}><line x1={center.x} y1={center.y} x2={edge.x} y2={edge.y} stroke="#e2e8f0" /><text x={label.x} y={label.y} textAnchor="middle" dominantBaseline="middle">{dimension.label.replace(" بازار", "")}</text></g>;
      })}
      <polygon points={polygon(averageValues)} fill="rgba(100, 116, 139, .08)" stroke="#94a3b8" strokeWidth="2" strokeDasharray="6 5" />
      <polygon points={polygon(companyValues)} fill="rgba(37, 99, 235, .2)" stroke="#2563eb" strokeWidth="3" />
      {MARKET_DIMENSIONS.map((dimension, index) => {
        const value = company.dimensions[dimension.key];
        const p = point(index, value ?? 0);
        return <circle key={dimension.key} cx={p.x} cy={p.y} r={value === null ? 5 : 4.5} fill={value === null ? "#fff" : "#2563eb"} stroke="#2563eb" strokeDasharray={value === null ? "2 2" : undefined}><title>{`${dimension.label}: ${value === null ? "داده موجود نیست" : fa(value)} · میانگین ${averages[dimension.key].value === null ? "—" : fa(averages[dimension.key].value!)} از ${averages[dimension.key].count.toLocaleString("fa-IR")} شرکت`}</title></circle>;
      })}
    </svg>
  );
}

export default function StrategicPortfolioMatrix({
  marketModel,
  rows,
  selectedYear,
  selectedCompany,
  onSelectCompany,
}: {
  marketModel: MarketModel | null;
  rows: DynamicRankingRow[];
  selectedYear: number;
  selectedCompany: string;
  onSelectCompany: (company: string) => void;
}) {
  const [financialSelection, setFinancialSelection] = useState<FinancialSelection>("overall");
  const [spreadHalfSpan, setSpreadHalfSpan] = useState(3.5);
  const [selectedPoint, setSelectedPoint] = useState<MatrixPoint | null>(null);
  const [exporting, setExporting] = useState(false);
  const matrixRef = useRef<HTMLElement>(null);
  const activeOption = FINANCIAL_OPTIONS.find((option) => option.value === financialSelection)!;

  const averages = useMemo(() => Object.fromEntries(MARKET_DIMENSIONS.map((dimension) => {
    const values = (marketModel?.companies ?? []).map((company) => company.dimensions[dimension.key]).filter((value): value is number => value !== null);
    return [dimension.key, { value: values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : null, count: values.length }];
  })) as Record<MarketDimensionKey, { value: number | null; count: number }>, [marketModel]);

  const { points, unmatchedFinancial, unmatchedMarket } = useMemo(() => {
    if (!marketModel) return { points: [] as MatrixPoint[], unmatchedFinancial: [] as string[], unmatchedMarket: [] as string[] };
    const rawPoints = rows.flatMap((row) => {
      const marketCompany = marketCompanyFor(marketModel, row.company);
      const financialScore = activeFinancialScore(row, financialSelection);
      if (!marketCompany || marketCompany.total === null || financialScore === null) return [];
      return [{
        company: row.company,
        marketCompany,
        row,
        financialScore,
        marketScore: marketCompany.total,
      }];
    });
    const financialValues = rawPoints.map((point) => point.financialScore);
    const marketValues = rawPoints.map((point) => point.marketScore);
    const sized = rawPoints.map((point) => {
      const displayFinancialScore = spreadScore(point.financialScore, financialValues, spreadHalfSpan);
      const displayMarketScore = spreadScore(point.marketScore, marketValues, spreadHalfSpan);
      const financialBand = bandFor(displayFinancialScore);
      const marketBand = bandFor(displayMarketScore);
      return {
        ...point,
        displayFinancialScore,
        displayMarketScore,
        financialBand,
        marketBand,
        strategy: strategyFor(marketBand, financialBand),
        x: xFor(displayFinancialScore),
        y: yFor(displayMarketScore),
        radius: 14,
      };
    });
    const matchedMarket = new Set(sized.map((point) => point.marketCompany.canonicalName));
    const matchedFinancial = new Set(sized.map((point) => point.company));
    return {
      points: resolveLabelOffsets(sized),
      unmatchedFinancial: rows.filter((row) => !matchedFinancial.has(row.company) && !marketCompanyFor(marketModel, row.company)).map((row) => row.company),
      unmatchedMarket: marketModel.companies.filter((company) => company.total !== null && !matchedMarket.has(company.canonicalName)).map((company) => company.name),
    };
  }, [financialSelection, marketModel, rows, spreadHalfSpan]);

  const financialAverage = points.length ? points.reduce((sum, point) => sum + point.financialScore, 0) / points.length : null;
  const marketAverage = points.length ? points.reduce((sum, point) => sum + point.marketScore, 0) / points.length : null;
  const displayFinancialAverage = points.length ? points.reduce((sum, point) => sum + point.displayFinancialScore, 0) / points.length : null;
  const displayMarketAverage = points.length ? points.reduce((sum, point) => sum + point.displayMarketScore, 0) / points.length : null;
  const growthCount = points.filter((point) => point.financialBand === "strong" && point.marketBand === "strong").length;

  function selectPoint(point: MatrixPoint) {
    setSelectedPoint(point);
    onSelectCompany(point.company);
  }

  function exportExcel() {
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(points.map((point) => ({
      شرکت: point.company,
      سال: selectedYear,
      "نوع امتیاز مالی": activeOption.label,
      "امتیاز مالی": point.financialScore,
      "جایگاه نمایشی مالی": point.displayFinancialScore,
      "سطح مالی": BAND_LABELS[point.financialBand],
      "امتیاز بازار": point.marketScore,
      "جایگاه نمایشی بازار": point.displayMarketScore,
      "سطح بازار": BAND_LABELS[point.marketBand],
      "سیاست پیشنهادی": point.strategy.policy,
      "اولویت سرمایه": point.strategy.priority,
    }))), "ماتریس راهبردی");
    if (marketModel) XLSX.utils.book_append_sheet(workbook, XLSX.utils.json_to_sheet(marketModel.issues.map((issue) => ({ سطح: issue.severity === "error" ? "خطا" : "هشدار", ردیف: issue.row, شرکت: issue.company, پیام: issue.message }))), "کنترل کیفیت بازار");
    XLSX.writeFile(workbook, `ماتریس-راهبردی-پرتفوی-${selectedYear}.xlsx`);
  }

  async function exportImage() {
    if (!matrixRef.current) return;
    setExporting(true);
    try {
      const { toPng } = await import("html-to-image");
      const dataUrl = await toPng(matrixRef.current, { pixelRatio: 1.6, backgroundColor: "#f7f9fc", cacheBust: true, filter: (node) => !(node instanceof HTMLElement && node.classList.contains("matrix-no-export")) });
      const anchor = document.createElement("a");
      anchor.href = dataUrl;
      anchor.download = `ماتریس-راهبردی-پرتفوی-${selectedYear}.png`;
      anchor.click();
    } finally {
      setExporting(false);
    }
  }

  if (!marketModel) {
    return (
      <section className="strategic-matrix-section matrix-empty-state">
        <span className="matrix-empty-icon"><Target size={28} /></span>
        <div><p className="eyebrow">تصمیم‌یار تخصیص سرمایه</p><h3>ماتریس راهبردی پرتفوی</h3><p>برای مشاهده ماتریس راهبردی، دیتابیس ارزیابی بازار را در صفحه بارگذاری اضافه کنید.</p></div>
      </section>
    );
  }

  return (
    <section className="strategic-matrix-section" ref={matrixRef}>
      <header className="strategic-matrix-heading">
        <div><p className="eyebrow">تصمیم‌یار تخصیص سرمایه</p><h2>ماتریس راهبردی پرتفوی</h2><span>تقابل مستقل موقعیت بازار با امتیاز مالی فعال برای تعیین جهت سرمایه‌گذاری هر شرکت</span></div>
        <div className="matrix-heading-actions matrix-no-export">
          <details className="matrix-method-help">
            <summary><CircleHelp size={16} />روش محاسبه ماتریس</summary>
            <div><strong>دو محور مستقل؛ بدون امتیاز نهایی ترکیبی</strong><p>امتیاز واقعی هر محور حفظ می‌شود و فقط مختصات ماتریس، بر پایه رتبه نسبی شرکت‌ها در یک دامنه متقارن پیرامون ۵ پخش می‌شود.</p><span>مرزهای سه بخش مساوی ۳٫۳۳ و ۶٫۶۷ هستند. شرکت‌های هم‌امتیاز جایگاه یکسان می‌گیرند و اسلایدر فقط شدت پراکندگی را تغییر می‌دهد.</span></div>
          </details>
          <button type="button" className="outline-button" onClick={exportExcel}><Download size={16} />Excel</button>
          <button type="button" className="outline-button" onClick={exportImage} disabled={exporting}>{exporting ? <LoaderCircle className="spin" size={16} /> : <ImageDown size={16} />}تصویر</button>
        </div>
      </header>

      <div className="matrix-control-bar matrix-no-export">
        <label><span>مبنای محور مالی</span><select value={financialSelection} onChange={(event) => { setFinancialSelection(event.target.value as FinancialSelection); setSelectedPoint(null); }}>{FINANCIAL_OPTIONS.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}</select></label>
        <label className="matrix-spread-control"><span>دامنه پراکندگی نقاط <b>{fa(5 - spreadHalfSpan, 1)} تا {fa(5 + spreadHalfSpan, 1)}</b></span><input type="range" min="2.5" max="4.5" step="0.25" value={spreadHalfSpan} onChange={(event) => { setSpreadHalfSpan(Number(event.target.value)); setSelectedPoint(null); }} aria-label="تنظیم دامنه پراکندگی نقاط" /><small>پیش‌فرض علمی: ۱٫۵ تا ۸٫۵</small></label>
        <div><span>سال مالی فعال</span><strong>{selectedYear.toLocaleString("fa-IR", { useGrouping: false })}</strong></div>
        <div><span>فایل ارزیابی بازار</span><strong title={marketModel.fileName}>{marketModel.fileName}</strong></div>
      </div>

      <div className="matrix-kpis">
        <article><span><Target size={17} /></span><div><strong>{marketModel.summary.validTotals.toLocaleString("fa-IR")}</strong><small>شرکت دارای امتیاز بازار</small></div></article>
        <article><span><BarChart3 size={17} /></span><div><strong>{marketAverage === null ? "—" : fa(marketAverage)}</strong><small>میانگین امتیاز بازار</small></div></article>
        <article><span><Sparkles size={17} /></span><div><strong>{financialAverage === null ? "—" : fa(financialAverage)}</strong><small>میانگین مالی فعال</small></div></article>
        <article className="growth"><span><Sparkles size={17} /></span><div><strong>{growthCount.toLocaleString("fa-IR")}</strong><small>رشد و سرمایه‌گذاری</small></div></article>
      </div>

      {(marketModel.summary.errors > 0 || unmatchedFinancial.length > 0 || unmatchedMarket.length > 0) && (
        <div className="matrix-quality-callout matrix-no-export">
          <AlertTriangle size={19} />
          <div><strong>کنترل تطبیق و کیفیت داده بازار</strong><p>{marketModel.summary.errors > 0 && `${marketModel.summary.errors.toLocaleString("fa-IR")} خطای ساختاری در فایل ثبت شده است. `}{unmatchedFinancial.length > 0 && `${unmatchedFinancial.length.toLocaleString("fa-IR")} شرکت مالی با فایل بازار تطبیق قطعی نشد. `}{unmatchedMarket.length > 0 && `${unmatchedMarket.length.toLocaleString("fa-IR")} شرکت بازار در امتیاز مالی فعال قابل استفاده نبود.`}</p><details><summary>نمایش جزئیات</summary><ul>{marketModel.issues.filter((issue) => issue.severity === "error").slice(0, 8).map((issue, index) => <li key={`${issue.row}-${index}`}>{issue.company ? `${issue.company}: ` : ""}{issue.message}</li>)}{unmatchedFinancial.slice(0, 8).map((company) => <li key={`f-${company}`}>{company}: نام متناظر در فایل بازار پیدا نشد.</li>)}{unmatchedMarket.slice(0, 8).map((company) => <li key={`m-${company}`}>{company}: نام متناظر در دیتابیس مالی یا امتیاز فعال پیدا نشد.</li>)}</ul></details></div>
        </div>
      )}

      {points.length ? (
        <div className="matrix-chart-card">
          <div className="matrix-chart-wrap">
            <svg viewBox={`0 0 ${CHART.width} ${CHART.height}`} className="portfolio-matrix-svg" role="img" aria-label={`ماتریس امتیاز موقعیت بازار در برابر ${activeOption.label}`}>
              {Y_RANGES.flatMap((yRange) => X_RANGES.map((xRange) => {
                const strategy = strategyFor(yRange.band, xRange.band);
                const x = xFor(xRange.min);
                const y = yFor(yRange.max);
                const width = xFor(xRange.max) - x;
                const height = yFor(yRange.min) - y;
                const active = selectedPoint?.strategy === strategy;
                return <g key={`${yRange.band}-${xRange.band}`} className={`matrix-cell ${strategy.tone} ${active ? "active" : ""}`}><rect x={x} y={y} width={width} height={height} /><text x={x + width / 2} y={y + height - 15} textAnchor="middle">{strategy.policy}</text></g>;
              }))}
              {[0, ONE_THIRD, TWO_THIRDS, 10].map((tick) => <g key={`x-${tick}`}><line x1={xFor(tick)} x2={xFor(tick)} y1={CHART.top} y2={CHART.bottom} className={tick === ONE_THIRD || tick === TWO_THIRDS ? "classification-line" : "grid-line"} /><text x={xFor(tick)} y={CHART.bottom + 28} textAnchor="middle">{tick === 0 || tick === 10 ? tick.toLocaleString("fa-IR") : fa(tick, 2)}</text></g>)}
              {[0, ONE_THIRD, TWO_THIRDS, 10].map((tick) => <g key={`y-${tick}`}><line x1={CHART.left} x2={CHART.right} y1={yFor(tick)} y2={yFor(tick)} className={tick === ONE_THIRD || tick === TWO_THIRDS ? "classification-line" : "grid-line"} /><text x={CHART.left - 23} y={yFor(tick) + 5} textAnchor="middle">{tick === 0 || tick === 10 ? tick.toLocaleString("fa-IR") : fa(tick, 2)}</text></g>)}
              {displayFinancialAverage !== null && financialAverage !== null && <g className="benchmark-line"><line x1={xFor(displayFinancialAverage)} x2={xFor(displayFinancialAverage)} y1={CHART.top} y2={CHART.bottom} /><text x={xFor(displayFinancialAverage) + 8} y={CHART.top + 52}>میانگین مالی واقعی {fa(financialAverage, 1)}</text></g>}
              {displayMarketAverage !== null && marketAverage !== null && <g className="benchmark-line"><line x1={CHART.left} x2={CHART.right} y1={yFor(displayMarketAverage)} y2={yFor(displayMarketAverage)} /><text x={CHART.right - 8} y={yFor(displayMarketAverage) - 9} textAnchor="end">میانگین بازار واقعی {fa(marketAverage, 1)}</text></g>}
              {points.map((point) => {
                const isSelected = selectedPoint?.company === point.company || (!selectedPoint && selectedCompany === point.company);
                const faded = Boolean(selectedPoint && !isSelected);
                return <g key={point.company} className={`matrix-company-point ${isSelected ? "selected" : ""} ${faded ? "faded" : ""}`} onClick={() => selectPoint(point)} role="button" tabIndex={0} onKeyDown={(event) => { if (event.key === "Enter" || event.key === " ") selectPoint(point); }} aria-label={`${point.company}؛ برای مشاهده جزئیات کلیک کنید`}>
                  {(point.labelDx !== 0 || Math.abs(point.labelDy + point.radius + 10) > 1) && <line x1={point.x} y1={point.y - point.radius} x2={point.x + point.labelDx} y2={point.y + point.labelDy + 4} className="label-leader" />}
                  <circle className="matrix-point-halo" cx={point.x} cy={point.y} r={point.radius + 5} style={{ "--point-tone": `var(--matrix-${point.strategy.tone})` } as CSSProperties} />
                  <circle className="matrix-point-core" cx={point.x} cy={point.y} r={point.radius} style={{ "--point-tone": `var(--matrix-${point.strategy.tone})` } as CSSProperties} />
                  <circle className="matrix-point-highlight" cx={point.x - 4} cy={point.y - 4} r="3" />
                  <text x={point.x + point.labelDx} y={point.y + point.labelDy} textAnchor="middle">{shortCompanyName(point.company)}</text>
                </g>;
              })}
              <text className="matrix-axis-title" x={(CHART.left + CHART.right) / 2} y={CHART.height - 13} textAnchor="middle">{activeOption.axisLabel}</text>
              <text className="matrix-axis-title" transform={`translate(24 ${(CHART.top + CHART.bottom) / 2}) rotate(-90)`} textAnchor="middle">امتیاز موقعیت بازار</text>
            </svg>
          </div>
          <footer className="matrix-legend"><span><i className="grow" />رشد و توسعه</span><span><i className="selective" />توسعه انتخابی / حفظ</span><span><i className="harvest" />کنترل سرمایه / برداشت</span><span><b className="dash" />میانگین پرتفوی</span><small>همه حباب‌ها هم‌اندازه‌اند؛ برای مشاهده جزئیات کامل شرکت، روی نقطه کلیک کنید.</small></footer>
        </div>
      ) : (
        <div className="matrix-no-points"><AlertTriangle size={24} /><strong>شرکت قابل ترسیم وجود ندارد</strong><p>وجود ردیف «کل»، تطبیق قطعی نام شرکت و امتیاز مالی معتبر برای سال و بُعد انتخاب‌شده را کنترل کنید.</p></div>
      )}

      {selectedPoint && (
        <div className="matrix-drawer-layer" onMouseDown={() => setSelectedPoint(null)}>
          <aside className="matrix-company-drawer" role="dialog" aria-modal="true" aria-label={`جزئیات راهبردی ${selectedPoint.company}`} onMouseDown={(event) => event.stopPropagation()}>
            <header><div className="drawer-company-title"><span className={`drawer-position-icon ${selectedPoint.strategy.tone}`}><Target size={22} /></span><div><p className="eyebrow">پروفایل راهبردی شرکت</p><h3>{selectedPoint.company}</h3><span>{selectedPoint.strategy.position}</span></div></div><button type="button" className="icon-button drawer-close-button" onClick={() => setSelectedPoint(null)} aria-label="بستن پنل"><X size={20} /></button></header>
            <div className="drawer-kpis"><article><span>امتیاز مالی</span><strong>{fa(selectedPoint.financialScore)}</strong><small>{activeOption.label}</small></article><article><span>امتیاز بازار</span><strong>{fa(selectedPoint.marketScore)}</strong><small>ارزیابی جاری</small></article><article><span>موقعیت راهبردی</span><strong>{selectedPoint.strategy.policy}</strong><small>{selectedPoint.strategy.position}</small></article><article><span>اولویت سرمایه</span><strong>{selectedPoint.strategy.priority}</strong><small>بر پایه خانه ماتریس</small></article></div>
            <section className="drawer-radar-card"><header><div><strong>پروفایل پنج‌بُعدی بازار</strong><span>مقایسه شرکت با میانگین پرتفوی</span></div><div className="radar-legend"><span><i className="company" />شرکت</span><span><i className="average" />میانگین</span></div></header><MarketRadar company={selectedPoint.marketCompany} averages={averages} /></section>
            <section className="market-comparison-card"><header><strong>مقایسه ابعاد بازار</strong><span>فاصله = شرکت منهای میانگین پرتفوی</span></header><div className="market-comparison-table"><div className="comparison-head"><span>بُعد بازار</span><span>شرکت</span><span>میانگین</span><span>فاصله</span></div>{MARKET_DIMENSIONS.map((dimension) => { const value = selectedPoint.marketCompany.dimensions[dimension.key]; const average = averages[dimension.key].value; const gap = value === null || average === null ? null : value - average; return <div key={dimension.key}><span>{dimension.label}</span><b>{value === null ? "—" : fa(value)}</b><b>{average === null ? "—" : fa(average)}</b><b className={gap === null ? "neutral" : gap > 0 ? "positive" : gap < 0 ? "negative" : "neutral"}>{gap === null ? "—" : `${gap > 0 ? "+" : ""}${fa(gap)}`}</b></div>; })}</div></section>
            <section className={`strategy-summary-card ${selectedPoint.strategy.tone}`}><header><Sparkles size={18} /><strong>جمع‌بندی راهبردی</strong></header><dl><div><dt>موقعیت</dt><dd>{selectedPoint.strategy.position}</dd></div><div><dt>سیاست پیشنهادی</dt><dd>{selectedPoint.strategy.policy}</dd></div><div><dt>اولویت تخصیص سرمایه</dt><dd>{selectedPoint.strategy.priority}</dd></div></dl><p>{selectedPoint.strategy.interpretation}</p></section>
            <section className="strategy-actions"><strong>جهت اقدام پیشنهادی</strong><div>{selectedPoint.strategy.actions.map((action, index) => <span key={action}><b>{(index + 1).toLocaleString("fa-IR")}</b>{action}</span>)}</div></section>
          </aside>
        </div>
      )}
    </section>
  );
}
