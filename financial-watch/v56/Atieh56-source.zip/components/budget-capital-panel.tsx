import { ChevronDown, Layers3 } from "lucide-react";
import { buildCapitalBridge } from "@/lib/planning-decision-engine";
import { buildScenarioAssetComposition, type PlanningScenarioSnapshot } from "@/lib/planning-scenario-engine";
import type { ValueSnapshot } from "@/lib/value-creation-engine";

const number = (value: number, signed = false) => Number.isFinite(value)
  ? new Intl.NumberFormat("fa-IR", { maximumFractionDigits: 0, signDisplay: signed ? "exceptZero" : "auto" }).format(value) : "—";
const percent = (value: number) => new Intl.NumberFormat("fa-IR", { maximumFractionDigits: 1 }).format(value * 100) + "٪";

/** Presentation-only: bridge and composition use the existing scenario engine.
 * Delta bars share a symmetric zero-centered domain. Composition uses 0–100%.
 * Exact amounts remain visible, including zero, negative and sub-pixel values.
 */
export default function BudgetCapitalPanel({ actual, budget }: { actual: ValueSnapshot; budget: PlanningScenarioSnapshot }) {
  const bridge = buildCapitalBridge(actual, budget);
  const schedule = budget.assetSchedule;
  const rows = buildScenarioAssetComposition(schedule).sort((a, b) => b.amount - a.amount);
  const maxDelta = Math.max(1, ...bridge.rows.map(row => Math.abs(row.value)));
  const delta = schedule.averageInvestedCapital - actual.averageIc;
  const validShares = schedule.averageTotalAssets > 0 && rows.every(row => Number.isFinite(row.share) && row.share >= 0 && row.share <= 1);
  const dominant = rows[0];
  const reconciled = Math.abs(bridge.reconciliationDifference) <= Math.max(1, Math.abs(delta) * 1e-9);
  return <details className="vc32-section capital-focus vc32-disclosure" data-qa-section="3">
    <summary><header className="capital-focus-heading">
      <span className="capital-focus-icon"><Layers3 size={23}/></span>
      <div><h2>سرمایه کجا درگیر شده؟</h2><p>بودجه پایه ۱۴۰۵ · برای مشاهده جزئیات کلیک کنید</p></div>
    </header><ChevronDown size={20}/></summary><div className="vc32-disclosure-body">

    <div className="capital-focus-totals">
      <div><span>متوسط سرمایه درگیر · واقعی ۱۴۰۴</span><strong><bdi dir="ltr">{number(actual.averageIc)}</bdi></strong></div>
      <div className="capital-focus-change"><span>{delta > 0 ? "افزایش سرمایه موردنیاز" : delta < 0 ? "کاهش سرمایه درگیر" : "بدون تغییر سرمایه درگیر"}</span><strong><bdi dir="ltr">{number(delta, true)}</bdi></strong></div>
      <div className="capital-focus-budget"><span>متوسط سرمایه درگیر · بودجه ۱۴۰۵</span><strong><bdi dir="ltr">{number(schedule.averageInvestedCapital)}</bdi></strong></div>
    </div>

    <div className="capital-focus-block">
      <header><h3>چه چیزی سرمایه را تغییر داده است؟</h3><p>تغییر اجزا نسبت به عملکرد ۱۴۰۴؛ جمع سه ردیف برابر با تغییر کل سرمایه درگیر است.</p></header>
      <div className="capital-focus-delta-head" aria-hidden="true"><span>جزء سرمایه</span><div><span>کاهش</span><span>صفر</span><span>افزایش</span></div><span>تغییر مبلغ</span></div>
      <ul className="capital-focus-deltas">
        {bridge.rows.map(row => <li key={row.key}>
          <strong>{row.label}</strong>
          <div className="capital-focus-delta-track" aria-hidden="true"><i className={row.value < 0 ? "decrease" : "increase"} style={{ left: row.value < 0 ? `${50 - Math.abs(row.value) / maxDelta * 50}%` : "50%", width: `${Math.abs(row.value) / maxDelta * 50}%` }}/></div>
          <span className={row.value < 0 ? "capital-focus-down" : "capital-focus-up"}><bdi dir="ltr">{number(row.value, true)}</bdi><small>{row.value > 0 ? "افزایش" : row.value < 0 ? "کاهش" : "بدون تغییر"}</small></span>
        </li>)}
      </ul>
      <p className={reconciled ? "capital-focus-check" : "capital-focus-alert"}>{reconciled ? "جمع تغییر اجزا با تغییر کل سرمایه تطبیق دارد." : "جمع تغییر اجزا با تغییر کل سرمایه مغایرت دارد."} <span>اختلاف: <bdi dir="ltr">{number(bridge.reconciliationDifference)}</bdi> میلیون ریال</span></p>
    </div>

    <div className="capital-focus-block">
      <header><h3>دارایی‌های بودجه در کدام اجزا قرار دارند؟</h3><p>سهم هر جزء از کل دارایی‌های برآوردی؛ این درصدها سهم از «سرمایه درگیر» نیستند.</p></header>
      <div className="capital-focus-assets-total"><span>کل دارایی‌های برآوردی ۱۴۰۵</span><strong><bdi dir="ltr">{number(schedule.averageTotalAssets)}</bdi><small>میلیون ریال</small></strong></div>
      <div className="capital-focus-table-wrap">
        <table className="capital-focus-table">
          <thead><tr><th scope="col">جزء دارایی</th><th scope="col">مبلغ · میلیون ریال</th><th scope="col">سهم از کل</th><th scope="col">مقایسه سهم · مقیاس صفر تا ۱۰۰٪</th></tr></thead>
          <tbody>{rows.map((row, index) => <tr key={row.key} className={index === 0 ? "largest" : ""}>
            <th scope="row">{row.label}{index === 0 && row.amount > 0 && <small>بزرگ‌ترین جزء</small>}</th>
            <td><bdi dir="ltr">{number(row.amount)}</bdi></td>
            <td><bdi>{schedule.averageTotalAssets > 0 ? percent(row.share) : "—"}</bdi></td>
            <td><div className="capital-focus-share-track" aria-hidden="true">{validShares && <i style={{ width: `${row.share * 100}%` }}/>}</div></td>
          </tr>)}</tbody>
        </table>
      </div>
      {!validShares && <p className="capital-focus-alert">نمودار سهم به علت دارایی کل نامعتبر یا وجود جزء منفی نمایش داده نمی‌شود؛ مبالغ برای بررسی حفظ شده‌اند.</p>}
      {validShares && dominant && dominant.amount > 0 && <p className="capital-focus-insight"><strong>{dominant.label}</strong> با سهم {percent(dominant.share)}، بزرگ‌ترین جزء دارایی است. این تمرکز به‌تنهایی نشانه ضعف عملکرد نیست.</p>}
      <details className="capital-focus-reconcile"><summary>تفاوت کل دارایی با سرمایه درگیر چیست؟</summary>
        <p>در مدل فعلی، نقد و سرمایه‌گذاری کوتاه‌مدت از کل دارایی کسر می‌شوند. سرمایه‌گذاری بلندمدت در سرمایه درگیر باقی می‌ماند.</p>
        <dl>
          <div><dt>کل دارایی‌های برآوردی</dt><dd><bdi dir="ltr">{number(schedule.averageTotalAssets)}</bdi></dd></div>
          <div><dt>کسر: نقد</dt><dd><bdi dir="ltr">{number(schedule.cash)}</bdi></dd></div>
          <div><dt>کسر: سرمایه‌گذاری کوتاه‌مدت</dt><dd><bdi dir="ltr">{number(schedule.shortTermInvestments)}</bdi></dd></div>
          <div><dt>سرمایه درگیر بودجه</dt><dd><bdi dir="ltr">{number(schedule.averageInvestedCapital)}</bdi></dd></div>
        </dl>
      </details>
    </div>
  </div></details>;
}
