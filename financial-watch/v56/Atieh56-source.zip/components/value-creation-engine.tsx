"use client";

import {selectReportModel, type ReportKind} from '@/lib/report-period';
import { useEffect, useMemo, useState } from "react";
import {useScenarioState,finiteNumber,stringValue} from '@/lib/use-scenario-state';
import {
  Activity,
  AlertTriangle,
  ArrowUpLeft,
  Building2,
  ChevronLeft,
  CircleDollarSign,
  Gauge,
  Info,
  Layers3,
  PackageSearch,
  RotateCcw,
  Sparkles,
  Target,
  WalletCards,
  X,
} from "lucide-react";
import type { FinancialModel } from "@/lib/financial-engine";
import type { ProfitModel } from "@/lib/profit-engine";
import type { ProductionModel } from "@/lib/investment-engine";
import {
  buildStandardScenarios,
  buildValueCreationAnalysis,
  capitalForSnapshot,
  decomposeValueChange,
  profitStagesForSnapshot,
  runProductMarginScenario,
  runValueScenario,
  solveValueTarget,
  type CapitalItem,
  type ProductInsight,
  type ScenarioResult,
  type ValueDecomposition,
  type ValueSnapshot,
} from "@/lib/value-creation-engine";
import type { HoldingKey } from "@/lib/company-resolver";
import BudgetManagerView from "@/components/budget-manager-view";
import CompanySpreadChart from "@/components/company-spread-chart";

type Focus = "overview" | "profit" | "capital" | "product";
type SolverMode = "single" | "combined";
const CAPITAL_COLORS = [
  "#1769e0",
  "#0f8f83",
  "#d49a3a",
  "#7657d7",
  "#d96f8f",
  "#6d7f94",
  "#9da9b8",
];
const BASE_SCENARIO = {
  targetSpread: 0,
  marginDelta: 1,
  dsoReduction: 10,
  dioReduction: 10,
  otherReduction: 5,
} as const;
function fa(value: number | null, digits = 1) {
  if (value === null || !Number.isFinite(value)) return "—";
  return new Intl.NumberFormat("fa-IR", {
    maximumFractionDigits: digits,
    minimumFractionDigits: digits,
  }).format(value);
}
function yearFa(value: number) {
  return value.toLocaleString("fa-IR", { useGrouping: false });
}
function pct(value: number | null, digits = 1) {
  return value === null ? "—" : `${fa(value * 100, digits)}٪`;
}
function pp(value: number | null, digits = 1) {
  return value === null
    ? "—"
    : `${value >= 0 ? "+" : ""}${fa(value * 100, digits)} واحد درصد`;
}
function amount(value: number | null) {
  if (value === null || !Number.isFinite(value))
    return { value: "—", unit: "" };
  if (Math.abs(value) >= 1000)
    return { value: fa(value / 1000, 1), unit: "میلیارد ریال" };
  return { value: fa(value, 0), unit: "میلیون ریال" };
}
function Amount({ value }: { value: number | null }) {
  const out = amount(value);
  return (
    <span className="vc28-amount">
      <strong>{out.value}</strong>
      <small>{out.unit}</small>
    </span>
  );
}
function Tip({ text }: { text: string }) {
  return (
    <span className="vc28-tip" title={text}>
      <Info size={15} />
    </span>
  );
}

function ValueStatus({ snapshot }: { snapshot: ValueSnapshot }) {
  const lower = Math.min(0, snapshot.roic, snapshot.wacc) - 0.03,
    upper = Math.max(0.1, snapshot.roic, snapshot.wacc) + 0.05;
  const position = (value: number) =>
    Math.max(
      4,
      Math.min(96, ((value - lower) / Math.max(0.001, upper - lower)) * 100),
    );
  const roicPosition = position(snapshot.roic),
    waccPosition = position(snapshot.wacc),
    positive = snapshot.spread >= 0;
  return (
    <section className={`vc28-status ${positive ? "positive" : "negative"}`}>
      <div className="vc28-status-copy">
        <span className="vc28-step-label">۱ · آیا ارزش ایجاد شده است؟</span>
        <h2>
          {positive
            ? "شرکت در محدوده ارزش‌آفرینی قرار دارد"
            : "بازده شرکت هنوز هزینه سرمایه را پوشش نمی‌دهد"}
        </h2>
        <p>
          {positive
            ? `بازده شرکت ${fa(snapshot.spread * 100, 1)} واحد درصد بالاتر از حداقل بازده مورد انتظار است.`
            : `شرکت ${fa(Math.abs(snapshot.spread) * 100, 1)} واحد درصد تا نقطه ارزش‌آفرینی فاصله دارد.`}
        </p>
        {snapshot.isEstimated && (
          <span className="vc28-budget-badge">
            <Sparkles size={15} /> برآورد بودجه‌ای
          </span>
        )}
      </div>
      <div className="vc28-spread-hero">
        <span>
          فاصله ارزش‌آفرینی <b>(Spread)</b>
        </span>
        <strong>{pp(snapshot.spread)}</strong>
        <small>
          {positive ? "ارزش اقتصادی ایجادشده" : "شکاف تا نقطه سر‌به‌سر سرمایه"}
        </small>
      </div>
      <div className="vc28-value-scale" dir="ltr">
        <div className="vc28-scale-track">
          <span
            className="vc28-scale-gap"
            style={{
              left: `${Math.min(roicPosition, waccPosition)}%`,
              width: `${Math.abs(roicPosition - waccPosition)}%`,
            }}
          />
          <i className="roic" style={{ left: `${roicPosition}%` }}>
            <b>{pct(snapshot.roic)}</b>
            <em>بازده سرمایه (ROIC)</em>
          </i>
          <i className="wacc" style={{ left: `${waccPosition}%` }}>
            <b>{pct(snapshot.wacc)}</b>
            <em>حداقل بازده (WACC)</em>
          </i>
        </div>
        <div className="vc28-scale-labels">
          <span>بازده کمتر</span>
          <span>بازده بیشتر</span>
        </div>
      </div>
      <div className="vc28-status-metrics">
        <div>
          <span>
            بازده ایجادشده از سرمایه{" "}
            <Tip text="نشان می‌دهد شرکت از سرمایه‌ای که در کسب‌وکار درگیر کرده چه میزان بازده ایجاد کرده است." />
          </span>
          <strong>{pct(snapshot.roic)}</strong>
          <small>بازده سرمایه (ROIC)</small>
        </div>
        <div>
          <span>
            حداقل بازده مورد انتظار{" "}
            <Tip text="حداقل بازدهی که برای توجیه استفاده از سرمایه انتظار می‌رود." />
          </span>
          <strong>{pct(snapshot.wacc)}</strong>
          <small>هزینه سرمایه (WACC)</small>
        </div>
        <div>
          <span>
            فاصله ارزش‌آفرینی{" "}
            <Tip text="فاصله بازده ایجادشده شرکت با حداقل بازده مورد انتظار سرمایه است." />
          </span>
          <strong>{pp(snapshot.spread)}</strong>
          <small>فاصله بازده (Spread)</small>
        </div>
      </div>
    </section>
  );
}

function DriverBridge({
  decomposition,
  comparison,
}: {
  decomposition: ValueDecomposition | null;
  comparison: ValueSnapshot | null;
}) {
  if (!decomposition || !comparison)
    return (
      <section className="vc28-bridge empty">
        <div>
          <Gauge size={22} />
          <span>
            <strong>چرا این وضعیت ایجاد شده؟</strong>
            <small>
              برای تجزیه تغییر بازده سرمایه (ROIC)، یک دوره مقایسه معتبر لازم
              است.
            </small>
          </span>
        </div>
      </section>
    );
  const profitPositive = decomposition.profitEffect >= 0,
    capitalPositive = decomposition.capitalEffect >= 0;
  const dominant =
    Math.abs(decomposition.profitEffect) >=
    Math.abs(decomposition.capitalEffect)
      ? "توان سودسازی"
      : "سرمایه درگیر";
  return (
    <section className="vc28-bridge">
      <header>
        <div>
          <span className="vc28-step-label">۲ · چرا؟</span>
          <h3>عامل اصلی تغییر بازده سرمایه</h3>
        </div>
        <span className="vc28-dominant">
          عامل غالب: <b>{dominant}</b>
        </span>
      </header>
      <div className="vc28-bridge-flow" dir="rtl">
        <article className="anchor">
          <span>بازده سرمایه مبنا (ROIC)</span>
          <strong>{pct(decomposition.fromRoic)}</strong>
          <small>
            {yearFa(comparison.year)}
            {comparison.isEstimated ? " بودجه" : " واقعی"}
          </small>
        </article>
        <ChevronLeft size={21} />
        <article className={profitPositive ? "up" : "down"}>
          <span>اثر توان سودسازی</span>
          <strong>{pp(decomposition.profitEffect)}</strong>
          <small>{profitPositive ? "کمک به بازده" : "فشار بر بازده"}</small>
        </article>
        <ChevronLeft size={21} />
        <article className={capitalPositive ? "up" : "down"}>
          <span>اثر سرمایه درگیر</span>
          <strong>{pp(decomposition.capitalEffect)}</strong>
          <small>
            {capitalPositive ? "آزادسازی سرمایه" : "افزایش سرمایه درگیر"}
          </small>
        </article>
        <ChevronLeft size={21} />
        <article className="anchor current">
          <span>بازده سرمایه جاری (ROIC)</span>
          <strong>{pct(decomposition.toRoic)}</strong>
          <small>{yearFa(decomposition.toYear)}</small>
        </article>
      </div>
      <footer>
        <span>
          اثر تغییر هزینه سرمایه بر فاصله ارزش‌آفرینی (Spread):{" "}
          <b>{pp(-decomposition.waccChange)}</b>
        </span>
        <span>
          تغییر نهایی فاصله ارزش‌آفرینی (Spread):{" "}
          <b>{pp(decomposition.spreadChange)}</b>
        </span>
      </footer>
    </section>
  );
}

function ComparisonPanel({
  current,
  comparison,
  onClose,
}: {
  current: ValueSnapshot;
  comparison: ValueSnapshot;
  onClose: () => void;
}) {
  const rows = [
    [
      "بازده ایجادشده",
      pct(current.roic),
      pct(comparison.roic),
      pp(current.roic - comparison.roic),
    ],
    [
      "فاصله ارزش‌آفرینی",
      pp(current.spread),
      pp(comparison.spread),
      pp(current.spread - comparison.spread),
    ],
    [
      "سود مبنای بازده",
      amount(current.nopat).value,
      amount(comparison.nopat).value,
      pct(
        comparison.nopat
          ? (current.nopat - comparison.nopat) / Math.abs(comparison.nopat)
          : null,
      ),
    ],
    [
      "میانگین سرمایه درگیر",
      amount(current.averageIc).value,
      amount(comparison.averageIc).value,
      pct(
        comparison.averageIc
          ? (current.averageIc - comparison.averageIc) /
              Math.abs(comparison.averageIc)
          : null,
      ),
    ],
  ];
  return (
    <section className="vc28-compare">
      <header>
        <div>
          <Activity size={19} />
          <span>
            <strong>مقایسه انتخابی دوره‌ها</strong>
            <small>اعداد مبلغی با واحد یکسان فایل مالی</small>
          </span>
        </div>
        <button type="button" onClick={onClose} aria-label="بستن مقایسه">
          <X size={18} />
        </button>
      </header>
      <div className="vc28-compare-grid">
        <span>شاخص</span>
        <b>
          {yearFa(current.year)}
          {current.isEstimated ? " بودجه" : " واقعی"}
        </b>
        <b>
          {yearFa(comparison.year)}
          {comparison.isEstimated ? " بودجه" : " واقعی"}
        </b>
        <b>تغییر</b>
        {rows.flatMap((row) =>
          row.map((cell, index) =>
            index === 0 ? (
              <span key={`${row[0]}-${index}`}>{cell}</span>
            ) : (
              <strong key={`${row[0]}-${index}`}>{cell}</strong>
            ),
          ),
        )}
      </div>
    </section>
  );
}

function DriverSummary({
  snapshot,
  comparison,
  decomposition,
  focus,
  setFocus,
}: {
  snapshot: ValueSnapshot;
  comparison: ValueSnapshot | null;
  decomposition: ValueDecomposition | null;
  focus: Focus;
  setFocus: (focus: Focus) => void;
}) {
  const stages = profitStagesForSnapshot(snapshot, comparison),
    profitStages = stages.filter((stage) => stage.key !== "revenue"),
    profitMax = Math.max(
      1,
      ...profitStages.map((stage) => Math.abs(stage.value ?? 0)),
    );
  const revenueStage = stages.find((stage) => stage.key === "revenue");
  const capital = [
    {
      label: "مطالبات",
      value: snapshot.averageReceivables ?? snapshot.receivables,
    },
    { label: "موجودی", value: snapshot.averageInventory ?? snapshot.inventory },
    {
      label: "سایر سرمایه",
      value:
        snapshot.averageOtherIc ??
        Math.max(
          0,
          snapshot.averageIc - snapshot.receivables - snapshot.inventory,
        ),
    },
  ].filter((item) => item.value > 0);
  const capitalTotal = capital.reduce((sum, item) => sum + item.value, 0) || 1;
  return (
    <section className="vc28-core">
      <header>
        <div>
          <span className="vc28-step-label">۳ · اجزای اصلی</span>
          <h3>سود چگونه ساخته شده و سرمایه کجا درگیر است؟</h3>
        </div>
        <p>برای ورود به جزئیات روی هر بلوک کلیک کنید.</p>
      </header>
      <div className="vc28-core-grid">
        <button
          type="button"
          className={`vc28-core-card profit ${focus === "profit" ? "active" : ""}`}
          onClick={() => setFocus(focus === "profit" ? "overview" : "profit")}
        >
          <header>
            <span>
              <WalletCards size={23} />
              <b>توان سودسازی</b>
            </span>
            <ArrowUpLeft size={20} />
          </header>
          <div className="vc28-core-number">
            <Amount value={snapshot.nopat} />
            <small>سود مبنای بازده سرمایه · NOPAT</small>
          </div>
          <div className="vc29-revenue-anchor">
            <span>درآمد؛ مبنای محاسبه حاشیه‌ها</span>
            <Amount value={revenueStage?.value ?? snapshot.revenue} />
          </div>
          <div
            className="vc29-profit-bars compact"
            aria-label="مقایسه سودها مستقل از مقیاس درآمد"
          >
            {profitStages.map((stage) => {
              const value = stage.value ?? 0,
                ratio = Math.abs(value) / profitMax;
              return (
                <div key={stage.key}>
                  <span>{stage.label}</span>
                  <i dir="ltr">
                    <em
                      className={value < 0 ? "negative" : "positive"}
                      style={{ width: `${Math.max(3, ratio * 50)}%` }}
                    />
                  </i>
                  <strong>
                    {amount(stage.value).value}
                    <small>{amount(stage.value).unit}</small>
                  </strong>
                </div>
              );
            })}
          </div>
          <p className="vc29-scale-note">
            <Info size={14} /> مقایسه سودها با مقیاس مستقل از درآمد
          </p>
          <footer>
            <span>اثر بر تغییر ROIC</span>
            <strong>
              {decomposition ? pp(decomposition.profitEffect) : "—"}
            </strong>
            <small>مشاهده ساخت سود و عوامل غیرعملیاتی</small>
          </footer>
        </button>
        <button
          type="button"
          className={`vc28-core-card capital ${focus === "capital" ? "active" : ""}`}
          onClick={() => setFocus(focus === "capital" ? "overview" : "capital")}
        >
          <header>
            <span>
              <Layers3 size={23} />
              <b>سرمایه درگیر</b>
            </span>
            <ArrowUpLeft size={20} />
          </header>
          <div className="vc28-core-number">
            <Amount value={snapshot.averageIc} />
            <small>میانگین سرمایه درگیر · Average IC</small>
          </div>
          <div className="vc28-capital-mini">
            <div>
              {capital.map((item, index) => (
                <i
                  key={item.label}
                  style={{
                    width: `${(item.value / capitalTotal) * 100}%`,
                    backgroundColor:
                      CAPITAL_COLORS[index % CAPITAL_COLORS.length],
                  }}
                />
              ))}
            </div>
            {capital.map((item, index) => (
              <span key={item.label}>
                <i
                  style={{
                    backgroundColor:
                      CAPITAL_COLORS[index % CAPITAL_COLORS.length],
                  }}
                />
                {item.label}
                <b>{pct(item.value / capitalTotal)}</b>
              </span>
            ))}
          </div>
          <footer>
            <span>اثر بر تغییر ROIC</span>
            <strong>
              {decomposition ? pp(decomposition.capitalEffect) : "—"}
            </strong>
            <small>مشاهده ترکیب سرمایه و محرک‌های گردش</small>
          </footer>
        </button>
      </div>
    </section>
  );
}

function ProfitDetail({
  snapshot,
  comparison,
  bridge,
  rows,
  unit,
  onProducts,
}: {
  snapshot: ValueSnapshot;
  comparison: ValueSnapshot | null;
  bridge: { key: string; label: string; value: number | null }[];
  rows: ProductInsight[];
  unit: string | null;
  onProducts: () => void;
}) {
  const stages = profitStagesForSnapshot(snapshot, comparison),
    revenueStage = stages.find((stage) => stage.key === "revenue"),
    profitStages = stages.filter((stage) => stage.key !== "revenue"),
    profitMax = Math.max(
      1,
      ...profitStages.map((item) => Math.abs(item.value ?? 0)),
    );
  const impacts = bridge.filter((item) =>
    ["finance", "non-op", "tax"].includes(item.key),
  );
  const operatingShare =
    snapshot.revenue && snapshot.operatingProfit !== null
      ? snapshot.operatingProfit / snapshot.revenue
      : null;
  return (
    <div className="vc28-profit-detail">
      <section className="vc28-profit-flow vc29-profit-lens">
        <header>
          <div>
            <strong>مقایسه توان سودسازی</strong>
            <small>
              سودهای ناخالص، عملیاتی، خالص و NOPAT روی یک مقیاس هم‌واحد
            </small>
          </div>
          <span>
            حاشیه عملیاتی <b>{pct(operatingShare)}</b>
          </span>
        </header>
        <div className="vc29-revenue-anchor detailed">
          <span>
            <b>درآمد</b>
            <small>عدد مرجع؛ خارج از مقیاس مقایسه سودها</small>
          </span>
          <Amount value={revenueStage?.value ?? snapshot.revenue} />
        </div>
        <div className="vc29-profit-bars" aria-label="مقایسه سودهای شرکت">
          {profitStages.map((stage) => {
            const value = stage.value ?? 0,
              ratio = Math.abs(value) / profitMax;
            return (
              <article key={stage.key}>
                <span>
                  <b>{stage.label}</b>
                  <small>{stage.technicalLabel}</small>
                </span>
                <i dir="ltr">
                  <em
                    className={value < 0 ? "negative" : "positive"}
                    style={{ width: `${Math.max(3, ratio * 50)}%` }}
                  />
                </i>
                <Amount value={stage.value} />
                <strong>حاشیه {pct(stage.margin)}</strong>
              </article>
            );
          })}
        </div>
        <p className="vc29-scale-note">
          <Info size={14} /> خط میانی، صفر است؛ طول هر میله فقط نسبت به
          بزرگ‌ترین مقدار سود سنجیده می‌شود.
        </p>
      </section>
      <aside className="vc28-profit-effects">
        <h4>عملیاتی در برابر غیرعملیاتی</h4>
        <div className="primary">
          <span>سود حاصل از عملیات اصلی</span>
          <Amount value={snapshot.operatingProfit} />
          <small>مبنای اصلی پایداری سود</small>
        </div>
        {impacts.length ? (
          impacts.map((item) => (
            <div key={item.key}>
              <span>{item.label}</span>
              <strong>{amount(item.value).value}</strong>
            </div>
          ))
        ) : (
          <p>جزئیات غیرعملیاتی برای مبنای بودجه موجود نیست.</p>
        )}
        <div className="final">
          <span>سود خالص</span>
          <Amount value={snapshot.netProfit} />
        </div>
      </aside>
      <button type="button" className="vc28-product-entry" onClick={onProducts}>
        <PackageSearch size={22} />
        <span>
          <strong>محصولات؛ موتور سود ناخالص</strong>
          <small>
            {rows.length
              ? `${rows.length.toLocaleString("fa-IR")} محصول · مقایسه فروش و سود ناخالص`
              : "داده محصول برای این دوره موجود نیست"}
          </small>
        </span>
        <ChevronLeft size={21} />
      </button>
      <p className="vc28-note">
        <Info size={15} /> مبالغ محصول با واحد {unit ?? "فایل Profit"} نمایش
        داده می‌شوند و سود محصول مستقیماً به سود خالص تخصیص داده نمی‌شود.
      </p>
    </div>
  );
}

function ProductDetail({
  snapshot,
  rows,
  unit,
}: {
  snapshot: ValueSnapshot;
  rows: ProductInsight[];
  unit: string | null;
}) {
  const productStateKey=JSON.stringify([snapshot.company,snapshot.periodDays ?? 365,snapshot.year,snapshot.nopat,snapshot.averageIc,'product']);
  const [metric,setMetric]=useScenarioState<'gp'|'revenue'>(productStateKey+':metric','gp',(v):v is 'gp'|'revenue'=>v==='gp'||v==='revenue'),
    [productKey,setProductKey]=useScenarioState<string>(productStateKey+':key','',stringValue),
    [marginDelta,setMarginDelta]=useScenarioState<number>(productStateKey+':margin',0,finiteNumber);
  if (!rows.length)
    return (
      <div className="vc28-empty">
        <PackageSearch size={30} />
        <strong>داده کافی برای تحلیل محصول وجود ندارد.</strong>
        <span>
          موتور اصلی ارزش‌آفرینی بدون تحلیل حساسیت محصول (Product Sensitivity)
          فعال باقی می‌ماند.
        </span>
      </div>
    );
  const selected =
      rows.find((row) => `${row.sourceRow}-${row.product}` === productKey) ??
      rows[0],
    sensitivity = runProductMarginScenario(snapshot, selected, marginDelta);
  const max = Math.max(
    1,
    ...rows.map((row) =>
      Math.abs(metric === "gp" ? row.calculatedGrossProfit : row.revenue),
    ),
  );
  return (
    <div className="vc28-product-detail">
      <section className="vc28-product-ranking">
        <header>
          <div>
            <strong>کدام محصول موتور سود ناخالص است؟</strong>
            <small>
              {unit ?? "واحد فایل سود (Profit)"} · محصول پرفروش لزوماً پرسودترین
              محصول نیست.
            </small>
          </div>
          <div>
            <button
              type="button"
              className={metric === "gp" ? "active" : ""}
              onClick={() => setMetric("gp")}
            >
              سود ناخالص
            </button>
            <button
              type="button"
              className={metric === "revenue" ? "active" : ""}
              onClick={() => setMetric("revenue")}
            >
              فروش
            </button>
          </div>
        </header>
        {rows.slice(0, 12).map((row, index) => {
          const key = `${row.sourceRow}-${row.product}`,
            value = metric === "gp" ? row.calculatedGrossProfit : row.revenue;
          return (
            <button
              type="button"
              className={selected === row ? "active" : ""}
              key={key}
              onClick={() => setProductKey(key)}
            >
              <span>{(index + 1).toLocaleString("fa-IR")}</span>
              <div>
                <strong>{row.product}</strong>
                <small>
                  سهم فروش {pct(row.revenueMix)} · سهم سود ناخالص{" "}
                  {pct(row.grossProfitContribution)}
                </small>
              </div>
              <i>
                <em
                  className={value < 0 ? "negative" : ""}
                  style={{
                    width: `${Math.max(3, (Math.abs(value) / max) * 100)}%`,
                  }}
                />
              </i>
              <b>{amount(value).value}</b>
              <small>حاشیه {pct(row.calculatedGrossMargin)}</small>
            </button>
          );
        })}
      </section>
      <aside className="vc28-product-sensitivity">
        <span className="vc28-step-label">حساسیت محصول</span>
        <h4>اثر تغییر حاشیه «{selected.product}»</h4>
        <label>
          <span>
            تغییر حاشیه سود ناخالص{" "}
            <b>
              {marginDelta >= 0 ? "+" : ""}
              {fa(marginDelta, 1)} واحد درصد
            </b>
          </span>
          <input
            aria-label="تغییر حاشیه سود ناخالص محصول"
            type="range"
            min="-5"
            max="8"
            step="0.5"
            value={marginDelta}
            onChange={(event) => setMarginDelta(Number(event.target.value))}
          />
        </label>
        <div>
          <span>تغییر سود ناخالص</span>
          <Amount value={sensitivity.addedGrossProfit} />
        </div>
        <div>
          <span>تغییر سود عملیاتی پس از مالیات (NOPAT)</span>
          <Amount value={sensitivity.addedNopat} />
        </div>
        <div>
          <span>بازده سرمایه جدید (ROIC)</span>
          <strong>{pct(sensitivity.roic)}</strong>
        </div>
        <div className="highlight">
          <span>فاصله ارزش‌آفرینی جدید (Spread)</span>
          <strong>{pp(sensitivity.spread)}</strong>
          <small>{pp(sensitivity.spreadDelta)} تغییر</small>
        </div>
        <p>
          <Info size={15} /> {sensitivity.message}
        </p>
      </aside>
    </div>
  );
}

function CapitalDetail({
  snapshot,
  rows,
}: {
  snapshot: ValueSnapshot;
  rows: CapitalItem[];
}) {
  const [selectedKey, setSelectedKey] = useState("ar"),
    positiveRows = rows.filter((row) => row.value > 0),
    total = positiveRows.reduce((sum, row) => sum + row.value, 0) || 1;
  const selected = rows.find((row) => row.key.includes(selectedKey)) ?? rows[0];
  const directDriver = selected?.key.includes("ar")
    ? {
        label: "روزهای وصول مطالبات (DSO)",
        value: snapshot.dso,
        unit: "روز",
        sensitivity:
          "کاهش هر روز وصول مطالبات، متوسط مطالبات را به‌اندازه فروش روزانه کاهش می‌دهد.",
      }
    : selected?.key.includes("inventory")
      ? {
          label: "روزهای نگهداری موجودی (DIO)",
          value: snapshot.dio,
          unit: "روز",
          sensitivity:
            "کاهش هر روز نگهداری موجودی، متوسط موجودی را به‌اندازه بهای تمام‌شده روزانه کاهش می‌دهد.",
        }
      : null;
  return (
    <div className="vc28-capital-detail">
      <section className="vc28-capital-map">
        <header>
          <strong>سرمایه بیشتر کجا درگیر شده است؟</strong>
          <small>
            {snapshot.isEstimated
              ? "اجزای متوسط برآوردی"
              : "ترکیب پایان دوره؛ بازده بر مبنای میانگین سرمایه درگیر (IC)"}
          </small>
        </header>
        <div className="vc28-capital-stack">
          {positiveRows.map((row, index) => (
            <button
              type="button"
              key={row.key}
              title={`${row.label}: ${pct(row.value / total)}`}
              style={{
                width: `${(row.value / total) * 100}%`,
                backgroundColor: CAPITAL_COLORS[index % CAPITAL_COLORS.length],
              }}
              onClick={() => setSelectedKey(row.key)}
            />
          ))}
        </div>
        <div className="vc28-capital-legend">
          {positiveRows.map((row, index) => (
            <button
              type="button"
              className={selected === row ? "active" : ""}
              key={row.key}
              onClick={() => setSelectedKey(row.key)}
            >
              <i
                style={{
                  backgroundColor:
                    CAPITAL_COLORS[index % CAPITAL_COLORS.length],
                }}
              />
              <span>{row.label}</span>
              <Amount value={row.value} />
              <b>{pct(row.value / total)}</b>
            </button>
          ))}
        </div>
      </section>
      <aside className="vc28-capital-focus">
        <span className="vc28-step-label">جزء انتخاب‌شده</span>
        <h4>{selected?.label ?? "سرمایه درگیر"}</h4>
        <Amount value={selected?.value ?? null} />
        <div>
          <span>سهم از ترکیب نمایش‌داده‌شده</span>
          <strong>{pct(selected ? selected.value / total : null)}</strong>
        </div>
        {directDriver ? (
          <>
            <div>
              <span>{directDriver.label}</span>
              <strong>
                {fa(directDriver.value, 1)} {directDriver.unit}
              </strong>
            </div>
            <p>{directDriver.sensitivity}</p>
          </>
        ) : (
          <p>برای این جزء، حساسیت مستقیم روزمحور در مدل فعلی تعریف نشده است.</p>
        )}
      </aside>
      <div className="vc28-cycle-drivers">
        <article title="متوسط زمان وصول مطالبات">
          <span>روزهای وصول مطالبات</span>
          <b>(DSO)</b>
          <strong>{fa(snapshot.dso, 1)} روز</strong>
        </article>
        <article title="متوسط زمان نگهداری موجودی">
          <span>روزهای نگهداری موجودی</span>
          <b>(DIO)</b>
          <strong>{fa(snapshot.dio, 1)} روز</strong>
        </article>
        <article title="مدت استفاده از اعتبار تأمین‌کنندگان">
          <span>روزهای پرداخت بدهی</span>
          <b>(DPO)</b>
          <strong>{fa(snapshot.dpo, 1)} روز</strong>
        </article>
        <article title="مدت خالص برگشت پول">
          <span>چرخه تبدیل نقد</span>
          <b>(CCC)</b>
          <strong>{fa(snapshot.ccc, 1)} روز</strong>
        </article>
        <article title="فروش به ازای هر واحد دارایی">
          <span>گردش دارایی</span>
          <b>(Asset Turnover)</b>
          <strong>
            {snapshot.assetTurnover === null
              ? "—"
              : `${fa(snapshot.assetTurnover, 2)} برابر`}
          </strong>
        </article>
      </div>
    </div>
  );
}

function ActionPanel({
  snapshot,
  scenarios,
  focus,
  product,
}: {
  snapshot: ValueSnapshot;
  scenarios: ScenarioResult[];
  focus: Focus;
  product: ProductInsight | null;
}) {
  const relevant = scenarios.filter((item) =>
      focus === "profit" || focus === "product"
        ? item.key === "margin"
        : focus === "capital"
          ? item.key !== "margin"
          : true,
    ),
    productScenario =
      product && (focus === "profit" || focus === "product")
        ? runProductMarginScenario(snapshot, product, 1)
        : null;
  const maxDelta = Math.max(
    0.0001,
    ...relevant.map((item) => Math.abs(item.spreadDelta)),
    Math.abs(productScenario?.spreadDelta ?? 0),
  );
  return (
    <section className="vc28-actions">
      <header>
        <div>
          <span className="vc28-step-label">۴ · اقدام</span>
          <h3>کدام اقدام بیشترین اثر را دارد؟</h3>
          <p>
            {focus === "capital"
              ? "اقدام‌های مرتبط با سرمایه درگیر در اولویت قرار گرفته‌اند."
              : focus === "profit" || focus === "product"
                ? "اقدام‌های مرتبط با سودسازی در اولویت قرار گرفته‌اند."
                : "اثر سناریوهای استاندارد بر فاصله ارزش‌آفرینی مقایسه شده است."}
          </p>
        </div>
        <span>
          Spread فعلی <b>{pp(snapshot.spread)}</b>
        </span>
      </header>
      <div className="vc28-action-list">
        {relevant.map((item, index) => (
          <article key={item.key} className={!item.feasible ? "disabled" : ""}>
            <span className="rank">{(index + 1).toLocaleString("fa-IR")}</span>
            <div className="copy">
              <strong>{item.label}</strong>
              <small>{item.changeLabel}</small>
            </div>
            <div className="move">
              <span>{pp(snapshot.spread)}</span>
              <i>
                <em
                  style={{
                    width: `${Math.max(6, (Math.abs(item.spreadDelta) / maxDelta) * 100)}%`,
                  }}
                />
              </i>
              <ChevronLeft size={17} />
              <b>{pp(item.spread)}</b>
            </div>
            <div className="delta">
              <strong>{pp(item.spreadDelta)}</strong>
              <small>
                {item.feasible ? "بهبود برآوردی" : "به‌تنهایی قابل اتکا نیست"}
              </small>
            </div>
          </article>
        ))}
        {productScenario && product && (
          <article>
            <span className="rank">P</span>
            <div className="copy">
              <strong>بهبود حاشیه «{product.product}»</strong>
              <small>+۱ واحد درصد</small>
            </div>
            <div className="move">
              <span>{pp(snapshot.spread)}</span>
              <i>
                <em
                  style={{
                    width: `${Math.max(6, (Math.abs(productScenario.spreadDelta) / maxDelta) * 100)}%`,
                  }}
                />
              </i>
              <ChevronLeft size={17} />
              <b>{pp(productScenario.spread)}</b>
            </div>
            <div className="delta">
              <strong>{pp(productScenario.spreadDelta)}</strong>
              <small>اثر برآوردی محصول</small>
            </div>
          </article>
        )}
      </div>
    </section>
  );
}

function TargetPanel({
  snapshot,
  targetSpread,
  onTargetSpreadChange,
}: {
  snapshot: ValueSnapshot;
  targetSpread: number;
  onTargetSpreadChange: (value: number) => void;
}) {
  const [mode, setMode] = useScenarioState<SolverMode>(JSON.stringify([snapshot.company,snapshot.periodDays ?? 365,snapshot.year,snapshot.nopat,snapshot.averageIc,'solver-mode']),'single',(v):v is SolverMode=>v==='single'||v==='combined'),
    [marginDelta,setMarginDelta]=useScenarioState<number>(JSON.stringify([snapshot.company,snapshot.periodDays ?? 365,snapshot.year,snapshot.nopat,snapshot.averageIc,'margin']),0,finiteNumber),
    [dsoReduction,setDsoReduction]=useScenarioState<number>(JSON.stringify([snapshot.company,snapshot.periodDays ?? 365,snapshot.year,snapshot.nopat,snapshot.averageIc,'dso']),0,finiteNumber),
    [dioReduction,setDioReduction]=useScenarioState<number>(JSON.stringify([snapshot.company,snapshot.periodDays ?? 365,snapshot.year,snapshot.nopat,snapshot.averageIc,'dio']),0,finiteNumber),
    [otherReduction,setOtherReduction]=useScenarioState<number>(JSON.stringify([snapshot.company,snapshot.periodDays ?? 365,snapshot.year,snapshot.nopat,snapshot.averageIc,'other']),0,finiteNumber);
  const solver = solveValueTarget(snapshot, targetSpread / 100),
    safeDso = Math.min(dsoReduction, Math.max(0, snapshot.dso ?? 0)),
    safeDio = Math.min(dioReduction, Math.max(0, snapshot.dio ?? 0)),
    custom = runValueScenario(
      snapshot,
      marginDelta,
      safeDso,
      safeDio,
      otherReduction,
    );
  const isBase =
    mode === "single" &&
    targetSpread === BASE_SCENARIO.targetSpread &&
    marginDelta === 0 &&
    dsoReduction === 0 &&
    dioReduction === 0 &&
    otherReduction === 0;
  const reset = () => {
    setMode("single");
    setMarginDelta(0);
    setDsoReduction(0);
    setDioReduction(0);
    setOtherReduction(0);
    onTargetSpreadChange(BASE_SCENARIO.targetSpread);
  };
  return (
    <section className="vc28-target">
      <header>
        <div>
          <span className="vc28-step-label">۵ · هدف</span>
          <h3>برای رسیدن به ارزش‌آفرینی چه باید تغییر کند؟</h3>
          <small>حل‌گر هدف (Target Solver)</small>
        </div>
        <div className="vc29-target-actions">
          <div className="vc29-mode-tabs">
            <button
              type="button"
              className={mode === "single" ? "active" : ""}
              onClick={() => setMode("single")}
            >
              هر عامل به‌تنهایی
            </button>
            <button
              type="button"
              className={mode === "combined" ? "active" : ""}
              onClick={() => setMode("combined")}
            >
              ترکیب اقدامات
            </button>
          </div>
          <button
            type="button"
            className="vc29-reset"
            onClick={reset}
            disabled={isBase}
            title="بازگرداندن هدف و همه اهرم‌ها به حالت اولیه"
          >
            <RotateCcw size={16} /> بازگشت به حالت پایه
          </button>
        </div>
      </header>
      <div className={`vc29-baseline ${isBase ? "is-base" : "is-custom"}`}>
        <span>
          <i />
          {isBase ? "حالت پایه فعال است" : "سناریوی کاربر فعال است"}
        </span>
        <small>
          پایه: هدف فاصله ارزش‌آفرینی (Spread) صفر · حاشیه +۱ واحد درصد · روزهای
          وصول مطالبات (DSO) و روزهای نگهداری موجودی (DIO) هرکدام −۱۰ روز · سایر
          سرمایه −۵٪
        </small>
      </div>
      {mode === "single" ? (
        <div className="vc28-single-solver">
          <p>
            هر گزینه یک راه‌حل مستقل است و نشان می‌دهد اگر فقط همان عامل تغییر
            کند، چه میزان تغییر برای رسیدن به هدف لازم است.
          </p>
          <div>
            {[
              [
                "فقط سود مبنای بازده",
                solver.nopatGrowth === null
                  ? "قابل حل نیست"
                  : `${pct(solver.nopatGrowth)} افزایش`,
                solver.nopatGap === null
                  ? "داده کافی نیست"
                  : `${amount(solver.nopatGap).value} ${amount(solver.nopatGap).unit}`,
                solver.nopatGrowth !== null,
              ],
              [
                "فقط حاشیه سود عملیاتی",
                solver.marginPp === null
                  ? "قابل حل نیست"
                  : `${fa(solver.marginPp, 1)} واحد درصد افزایش`,
                "با ثابت بودن سرمایه درگیر",
                solver.marginPp !== null,
              ],
              [
                "فقط سرمایه درگیر",
                solver.capitalFeasible
                  ? `${pct(solver.icReductionPercent)} کاهش`
                  : "این عامل به‌تنهایی کافی نیست.",
                solver.icReduction === null
                  ? "سود فعلی مثبت نیست"
                  : `${amount(solver.icReduction).value} ${amount(solver.icReduction).unit}`,
                solver.capitalFeasible,
              ],
              [
                "فقط سرعت وصول مطالبات",
                solver.dso.feasible
                  ? `از ${fa(solver.dso.current, 1)} به ${fa(solver.dso.target, 1)} روز`
                  : "این عامل به‌تنهایی کافی نیست.",
                `کاهش نظری ${fa(solver.dso.theoretical, 1)} روز`,
                solver.dso.feasible,
              ],
              [
                "فقط سرعت گردش موجودی",
                solver.dio.feasible
                  ? `از ${fa(solver.dio.current, 1)} به ${fa(solver.dio.target, 1)} روز`
                  : "این عامل به‌تنهایی کافی نیست.",
                `کاهش نظری ${fa(solver.dio.theoretical, 1)} روز`,
                solver.dio.feasible,
              ],
            ].map((item) => (
              <article
                className={item[3] ? "feasible" : "not-feasible"}
                key={String(item[0])}
              >
                <span>{item[0]}</span>
                <strong>{item[1]}</strong>
                <small>{item[2]}</small>
              </article>
            ))}
          </div>
        </div>
      ) : (
        <div className="vc28-combined">
          <div className="vc28-sliders">
            <label>
              <span>
                بهبود حاشیه عملیاتی <b>+{fa(marginDelta, 1)} واحد درصد</b>
              </span>
              <input
                aria-label="بهبود حاشیه عملیاتی"
                type="range"
                min="0"
                max="8"
                step="0.5"
                value={marginDelta}
                onChange={(event) => setMarginDelta(Number(event.target.value))}
              />
            </label>
            <label>
              <span>
                کاهش روزهای وصول مطالبات (DSO) <b>{fa(safeDso, 0)} روز</b>
              </span>
              <input
                aria-label="کاهش دوره وصول مطالبات"
                type="range"
                min="0"
                max={Math.max(0, snapshot.dso ?? 0)}
                step="1"
                value={safeDso}
                onChange={(event) =>
                  setDsoReduction(Number(event.target.value))
                }
              />
            </label>
            <label>
              <span>
                کاهش روزهای نگهداری موجودی (DIO) <b>{fa(safeDio, 0)} روز</b>
              </span>
              <input
                aria-label="کاهش دوره نگهداری موجودی"
                type="range"
                min="0"
                max={Math.max(0, snapshot.dio ?? 0)}
                step="1"
                value={safeDio}
                onChange={(event) =>
                  setDioReduction(Number(event.target.value))
                }
              />
            </label>
            <label>
              <span>
                کاهش سایر سرمایه <b>{fa(otherReduction, 0)}٪</b>
              </span>
              <input
                aria-label="کاهش سایر سرمایه درگیر"
                type="range"
                min="0"
                max="30"
                step="1"
                value={otherReduction}
                onChange={(event) =>
                  setOtherReduction(Number(event.target.value))
                }
              />
            </label>
          </div>
          <div
            className={`vc28-target-result ${custom.spread >= targetSpread / 100 ? "reached" : ""}`}
            aria-live="polite"
          >
            <span>فاصله ارزش‌آفرینی جدید (Spread)</span>
            <strong>{pp(custom.spread)}</strong>
            <div>
              <span>
                بازده سرمایه جدید (ROIC) <b>{pct(custom.roic)}</b>
              </span>
              <span>
                سرمایه جدید <b>{amount(custom.newAverageIc).value}</b>
              </span>
              <span>
                سود عملیاتی پس از مالیات جدید (NOPAT){" "}
                <b>{amount(snapshot.nopat + custom.addedNopat).value}</b>
              </span>
            </div>
            <i>
              <em
                style={{
                  width: `${Math.max(3, Math.min(100, (custom.roic / Math.max(0.001, snapshot.wacc + targetSpread / 100)) * 100))}%`,
                }}
              />
            </i>
            <small>
              {custom.spread >= targetSpread / 100
                ? "هدف محقق شده است"
                : "هنوز تا آستانه هدف فاصله وجود دارد"}
            </small>
          </div>
        </div>
      )}
    </section>
  );
}

function ValueCreationContent({
  financialModel, reportFilter,
  profitModel,
  productionModel = null,
  holding,
  initialCompany,initialYear,onContextChange,
}: {
  financialModel: FinancialModel;
  reportFilter?: React.ReactNode;
  profitModel: ProfitModel | null;
  productionModel?: ProductionModel | null;
  holding: HoldingKey;
  initialCompany?: string;initialYear?:number;onContextChange?:(company:string,year?:number)=>void;
}) {
  const viableCompanies = useMemo(
    () =>
      financialModel.companies.filter((item) =>
        financialModel.years.some(
          (yr) =>
            buildValueCreationAnalysis(financialModel, profitModel, item, yr,{},productionModel,holding)
              .selected,
        ),
      ),
    [financialModel, profitModel,productionModel,holding],
  );
  const [company, setCompany] = useState(
      (initialCompany && viableCompanies.includes(initialCompany) ? initialCompany : viableCompanies[0]) ?? financialModel.companies[0] ?? "",
    ),
    initial = useMemo(
      () => buildValueCreationAnalysis(financialModel, profitModel, company,undefined,{},productionModel,holding),
      [financialModel, profitModel, company,productionModel,holding],
    );
  const [year, setYear] = useState(initialYear??initial.years.at(-1)??1404),
    [basis, setBasis] = useState<"actual" | "budget">("actual"),
    [compareEnabled, setCompareEnabled] = useState(false),
    [compareKey, setCompareKey] = useState(""),
    [focus, setFocus] = useState<Focus>("overview"),
    [targetSpread,setTargetSpread]=useScenarioState<number>(JSON.stringify([holding,company,year,financialModel.importedAt,'target-spread']),0,finiteNumber);
  const analysis = useMemo(
    () =>
      buildValueCreationAnalysis(financialModel, profitModel, company, year,{},productionModel,holding),
    [financialModel, profitModel, company, year,productionModel,holding],
  );
  useEffect(()=>{if(initialCompany)setCompany(initialCompany);if(initialYear!==undefined)setYear(initialYear);setCompareEnabled(false);setCompareKey("");},[initialCompany,initialYear]);
  const latestYear = analysis.years.at(-1) ?? year;
  const budgetAnalysis = useMemo(
    () =>
      buildValueCreationAnalysis(
        financialModel,
        profitModel,
        company,
        latestYear,
        {},productionModel,holding,
      ),
    [financialModel, profitModel, company, latestYear,productionModel,holding],
  );
  const companyHolding = holding;
  const selected = analysis.selected,
    active =
      basis === "budget" && budgetAnalysis.budget
        ? budgetAnalysis.budget
        : selected,
    defaultComparison =
      basis === "budget" ? budgetAnalysis.selected : analysis.previous;
  const chosenComparison =
    compareKey === "budget"
      ? budgetAnalysis.budget
      : (analysis.actuals.find((item) => String(item.year) === compareKey) ??
        defaultComparison);
  const comparison =
    chosenComparison &&
    active &&
    chosenComparison.year === active.year &&
    chosenComparison.isEstimated === active.isEstimated
      ? defaultComparison
      : chosenComparison;
  const decomposition = active
      ? decomposeValueChange(comparison ?? null, active)
      : null,
    scenarios = useMemo(
      () => (active ? buildStandardScenarios(active) : []),
      [active],
    ),
    capitalRows = active
      ? capitalForSnapshot(
          active,
          basis === "budget" ? budgetAnalysis.capital : analysis.capital,
        )
      : [],
    productRows =
      basis === "budget" ? budgetAnalysis.budgetProducts : analysis.products,
    primaryProduct = productRows[0] ?? null;
  const changeCompany = (next: string) => {
    const nextAnalysis = buildValueCreationAnalysis(
      financialModel,
      profitModel,
      next,
      undefined,{},productionModel,holding,
    );
    setCompany(next);onContextChange?.(next);
    setYear(nextAnalysis.years.at(-1) ?? 1404);
    setBasis("actual");
    setCompareEnabled(false);
    setCompareKey("");
    setFocus("overview");
  };
  if (!selected || !active)
    return (
      <div className="value-creation-page vc28-page">
        {reportFilter}
        <div className="vc28-empty large">
          <AlertTriangle size={35} />
          <strong>داده کافی برای این تحلیل وجود ندارد.</strong>
          <span>
            سرمایه درگیر دو دوره، سود عملیاتی پس از مالیات (NOPAT)، هزینه سرمایه
            (WACC)، نرخ مالیات، درآمد و بهای تمام‌شده باید معتبر باشند.
          </span>
        </div>
      </div>
    );
  if (basis === "budget" && budgetAnalysis.budget)
    return (
      <BudgetManagerView
        financialModel={financialModel}
        profitModel={profitModel}
        productionModel={productionModel}
        holding={companyHolding}
        company={company}
        companies={viableCompanies}
        actual={budgetAnalysis.actuals.find(s=>s.year===budgetAnalysis.budget!.year-1)??budgetAnalysis.selected!}
        onCompany={(next) => {
          const nextAnalysis = buildValueCreationAnalysis(
            financialModel,
            profitModel,
            next,
            undefined,{},productionModel,holding,
          );
          setCompany(next);onContextChange?.(next);
          setYear(nextAnalysis.years.at(-1) ?? 1404);
        }}
        onActual={() => setBasis("actual")}
      />
    );
  const positive = active.spread >= 0,
    topScenario = scenarios.find((item) => item.feasible) ?? null;
  const insight = `${positive ? `بازده شرکت ${fa(active.spread * 100, 1)} واحد درصد بالاتر از حداقل بازده مورد انتظار است.` : `بازده شرکت ${fa(Math.abs(active.spread) * 100, 1)} واحد درصد پایین‌تر از حداقل بازده مورد انتظار است.`} ${decomposition ? `${decomposition.profitEffect >= 0 ? "تغییر توان سودسازی اثر مثبت" : "افت توان سودسازی اثر منفی"} داشته و ${decomposition.capitalEffect >= 0 ? "سرمایه درگیر به بهبود بازده کمک کرده" : "افزایش سرمایه درگیر بخشی از بازده را خنثی کرده"} است.` : "برای تحلیل علت تغییر، داده مقایسه‌ای کافی وجود ندارد."} ${topScenario ? `بیشترین ظرفیت بهبود استاندارد فعلی در «${topScenario.label}» دیده می‌شود.` : ""}`;
  const periodValue = basis === "budget" ? "budget" : String(active.year),
    comparisonValue =
      compareKey ||
      (defaultComparison
        ? defaultComparison.isEstimated
          ? "budget"
          : String(defaultComparison.year)
        : "");
  return (
    <div className="value-creation-page vc28-page">
      <section className="vc28-hero">
        <div>
          <span>
            <CircleDollarSign size={19} /> موتور ارزش‌آفرینی · عملکرد واقعی
          </span>
          <h1>از وضعیت سرمایه تا تصمیم مدیریتی</h1>
          <p>
            {financialModel.reportKind === "half-year" ? "بازده شش‌ماهه با WACC معادل شش‌ماهه سنجیده می‌شود؛ سرمایه ابتدای دوره از پایان سال قبل خوانده می‌شود." : "وضعیت را ببینید، علت را باز کنید و اثر اقدام را پیش از تصمیم بسنجید."}
          </p>
        </div>
        <nav>
          <b>وضعیت</b>
          <ChevronLeft size={16} />
          <b>علت</b>
          <ChevronLeft size={16} />
          <b>جزء</b>
          <ChevronLeft size={16} />
          <b>اقدام</b>
          <ChevronLeft size={16} />
          <b>هدف</b>
        </nav>
      </section>
      <section className="vc28-controls no-print">
        {reportFilter}
        <label>
          <span>شرکت</span>
          <div>
            <Building2 size={18} />
            <select
              value={company}
              onChange={(event) => changeCompany(event.target.value)}
            >
              {viableCompanies.map((item) => (
                <option key={item}>{item}</option>
              ))}
            </select>
          </div>
        </label>
        <label>
          <span>دوره تحلیل</span>
          <div>
            <Activity size={18} />
            <select
              value={periodValue}
              onChange={(event) => {
                if (event.target.value === "budget") {
                  setYear(latestYear);
                  setBasis("budget");
                } else {
                  setYear(Number(event.target.value));onContextChange?.(company,Number(event.target.value));
                  setBasis("actual");
                }
                setFocus("overview");
                setTargetSpread(BASE_SCENARIO.targetSpread);
              }}
            >
              {analysis.years.map((item) => (
                <option key={item} value={item}>
                  {yearFa(item)} · واقعی
                </option>
              ))}
              {budgetAnalysis.budget && (
                <option value="budget">{budgetAnalysis.budget?.year.toLocaleString("fa-IR",{useGrouping:false})} · بودجه</option>
              )}
            </select>
          </div>
        </label>
        <label className="vc28-compare-toggle">
          <span>مقایسه با دوره دیگر</span>
          <button
            type="button"
            className={compareEnabled ? "active" : ""}
            onClick={() => setCompareEnabled(!compareEnabled)}
          >
            <i />
            <b>{compareEnabled ? "فعال" : "اختیاری"}</b>
          </button>
        </label>
        {compareEnabled && (
          <label>
            <span>دوره مقایسه</span>
            <div>
              <Activity size={18} />
              <select
                value={comparisonValue}
                onChange={(event) => setCompareKey(event.target.value)}
              >
                {analysis.actuals
                  .filter(
                    (item) =>
                      !(basis === "actual" && item.year === active.year),
                  )
                  .map((item) => (
                    <option key={item.year} value={item.year}>
                      {yearFa(item.year)} · واقعی
                    </option>
                  ))}
                {budgetAnalysis.budget && basis !== "budget" && (
                  <option value="budget">۱۴۰۵ · بودجه</option>
                )}
              </select>
            </div>
          </label>
        )}
        {basis === "budget" && (
          <span className="vc28-budget-badge">
            <Sparkles size={15} /> برآورد بودجه‌ای
          </span>
        )}
      </section>
      <ValueStatus snapshot={active} />
      <DriverBridge
        decomposition={decomposition}
        comparison={comparison ?? null}
      />
      {compareEnabled && comparison && (
        <ComparisonPanel
          current={active}
          comparison={comparison}
          onClose={() => setCompareEnabled(false)}
        />
      )}
      <DriverSummary
        snapshot={active}
        comparison={comparison ?? null}
        decomposition={decomposition}
        focus={focus}
        setFocus={setFocus}
      />
      <CompanySpreadChart financialModel={financialModel} profitModel={profitModel} productionModel={productionModel} holding={holding} year={active.year} basis="actual" selectedCompany={company} />
      {focus !== "overview" && (
        <section className="vc28-drill">
          <header>
            <div className="vc28-breadcrumb">
              <button type="button" onClick={() => setFocus("overview")}>
                موتور ارزش‌آفرینی
              </button>
              <ChevronLeft size={16} />
              {focus === "profit" && <b>توان سودسازی</b>}
              {focus === "capital" && <b>سرمایه درگیر</b>}
              {focus === "product" && (
                <>
                  <button type="button" onClick={() => setFocus("profit")}>
                    توان سودسازی
                  </button>
                  <ChevronLeft size={16} />
                  <b>محصولات</b>
                </>
              )}
            </div>
            <button
              type="button"
              onClick={() => setFocus("overview")}
              aria-label="بستن جزئیات"
            >
              <X size={19} />
            </button>
          </header>
          {focus === "profit" && (
            <ProfitDetail
              snapshot={active}
              comparison={comparison ?? null}
              bridge={basis === "budget" ? [] : analysis.bridge}
              rows={productRows}
              unit={analysis.profitUnit}
              onProducts={() => setFocus("product")}
            />
          )}{" "}
          {focus === "product" && (
            <ProductDetail
              snapshot={active}
              rows={productRows}
              unit={analysis.profitUnit}
            />
          )}{" "}
          {focus === "capital" && (
            <CapitalDetail snapshot={active} rows={capitalRows} />
          )}
        </section>
      )}
      <section className={`vc28-insight ${positive ? "positive" : "negative"}`}>
        <Sparkles size={24} />
        <div>
          <strong>جمع‌بندی مدیریتی</strong>
          <p>{insight}</p>
        </div>
      </section>
      <section className="vc28-target-control">
        <div>
          <Target size={21} />
          <span>
            <strong>هدف تصمیم</strong>
            <small>حداقل فاصله ارزش‌آفرینی مورد انتظار</small>
          </span>
        </div>
        <label>
          <input
            aria-label="هدف فاصله ارزش‌آفرینی"
            type="number"
            min="-20"
            max="30"
            step="0.5"
            value={targetSpread}
            onChange={(event) => setTargetSpread(Number(event.target.value))}
          />
          <b>واحد درصد</b>
        </label>
      </section>
      <ActionPanel
        snapshot={active}
        scenarios={scenarios}
        focus={focus}
        product={primaryProduct}
      />
      <TargetPanel
        key={`${active.company}-${active.year}-${active.isEstimated ? "budget" : "actual"}`}
        snapshot={active}
        targetSpread={targetSpread}
        onTargetSpreadChange={setTargetSpread}
      />
      {analysis.warnings.length > 0 && (
        <section className="vc28-quality">
          <header>
            <AlertTriangle size={19} />
            <strong>کنترل کیفیت و محدودیت داده</strong>
          </header>
          {analysis.warnings.map((warning) => (
            <p key={warning}>{warning}</p>
          ))}
          {profitModel?.issues.slice(0, 4).map((issue) => (
            <p key={`${issue.row}-${issue.type}`}>
              ردیف {issue.row.toLocaleString("fa-IR")}: {issue.message}
            </p>
          ))}
        </section>
      )}
    </div>
  );
}


export default function ValueCreationEngine(props: {
  financialModel: FinancialModel;
  allFinancialModel?: FinancialModel;
  profitModel: ProfitModel | null;
  productionModel?: ProductionModel | null;
  holding: HoldingKey;
  initialCompany?: string;
  initialYear?: number;
  onContextChange?: (company: string, year?: number) => void;
}) {
  const [kind, setKind] = useState<ReportKind>('annual');
  const source = props.allFinancialModel ?? props.financialModel;
  const model = useMemo(() => selectReportModel(source, kind), [source, kind]);
  const initialYear = props.initialYear !== undefined && model.years.includes(props.initialYear) ? props.initialYear : model.years.at(-1);
  const reportFilter = <label className="period-kind-filter"><span>نوع گزارش</span><div><select aria-label="نوع گزارش موتور ارزش‌آفرینی" value={kind} onChange={event => setKind(event.target.value as ReportKind)}><option value="annual">سالانه</option><option value="half-year">شش‌ماهه</option></select></div></label>;
  return <>
    {model.years.length ? <ValueCreationContent {...props} reportFilter={reportFilter} key={kind + model.importedAt} financialModel={model} initialYear={initialYear} profitModel={kind === 'annual' ? props.profitModel : null} productionModel={kind === 'annual' ? props.productionModel : null} onContextChange={kind === 'annual' ? props.onContextChange : undefined} /> : <div>{reportFilter}<p role="status">گزارش این نوع دوره در فایل بارگذاری‌شده موجود نیست.</p></div>}
  </>;
}
