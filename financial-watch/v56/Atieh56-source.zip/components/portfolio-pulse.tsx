"use client";

import { useMemo, useState } from "react";
import { Building2, ChevronDown, CircleGauge, Eye, EyeOff, TrendingDown, TrendingUp } from "lucide-react";
import type { FinancialModel } from "@/lib/financial-engine";
import type { ProfitModel } from "@/lib/profit-engine";
import type { ProductionModel } from "@/lib/investment-engine";
import type { HoldingKey } from "@/lib/company-resolver";
import { buildRoicComparison, type RoicRow as PortfolioPulseCompany } from "@/lib/roic-comparison";

type PulseYear = number;
type DetailKey = "nopat" | "capital";
const nf = (value: number, digits = 1) => new Intl.NumberFormat("fa-IR", { minimumFractionDigits: digits, maximumFractionDigits: digits }).format(value);
const pct = (value: number) => `${nf(value * 100)}٪`;
const pp = (value: number) => `${value > 0 ? "+" : ""}${nf(value * 100)} واحد درصد`;
const money = (value: number | null) => value === null ? "—" : Math.abs(value) >= 1000 ? `${nf(value / 1000)} میلیارد ریال` : `${nf(value, 0)} میلیون ریال`;
const periodLabel = (year: PulseYear) => `سال ${year.toLocaleString("fa-IR",{useGrouping:false})}`;

function RoicBar({ value, max, muted = false }: { value: number; max: number; muted?: boolean }) {
  const width = Math.min(100, Math.abs(value) / max * 100);
  return <div className={`roic-period-bar ${value < 0 ? "negative" : "positive"} ${muted ? "muted" : ""}`}><span><i style={{ width: `${Math.max(2, width)}%` }}/></span><b>{pct(value)}</b></div>;
}

function CompanyBreakdown({ current, previous, visible }: { current: PortfolioPulseCompany; previous?: PortfolioPulseCompany; visible: Set<DetailKey> }) {
  const cards = [previous, current].filter(Boolean) as PortfolioPulseCompany[];
  return <div className="roic-row-breakdown"><div className="roic-period-cards">{cards.map((row) => <article key={row.year} className={row.year === current.year ? "current" : "previous"}><header><span>{row.period==="budget"?"بودجه ":"واقعی "}{periodLabel(row.year)}</span><strong>{pct(row.roic)}</strong></header><div className="roic-equation">{visible.has("nopat") && <span><small>NOPAT</small><b>{money(row.nopat)}</b></span>}{visible.has("nopat") && visible.has("capital") && <i>÷</i>}{visible.has("capital") && <span><small>متوسط سرمایه درگیر</small><b>{money(row.investedCapital)}</b></span>}{visible.size > 0 && <i>{visible.size === 2 ? "=" : "←"}</i>}<span className="result"><small>ROIC</small><b>{pct(row.roic)}</b></span></div></article>)}</div><p>مبنای محاسبه: NOPAT ÷ متوسط سرمایه درگیر. {current.period === "budget" ? "سرمایه درگیر بودجه از برنامه دارایی‌ها برآورد شده است." : "سرمایه درگیر از میانگین ابتدا و انتهای دوره محاسبه شده است."}</p></div>;
}

export default function PortfolioPulseView({ financialModel, profitModel, productionModel, holding, onHoldingChange, availableHoldings }: { financialModel: FinancialModel; profitModel: ProfitModel | null; productionModel: ProductionModel | null; holding: HoldingKey; onHoldingChange: (holding: HoldingKey) => void; availableHoldings: Record<HoldingKey, boolean>; onCompany: (company: string) => void }) {
  const pulse = useMemo(() => buildRoicComparison(financialModel, profitModel, productionModel, holding), [financialModel, profitModel, productionModel, holding]);
  const keys=Object.keys(pulse.periods).sort((a,b)=>pulse.periods[a].year-pulse.periods[b].year||a.localeCompare(b));
  const [selectedKey,setSelectedKey]=useState('');
  const [openCompany, setOpenCompany] = useState("");
  const [visibleDetails, setVisibleDetails] = useState<Set<DetailKey>>(new Set(["nopat", "capital"]));
  const effectiveKey=pulse.periods[selectedKey]?selectedKey:keys.at(-1);
  const period=effectiveKey?pulse.periods[effectiveKey]:undefined;
  const effectiveYear=period?.year??0;
  const previousPeriod=pulse.periods[`actual:${effectiveYear-1}`];
  const previousYear=previousPeriod?.year;
  if (!period) return <section className="portfolio-pulse pulse-empty"><CircleGauge/><div><h1>ROIC قابل محاسبه نیست</h1><p>برای این مجموعه، NOPAT و سرمایه درگیر معتبر در دسترس نیست.</p></div></section>;

  const previousRows = new Map((previousPeriod?.companies??[]).map((row) => [row.company, row]));
  const rows = [...period.companies].sort((a, b) => b.roic - a.roic);
  const maxRoic = Math.max(.01, ...rows.flatMap((row) => [Math.abs(row.roic), Math.abs(previousRows.get(row.company)?.roic ?? 0)]));
  const toggleDetail = (key: DetailKey) => setVisibleDetails((current) => { const next = new Set(current); next.has(key) ? next.delete(key) : next.add(key); return next; });

  return <div className="portfolio-pulse roic-simple-page"><header className="roic-simple-hero"><div><span><CircleGauge/> مقایسه مدیریتی شرکت‌ها</span><h1>جدول مقایسه ROIC</h1><p>مقایسه بازده سرمایه شرکت‌ها با عملکرد واقعی سال قبل؛ برای مشاهده اجزای هر شرکت، ردیف آن را باز کنید.</p></div><div className="pulse-holding" role="tablist">{(["atieh", "metil"] as HoldingKey[]).map((key) => <button type="button" role="tab" aria-selected={holding === key} disabled={!availableHoldings[key]} className={holding === key ? "active" : ""} onClick={() => onHoldingChange(key)} key={key}><Building2 size={17}/>{key === "atieh" ? "آتیه فولاد" : "فولاد متیل"}</button>)}</div></header>
    <section className="roic-simple-card"><div className="roic-table-toolbar"><div className="roic-year-tabs" role="tablist" aria-label="انتخاب دوره">{keys.map((key) => { const year=pulse.periods[key].year; return <button type="button" role="tab" aria-selected={effectiveKey === key}  className={effectiveYear === year ? "active" : ""} onClick={() => setSelectedKey(key)} key={key}><span>{pulse.periods[key].period === "budget" ? "بودجه" : "واقعی"}</span><strong>{year.toLocaleString("fa-IR")}</strong></button>; })}</div><div className="roic-column-controls"><span>جزئیات قابل نمایش:</span>{([["nopat", "NOPAT (سود عملیاتی پس از مالیات)"], ["capital", "سرمایه درگیر"]] as [DetailKey, string][]).map(([key, label]) => <button type="button" className={visibleDetails.has(key) ? "active" : ""} aria-pressed={visibleDetails.has(key)} onClick={() => toggleDetail(key)} key={key}>{visibleDetails.has(key) ? <Eye/> : <EyeOff/>}{label}</button>)}</div></div>
      <div className="roic-comparison-head"><span>شرکت</span><span>{previousYear ? periodLabel(previousYear) : "دوره قبل"}</span><span>{period.period==="budget"?"بودجه ":"واقعی "}{periodLabel(effectiveYear)}</span><span>تغییر ROIC</span><span aria-hidden="true"/></div>
      <div className="roic-comparison-list">{rows.map((row, index) => { const previous = previousRows.get(row.company); const change = previous ? row.roic - previous.roic : null; const open = openCompany === row.company; return <article className={`roic-company-entry ${open ? "open" : ""}`} key={row.company}><button type="button" className="roic-company-row" aria-expanded={open} onClick={() => setOpenCompany(open ? "" : row.company)}><span className="roic-company-name"><i>{(index + 1).toLocaleString("fa-IR")}</i><strong>{row.company}</strong></span><span>{previous ? <RoicBar value={previous.roic} max={maxRoic} muted/> : <em>فاقد داده</em>}</span><span><RoicBar value={row.roic} max={maxRoic}/></span><span className={`roic-change ${change === null ? "neutral" : change >= 0 ? "up" : "down"}`}>{change === null ? "—" : <>{change >= 0 ? <TrendingUp/> : <TrendingDown/>}<b>{pp(change)}</b></>}</span><ChevronDown className="roic-expand-icon"/></button>{open && <CompanyBreakdown current={row} previous={previous} visible={visibleDetails}/>}</article>; })}</div>
      <footer className="roic-table-note"><span><i className="positive"/> ROIC مثبت</span><span><i className="negative"/> ROIC منفی</span><p>شرکت‌ها بر اساس ROIC دوره منتخب مرتب شده‌اند. نبود WACC مانع محاسبه ROIC نیست. شرکت فاقد NOPAT یا سرمایه معتبر از مقایسه حذف می‌شود.</p></footer>
    </section>
  </div>;
}
