import { readFile } from "node:fs/promises";
import { basename } from "node:path";
import { parseFinancialWorkbook } from "../lib/workbook-parser";
import { parseProfitWorkbook } from "../lib/profit-engine";
import { buildValueCreationAnalysis, runProductMarginScenario, runValueScenario, solveValueTarget } from "../lib/value-creation-engine";

async function bytes(path: string) {
  const source = await readFile(path);
  return source.buffer.slice(source.byteOffset, source.byteOffset + source.byteLength);
}

const [financialPath, profitPath] = process.argv.slice(2);
if (!financialPath || !profitPath) throw new Error("Financial and Profit workbooks are required.");

const financial = parseFinancialWorkbook(await bytes(financialPath), basename(financialPath));
const profit = parseProfitWorkbook(await bytes(profitPath), basename(profitPath));
const failures: string[] = [];
let actualPeriods = 0, positiveSpreads = 0, negativeSpreads = 0, decompositions = 0;
let budgetCompanies = 0, productCompanies = 0, productSensitivities = 0, combinedScenarios = 0;

for (const company of financial.companies) {
  const latest = financial.years.at(-1);
  if (latest === undefined) continue;
  const latestAnalysis = buildValueCreationAnalysis(financial, profit, company, latest);
  if (latestAnalysis.budget) budgetCompanies += 1;
  if (latestAnalysis.products.length || latestAnalysis.budgetProducts.length) productCompanies += 1;

  for (const year of financial.years) {
    const analysis = buildValueCreationAnalysis(financial, profit, company, year);
    const snapshot = analysis.selected;
    if (!snapshot) continue;
    actualPeriods += 1;
    if (snapshot.spread >= 0) positiveSpreads += 1; else negativeSpreads += 1;
    const combined = runValueScenario(snapshot, 1, Math.min(5, Math.max(0, snapshot.dso ?? 0)), Math.min(5, Math.max(0, snapshot.dio ?? 0)), 5);
    if (![combined.roic, combined.spread, combined.newAverageIc].every(Number.isFinite)) failures.push(`${company} ${year}: combined scenario is not finite`);
    else combinedScenarios += 1;
    const solver = solveValueTarget(snapshot, 0);
    if (!Number.isFinite(solver.targetRoic)) failures.push(`${company} ${year}: target solver is not finite`);
    if (analysis.actualDecomposition) {
      decompositions += 1;
      if (Math.abs(analysis.actualDecomposition.spreadControlDifference) > 1e-9) failures.push(`${company} ${year}: Shapley reconciliation failed`);
    }
    const product = analysis.products[0];
    if (product) {
      const result = runProductMarginScenario(snapshot, product, 1);
      if (!result.feasible || ![result.addedGrossProfit, result.addedNopat, result.roic, result.spread].every(Number.isFinite)) failures.push(`${company} ${year}: product sensitivity failed`);
      else productSensitivities += 1;
    }
  }
}

console.log(JSON.stringify({
  files: [basename(financialPath), basename(profitPath)], companies: financial.companies.length,
  actualPeriods, positiveSpreads, negativeSpreads, decompositions, combinedScenarios,
  budgetCompanies, productCompanies, productSensitivities, failures,
}, null, 2));

if (failures.length) process.exitCode = 1;
