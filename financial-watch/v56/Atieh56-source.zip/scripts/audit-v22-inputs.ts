import fs from "node:fs";
import {
  activityForCompany,
  assetsForCompany,
  parseAssetWorkbook,
  parseMetilActivityWorkbook,
} from "../lib/investment-data-engine";
import { buildFinancialModel } from "../lib/financial-engine";
import { buildInvestmentPoints, parseProductionWorkbook } from "../lib/investment-engine";

function arrayBuffer(path: string) {
  const buffer = fs.readFileSync(path);
  return buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength);
}

const assetPath = process.argv[2];
const activityPath = process.argv[3];
const productPath = process.argv[4];
if (!assetPath || !activityPath || !productPath) throw new Error("Asset, activity and product workbook paths are required.");

const assets = parseAssetWorkbook(arrayBuffer(assetPath), "assets.xlsx");
const activity = parseMetilActivityWorkbook(arrayBuffer(activityPath), "metil.xlsx");
const production = parseProductionWorkbook(arrayBuffer(productPath), "product.xlsx");
const headers = ["ماهیت", "شرکت", "سال", "متغیر", "کد متغیر", "واحد", "مقدار", "امتیاز", "نشان"];
const rows: Record<string, unknown>[] = [];
for (const company of ["آتیه صنعت افق نقش جهان", "کارگزاری مبین سرمایه"]) {
  for (const code of ["144", "150", "175", "176", "165", "166", "168"]) {
    rows.push({ ماهیت: "نمونه", شرکت: company, سال: 1404, متغیر: `شاخص ${code}`, "کد متغیر": code, واحد: code.startsWith("16") ? "روز" : "درصد", مقدار: 1, امتیاز: code === "165" ? 8 : code === "166" ? 6 : code === "168" ? 7 : 5, نشان: null });
  }
}
const financial = buildFinancialModel(rows, headers, "fixture.xlsx");
const points = buildInvestmentPoints(financial, production, { spread: .4, roic: .25, fcfMargin: .2, revenueGrowth: .15 }, "atieh");
const atiehPoint = points.find((point) => point.company === "آتیه صنعت افق نقش جهان" && point.year === 1404);
const brokerPoint = points.find((point) => point.company === "کارگزاری مبین سرمایه" && point.year === 1404);

console.log(JSON.stringify({
  assets: assets.summary,
  assetClasses: [...new Set(assets.records.map((record) => record.assetClass))],
  atiehSampleRows: assetsForCompany(assets, "آتیه صنعت افق نقش جهان", "atieh").length,
  metilSampleRows: assetsForCompany(assets, "آهن و فولاد کاسپین", "metil").length,
  activity: activity.summary,
  activitySampleRows: activityForCompany(activity, "آهن و فولاد کاسپین").length,
  production: production.summary,
  atiehIndustryWeights: atiehPoint?.productGroups.map((group) => ({ label: group.label, weight: group.weight })),
  brokerOperationalEfficiency: brokerPoint?.y,
}, null, 2));
