import {readFile,writeFile} from 'node:fs/promises';
const manifest=JSON.parse(await readFile('dist-pages/.vite/manifest.json','utf8'));
const entry=Object.values(manifest).find(item=>item.isEntry&&item.src==='index.html');
if(!entry?.file)throw Error('Current static build entry is missing.');
let html=await readFile('index.html','utf8');
html=html.replace(/<script type="module"[^>]+src="\/static-main\.tsx"[^>]*><\/script>/,()=>`<script type="module" crossorigin src="./${entry.file}"></script>`);
html=html.replace('</head>',()=>`${(entry.css??[]).map(file=>`<link rel="stylesheet" href="./${file}">`).join('\n')}</head>`);
await writeFile('dist-pages/index.html',html,'utf8');
