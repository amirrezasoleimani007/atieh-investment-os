import assert from "node:assert/strict";
import {
  CHART_DEFINITIONS,
  DEFAULT_SETTINGS,
  buildAxisMatrix,
  buildFinancialModel,
} from "../lib/financial-engine";

const scores: Record<string, number> = {
  "144": 8,
  "186": 6,
  "146": 7,
  "178": 5,
  "152": 9,
  "154": 4,
  "176": 8,
  "151": 6,
  "164": 7,
  "163": 5,
  "173": 9,
  "174": 6,
  "155": 4,
  "162": 8,
  "169": 5,
  "175": 7,
  "170": 9,
};

const headers = ["ماهیت", "شرکت", "سال", "متغیر", "کد متغیر", "واحد", "مقدار", "امتیاز", "نشان"];
const rows = Object.entries(scores).map(([code, score]) => ({
  ماهیت: "تولیدی",
  شرکت: "شرکت آزمون",
  سال: 1404,
  متغیر: `شاخص ${code}`,
  "کد متغیر": code,
  واحد: "امتیاز",
  مقدار: score,
  امتیاز: score,
  نشان: "",
}));

const model = buildFinancialModel(rows, headers, "scatter-audit.xlsx");
const bundle = buildAxisMatrix(model, DEFAULT_SETTINGS).get("شرکت آزمون")?.get(1404);
assert.ok(bundle, "محورهای شرکت آزمون ساخته نشدند");

const expected = {
  phase1: [7.1, 6.2],
  phase2: [7, 7.2],
  phase3: [6.2, 6.7],
  phase4: [6.8, 7.8],
} as const;

for (const definition of CHART_DEFINITIONS) {
  assert.deepEqual(
    [bundle.axes[definition.xKey].score, bundle.axes[definition.yKey].score],
    expected[definition.key],
    `محاسبه ${definition.phase} با وزن‌های مصوب منطبق نیست`,
  );
}

const missingRows = rows.filter((row) => row["کد متغیر"] !== "186");
const missingModel = buildFinancialModel(missingRows, headers, "scatter-missing-audit.xlsx");
const missingBundle = buildAxisMatrix(missingModel, DEFAULT_SETTINGS).get("شرکت آزمون")?.get(1404);
assert.ok(missingBundle);
assert.equal(missingBundle.axes.scatterOperationalGrowth.score, null, "وزن کد مفقود نباید بازتوزیع شود");

console.log("Scatter model audit passed: 4 phases, 8 axes, 17 code-based indicators.");
