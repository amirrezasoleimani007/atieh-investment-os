import { readFile } from "node:fs/promises";
import { basename } from "node:path";
import {
  CHART_DEFINITIONS,
  DEFAULT_SETTINGS,
  buildAxisMatrix,
} from "../lib/financial-engine";
import { parseFinancialWorkbook } from "../lib/workbook-parser";

const paths = process.argv.slice(2);
if (!paths.length) throw new Error("At least one XLSX path is required.");

for (const path of paths) {
  const bytes = await readFile(path);
  const data = bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
  const model = parseFinancialWorkbook(data, basename(path));
  const matrix = buildAxisMatrix(model, DEFAULT_SETTINGS);
  const observations = model.companies.length * model.years.length;
  const phases = Object.fromEntries(
    CHART_DEFINITIONS.map((definition) => {
      let valid = 0;
      for (const company of model.companies) {
        for (const year of model.years) {
          const bundle = matrix.get(company)?.get(year);
          if (
            bundle?.axes[definition.xKey].score !== null &&
            bundle?.axes[definition.yKey].score !== null
          ) valid += 1;
        }
      }
      return [definition.phase, `${valid}/${observations}`];
    }),
  );
  console.log(JSON.stringify({
    file: basename(path),
    companies: model.companies.length,
    years: model.years,
    records: model.summary.totalRecords,
    phases,
  }));
}
