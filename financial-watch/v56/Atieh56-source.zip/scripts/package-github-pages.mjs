import { readFile, readdir, rm, writeFile } from "node:fs/promises";
import path from "node:path";

const outputRoot = path.resolve("dist-pages");
const assetsRoot = path.join(outputRoot, "assets");
const htmlPath = path.join(outputRoot, "index.html");
const publicBase = "/investment-evaluator/assets/";
const releaseTag = "v42-2";
const partPrefix = `index-${releaseTag}.part-`;
const loaderName = `main-loader-${releaseTag}.js`;
const maxPartCharacters = 220_000;

const html = await readFile(htmlPath, "utf8");
const entryMatch = html.match(/<script\s+type="module"\s+crossorigin\s+src="\/investment-evaluator\/assets\/(index-[^"]+\.js)"><\/script>/);

if (!entryMatch) {
  throw new Error("GitHub Pages entry script was not found in dist-pages/index.html.");
}

const entryName = entryMatch[1];
const entryPath = path.join(assetsRoot, entryName);
let source = await readFile(entryPath, "utf8");

// The assembled entry runs from a Blob URL, so lazy chunks need an absolute Pages path.
source = source
  .replaceAll('import("./', `import("${publicBase}`)
  .replaceAll("import('./", `import('${publicBase}`)
  .replaceAll("import(`./", "import(`" + publicBase);

for (const file of await readdir(assetsRoot)) {
  if (/^main-loader(?:-v[\w-]+)?\.js$/.test(file) || /^index-v[\w-]+\.part-\d+$/.test(file)) {
    await rm(path.join(assetsRoot, file));
  }
}

const parts = [];
for (let start = 0; start < source.length;) {
  let end = Math.min(source.length, start + maxPartCharacters);
  const lastCode = source.charCodeAt(end - 1);
  if (lastCode >= 0xd800 && lastCode <= 0xdbff) end -= 1;
  const name = `${partPrefix}${String(parts.length).padStart(2, "0")}`;
  await writeFile(path.join(assetsRoot, name), source.slice(start, end), "utf8");
  parts.push(name);
  start = end;
}

const loader = `const partNames=${JSON.stringify(parts)};
const baseUrl=new URL("./",import.meta.url);
const sourceParts=await Promise.all(partNames.map(async(name)=>{
  const response=await fetch(new URL(name,baseUrl));
  if(!response.ok)throw new Error(\`Unable to load dashboard bundle part: \${name}\`);
  return response.text();
}));
const moduleUrl=URL.createObjectURL(new Blob([sourceParts.join("")],{type:"text/javascript"}));
try{await import(moduleUrl);}finally{setTimeout(()=>URL.revokeObjectURL(moduleUrl),0);}
`;

await writeFile(path.join(assetsRoot, loaderName), loader, "utf8");
await writeFile(
  htmlPath,
  html.replace(entryMatch[0], `<script type="module" crossorigin src="/investment-evaluator/assets/${loaderName}"></script>`),
  "utf8",
);
await rm(entryPath);

const policyDataRoot = path.join(outputRoot, "data");
const policyRuntimePath = path.join(policyDataRoot, "financial_watch_policy_runtime.json");
const policySource = await readFile(policyRuntimePath, "utf8");
const policyPartNames = [];
for (let start = 0; start < policySource.length; start += 320_000) {
  const name = `financial_watch_policy_runtime.part-${String(policyPartNames.length).padStart(2, "0")}`;
  await writeFile(path.join(policyDataRoot, name), policySource.slice(start, start + 320_000), "utf8");
  policyPartNames.push(name);
}
await writeFile(
  path.join(policyDataRoot, "financial_watch_policy_runtime.manifest.json"),
  `${JSON.stringify({ parts: policyPartNames })}\n`,
  "utf8",
);
await rm(policyRuntimePath);

console.log(`Packaged ${entryName} into ${parts.length} script parts and the policy Rule Book into ${policyPartNames.length} data parts.`);
