import { readFile, writeFile } from "node:fs/promises";
import { resolve } from "node:path";

const projectRoot = resolve(import.meta.dirname, "..");
const sourcePath = resolve(projectRoot, "data/policy/financial_watch_policy_rulebook_6561_fa.json");
const outputPath = resolve(projectRoot, "public/data/financial_watch_policy_runtime.json");
const source = JSON.parse(await readFile(sourcePath, "utf8"));

function invariant(condition, message) {
  if (!condition) throw new Error(`Rule Book validation failed: ${message}`);
}

invariant(source.meta?.matrices === 4, "meta.matrices must equal 4");
invariant(source.meta?.base_states === 36, "meta.base_states must equal 36");
invariant(source.meta?.combinations === 6561, "meta.combinations must equal 6561");
invariant(Array.isArray(source.base_states) && source.base_states.length === 36, "base_states must contain 36 rows");
invariant(Array.isArray(source.combinations) && source.combinations.length === 6561, "combinations must contain 6561 rows");
invariant(Object.keys(source.policy_families ?? {}).length === 16, "policy_families must contain 16 families");

const stateCodes = new Set(source.base_states.map((state) => state.code));
invariant(stateCodes.size === 36, "base-state codes must be unique");

const stateOrders = [1, 2, 3, 4].map((matrix) => {
  const rows = source.base_states.filter((state) => state.matrix === matrix);
  invariant(rows.length === 9, `matrix ${matrix} must contain 9 base states`);
  return rows.map((state) => state.code);
});

const traces = [...new Set(source.combinations.map((row) => row.rule_trace))];
const guards = [...new Set(source.combinations.map((row) => row.guardrail))];
const actionKeys = [...new Set(source.combinations.map((row) => JSON.stringify(row.priority_actions)))];
const policies = [...new Set(source.combinations.map((row) => row.comprehensive_policy))];
const diagnoses = [...new Set(source.combinations.map((row) => row.comprehensive_diagnosis))];
const traceIndex = new Map(traces.map((value, index) => [value, index]));
const guardIndex = new Map(guards.map((value, index) => [value, index]));
const actionIndex = new Map(actionKeys.map((value, index) => [value, index]));
const policyIndex = new Map(policies.map((value, index) => [value, index]));
const diagnosisIndex = new Map(diagnoses.map((value, index) => [value, index]));
const seenCombinations = new Set();

const combinations = source.combinations.map((row, index) => {
  invariant(/^C\d{4}$/.test(row.id), `invalid combination id at row ${index + 1}`);
  invariant(Array.isArray(row.matrix_state_codes) && row.matrix_state_codes.length === 4, `${row.id} must contain four state codes`);
  row.matrix_state_codes.forEach((code, matrixIndex) => {
    invariant(stateOrders[matrixIndex].includes(code), `${row.id} references invalid state ${code}`);
  });
  const key = row.matrix_state_codes.join("|");
  invariant(!seenCombinations.has(key), `duplicate combination ${key}`);
  seenCombinations.add(key);
  invariant(source.policy_families[row.policy_family_code], `${row.id} references an unknown policy family`);
  invariant(Array.isArray(row.priority_actions) && row.priority_actions.length === 3, `${row.id} must contain exactly three priority actions`);
  invariant(typeof row.guardrail === "string" && row.guardrail.length > 0, `${row.id} is missing its guardrail`);
  invariant(typeof row.comprehensive_policy === "string" && row.comprehensive_policy.length > 0, `${row.id} is missing its comprehensive policy`);
  invariant(typeof row.comprehensive_diagnosis === "string" && row.comprehensive_diagnosis.length > 0, `${row.id} is missing its comprehensive diagnosis`);

  const expectedCodes = [];
  let cursor = index;
  for (let matrix = 3; matrix >= 0; matrix -= 1) {
    expectedCodes[matrix] = stateOrders[matrix][cursor % 9];
    cursor = Math.floor(cursor / 9);
  }
  invariant(expectedCodes.join("|") === key, `${row.id} is out of deterministic base-9 order`);

  return [
    row.policy_family_code,
    row.severity,
    traceIndex.get(row.rule_trace),
    actionIndex.get(JSON.stringify(row.priority_actions)),
    guardIndex.get(row.guardrail),
    policyIndex.get(row.comprehensive_policy),
    diagnosisIndex.get(row.comprehensive_diagnosis),
  ];
});

invariant(seenCombinations.size === 6561, "the cartesian combination coverage is incomplete");

const runtime = {
  meta: source.meta,
  state_orders: stateOrders,
  base_states: source.base_states,
  policy_families: source.policy_families,
  trend_modifiers: source.trend_modifiers,
  traces,
  guards,
  actions: actionKeys.map((value) => JSON.parse(value)),
  policies,
  diagnoses,
  combinations,
};

await writeFile(outputPath, `${JSON.stringify(runtime)}\n`, "utf8");
console.log(`Validated ${seenCombinations.size} deterministic policy combinations from Rule Book ${source.meta.version}.`);
