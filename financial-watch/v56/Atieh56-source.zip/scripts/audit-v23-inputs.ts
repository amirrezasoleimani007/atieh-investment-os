import { readFile } from "node:fs/promises";
import { basename } from "node:path";
import { parseFinancialWorkbook } from "../lib/workbook-parser";
import { parseBenchmarkWorkbook } from "../lib/benchmark-engine";
import { parseMarketWorkbook } from "../lib/market-engine";
import { buildInvestmentPoints, parseProductionWorkbook } from "../lib/investment-engine";
import {
  activityForCompany,
  assetsForCompany,
  canonicalCompanyKey,
  parseAssetWorkbook,
  parseMetilActivityWorkbook,
} from "../lib/investment-data-engine";

async function arrayBuffer(path: string) {
  const bytes = await readFile(path);
  return bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength);
}

const [atiehPath, metilPath, productPath, assetPath, activityPath, comparisonPath, marketPath] = process.argv.slice(2);
if (!marketPath) throw new Error("Seven workbook paths are required.");

const atieh = parseFinancialWorkbook(await arrayBuffer(atiehPath), basename(atiehPath));
const metil = parseFinancialWorkbook(await arrayBuffer(metilPath), basename(metilPath));
const production = parseProductionWorkbook(await arrayBuffer(productPath), basename(productPath));
const assets = parseAssetWorkbook(await arrayBuffer(assetPath), basename(assetPath));
const activity = parseMetilActivityWorkbook(await arrayBuffer(activityPath), basename(activityPath));
const comparisonBytes = await readFile(comparisonPath);
const comparison = await parseBenchmarkWorkbook(new File([comparisonBytes], basename(comparisonPath)));
const market = parseMarketWorkbook(await arrayBuffer(marketPath), basename(marketPath));
const weights = { spread: .4, roic: .25, fcfMargin: .2, revenueGrowth: .15 };

function financialProfile(label: "atieh" | "metil", model: typeof atieh) {
  const targetCodes = ["144", "150", "165", "166", "167", "168", "175", "176"];
  const codeCoverage = Object.fromEntries(targetCodes.map((code) => {
    const records = model.validRecords.filter((record) => record.code === code);
    return [code, {
      rows: records.length,
      values: records.filter((record) => record.value !== null).length,
      scores: records.filter((record) => record.score !== null).length,
      variables: [...new Set(records.map((record) => record.variable))],
    }];
  }));
  const cycleCandidates = model.validRecords
    .filter((record) => /چرخه تبدیل نقد|CCC/i.test(record.variable))
    .map((record) => ({ code: record.code, variable: record.variable, score: record.score, value: record.value }));
  const points = buildInvestmentPoints(model, production, weights, label);
  return {
    file: model.fileName,
    companies: model.companies,
    years: model.years,
    records: model.validRecords.length,
    codeCoverage,
    cycleCodes: [...new Set(cycleCandidates.map((record) => `${record.code} | ${record.variable}`))],
    cycleScoreCoverage: `${cycleCandidates.filter((record) => record.score !== null).length}/${cycleCandidates.length}`,
    points: points.length,
    pointCompanies: [...new Set(points.map((point) => point.company))],
    assetMatches: model.companies.map((company) => ({ company, rows: assetsForCompany(assets, company, label).length })),
    activityMatches: label === "metil" ? model.companies.map((company) => ({ company, rows: activityForCompany(activity, company).length })) : [],
  };
}

console.log(JSON.stringify({
  financial: [financialProfile("atieh", atieh), financialProfile("metil", metil)],
  production: {
    ...production.summary,
    companies: production.companies.map((company) => ({ company, key: canonicalCompanyKey(company) })),
    years: production.years,
  },
  assets: {
    ...assets.summary,
    groups: assets.groups,
    companies: assets.companies.map((company) => ({ company, key: canonicalCompanyKey(company) })),
  },
  activity: {
    ...activity.summary,
    companies: activity.companies.map((company) => ({ company, key: canonicalCompanyKey(company) })),
  },
  comparison: comparison.summary,
  market: market.summary,
}, null, 2));
